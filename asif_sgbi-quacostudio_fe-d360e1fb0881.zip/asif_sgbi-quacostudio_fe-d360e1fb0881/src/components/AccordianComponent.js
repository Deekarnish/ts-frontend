import * as React from "react";
import { createTheme, ThemeProvider } from "@mui/material/styles";
import Accordion from "@mui/material/Accordion";
import AccordionSummary from "@mui/material/AccordionSummary";
import AccordionDetails from "@mui/material/AccordionDetails";
import Typography from "@mui/material/Typography";
import ExpandLessIcon from "@mui/icons-material/ExpandLess";
import CloseIcon from "@mui/icons-material/Close";
import { Box, IconButton } from "@mui/material";

// Create a dark theme
const darkTheme = createTheme({
  palette: {
    mode: "dark",
  },
});

export default function AccordionExpandDefault() {
  const [expanded, setExpanded] = React.useState(false);
  const [logs, setLogs] = React.useState([]);
  const [error, setError] = React.useState(null);
  const logsEndRef = React.useRef(null);
  // Handle change when the close icon is clicked
  const handleIconClick = (event) => {
    event.stopPropagation(); // Prevent default AccordionSummary behavior
    setExpanded(!expanded);
  };

  React.useEffect(() => {
    const eventSource = new EventSource('http://192.168.29.103:8000/logs');

    eventSource.onmessage = (event) => {
      // Append new log message to the logs array
      setLogs(prevLogs => [...prevLogs, event.data]);
      console.log(event.data)
    };

    eventSource.onerror = (error) => {
      console.error('SSE error:', error);
      setError("SSE error occurred.");
      eventSource.close();  // Close connection on error
    };

    eventSource.onopen = () => {
      console.log('SSE connection established');
    };

    return () => {
      eventSource.close();
    };
  }, []);
    // Scroll to the bottom when logs change
    // React.useEffect(() => {
    //   if (logsEndRef.current) {
    //     logsEndRef.current.scrollIntoView({ behavior: "smooth" });
    //   }
    // }, [logs]);
  return (
    <ThemeProvider theme={darkTheme}>
      <div>
        <Accordion
          expanded={expanded}
          onChange={() => {}}
          sx={{
            position: "absolute", // Position absolutely
            bottom: 7, // Adjust based on where you want it
            left: 0, // Adjust based on where you want it
            right: 0, // Adjust based on where you want it
            zIndex: 10, // Ensure it's above other content
            bgcolor: "background.paper", // Ensure it has a background to stand out
          }}
        >
          <AccordionSummary
            expandIcon={
              <IconButton edge="end" onClick={handleIconClick}>
                {expanded ? <CloseIcon /> : <ExpandLessIcon />}
              </IconButton>
            }
            aria-controls="panel2-content"
            id="panel2-header"
          >
            <Box
              sx={{
                flexGrow: 1,
                display: "flex",
                justifyContent: "space-between",
                pr: 2,
              }}
            >
              <Box
                sx={{
                  bgcolor: "#2F2F37",
                  mt: -1,
                  pl: 2,
                  pr: 2,
                  pt: 1,
                  clipPath:
                    "polygon(10% 0%, 90% 0%, 100% 100%, 100% 100%, 0% 100%, 0% 100%)",
                  color: "white", // Adding color for better visibility of the text
                }}
              >
                <Typography sx={{ flexBasis: "33.33%", fontSize: 14 }}>
                  Output console
                </Typography>
              </Box>
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "flex-end",
                  flexBasis: "66.66%",
                }}
              >
                <Typography sx={{ marginRight: 2, fontSize: 14 }}>
                  Clear All
                </Typography>
                <Typography sx={{ fontSize: 14 }}>Export as</Typography>
              </Box>
            </Box>
          </AccordionSummary>
          <AccordionDetails
            sx={{
              maxHeight: 200,
              overflow: "auto",
              backgroundColor: "rgba(0, 0, 0, 0.87)",
              "&::-webkit-scrollbar": {
                width: "8px",
              },
              "&::-webkit-scrollbar-track": {
                backgroundColor: "rgba(30, 30, 30, 1)", // Darker scrollbar track background
              },
              "&::-webkit-scrollbar-thumb": {
                backgroundColor: "rgba(70, 70, 70, 1)", // Dark scrollbar thumb
                borderRadius: "4px",
              },
              "&::-webkit-scrollbar-thumb:hover": {
                backgroundColor: "rgba(90, 90, 90, 1)", // Slightly lighter when hovered
              },
            }}
          >{
            logs.map((item , index)=> <Typography key={index}>{item}</Typography>)
          }
          <div ref={logsEndRef} />
          </AccordionDetails>
        </Accordion>
      </div>
    </ThemeProvider>
  );
}
