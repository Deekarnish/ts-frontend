import React, {
  useEffect,
  useRef,
  useState,
  forwardRef,
  useImperativeHandle,
} from "react";
import { Box } from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { setParams } from "./store/dutButtonSlice";
import LoadingScreenModal from "./modals/LoadingScreenModal";
import {
  cropImageApi,
  onClikNavigation,
  onClikNavigationLeft,
  onClikNavigationRight,
  swipeCommandApi,
} from "../api/navigationApis";
import { setParamsSCreen } from "./store/dutScreenSlice";
import AccordionExpandDefault from "./AccordianComponent";
import { disableVideoFeedCanvas } from "./store/videoFeedSlice";
import { setWsStatus } from "./store/ApiLoadingSlice";
import dut from "../assest/images/dut images/mobile.jpg";
import { setHapiValues } from "./store/hapiSlice";
import MouseCanvasComponent from "../hapi_page/MouseAssistCanvas";
import { base64ToImageUrl } from "../utils/setDutdetails";
import SwipeCanvasComponent from "../hapi_page/SwipeCanvas";
import ScreenElementsComponent from "../hmi_page/ScreenElementsCanvas";
import drawLineWithArrow from "../assest/utils/swipearrow";


const LiveCameraFeed = forwardRef((props, ref) => {
  const videoCanvasRef = useRef(null); // Canvas for the video feed
  const drawCanvasRef = useRef(null); // Canvas for drawing when drawable is true
  const elementReft = useRef(null); // Canvas for drawing when drawable is false
  const cropCanvasRef = useRef(null); // Canvas for cropping
  const containerRef = useRef(null); //canvas for draw screen and elements
  const globalCanvasRef = useRef(null); //canvas for global navigation
  
  const [sX, setSX] = useState(null);
  const [sY, setSY] = useState(null);
  const [eX, setEX] = useState(null);
  const [eY, setEY] = useState(null);


  const [isDrawing, setIsDrawing] = useState(false);
  const [isSwipe, setIsSwipe] = useState(false);
  const [endX, setEndX] = useState(0);
  const [endY, setEndY] = useState(0);
  const [canvasRect, setCanvasRect] = useState({});
  const [container, setContainer] = useState({});
  const [lastRect, setLastRect] = useState(null); // Track the last drawn rectangle
  const { wsStatus } = useSelector((state) => state.loading); // Track WebSocket status
  const { gDuration, gBackposition, gForce } = useSelector(
    (state) => state.globalParameters
  );
  const dispatch = useDispatch();

  const { buttons, screens, elements , ocr} = useSelector((state) => state.page);

  const selectedState = useSelector((state) =>
    buttons ? state.dutButtons : state.dutScreen
  );

  // Destructure the selected state
  const { startX, startY, width, height } = selectedState;

  const vFeed = useSelector((state) => state.vFeed);
  const wsRef = useRef(null);
  // console.log(vFeed)

  useEffect(() => {
    if (videoCanvasRef.current) {
      if (lastRect) {
        redrawRectangle();
      }
    }
  }, []);

  useEffect(() => {
    if (startX && startY && width && height) {
      setTimeout(() => {
        redrawRectangle();
      }, 100);
    }
    const updateCanvasRect = () => {
      if (containerRef.current) {
        setContainer(containerRef.current);
        setCanvasRect(containerRef.current.getBoundingClientRect());
      }
    };
    updateCanvasRect();
    window.addEventListener("resize", updateCanvasRect);

    return () => {
      window.removeEventListener("resize", updateCanvasRect);
    };
  }, [
    selectedState,
    vFeed.globalNavigationEnabled,
    buttons,
    screens,
    vFeed.MouseAssist,
  ]);

  useEffect(() => {
    if (lastRect && buttons) {
      const drawCanvas = vFeed.buttonDrawEnabled
        ? drawCanvasRef.current
        : elementReft.current;
      const drawContext = drawCanvas.getContext("2d");
      drawContext.clearRect(0, 0, drawCanvas.width, drawCanvas.height);
      drawContext.strokeStyle = "#2DB232";
      drawContext.lineWidth = 2;
      drawContext.strokeRect(startX, startY, width, height);
      setTimeout(() => {
        handleCrop();
      }, 1000);
    } else if (lastRect && screens) {
      console.log("test");
      const drawCanvas = vFeed.buttonDrawEnabled
        ? drawCanvasRef.current
        : elementReft.current;
      if(drawCanvas){
      const drawContext = drawCanvas.getContext("2d");
      drawContext.clearRect(0, 0, drawCanvas.width, drawCanvas.height);
      drawContext.strokeStyle = "#2DB232";
      drawContext.lineWidth = 2;
      drawContext.strokeRect(startX, startY, width, height);
    }
  }
    // console.log("buttons", buttons, "screens", screens);
  }, [selectedState, buttons, screens]);

  const redrawRectangle = () => {
    const canvas = vFeed.buttonDrawEnabled
      ? drawCanvasRef.current
      : elementReft.current;
    if (canvas) {
      const context = canvas.getContext("2d");
      context.clearRect(0, 0, canvas.width, canvas.height); // Clear the previous rectangle
      context.strokeStyle = "#2DB232";
      context.lineWidth = 2;
      context.strokeRect(startX, startY, width, height);
    }
  };

  const clearReactangle = () => {
    const canvas = vFeed.buttonDrawEnabled
      ? drawCanvasRef.current
      : elementReft.current;
    if(canvas){
      const context = canvas.getContext("2d");
      context.clearRect(0, 0, canvas.width, canvas.height);
    }
  };

  // Use useImperativeHandle to expose the clearReactangle method to the parent
  useImperativeHandle(ref, () => ({
    clearReactangle,
  }));

  const handleMouseDown = (event) => {
    const rect = videoCanvasRef.current.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;

    if (buttons) {
      dispatch(setParams({ startX: Math.floor(Math.max(x)), startY:  Math.floor(Math.max(y)) }));
    } else if (screens) {
      dispatch(setParamsSCreen({ startX: Math.floor(Math.max(x)), startY: Math.floor(Math.max(y)) }));
    }

    setIsDrawing(true);
    setEndX(x);
    setEndY(y);
    setLastRect(null);

    const drawCanvas = drawCanvasRef.current;
    const context = drawCanvas.getContext("2d");
    drawCanvas.style.cursor = "crosshair";
    context.clearRect(0, 0, drawCanvas.width, drawCanvas.height);
  };

  const handleMouseMove = (event) => {
    if (!isDrawing) return;

    const rect = videoCanvasRef.current.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;

    setEndX(x);
    setEndY(y);

    const drawCanvas = drawCanvasRef.current;
    const context = drawCanvas.getContext("2d");
    context.clearRect(0, 0, drawCanvas.width, drawCanvas.height);
    context.strokeStyle = "green";
    context.lineWidth = 2;
    context.strokeRect(startX, startY, x - startX, y - startY);
  };

  const handleMouseUp = () => {
    setIsDrawing(false);
    drawCanvasRef.current.style.cursor = "default";
    const newRect = {
      startX,
      startY,
      width:  Math.floor(Math.max(endX - startX, 0)),
      height: Math.floor(Math.max(endY - startY, 0)),
    };

    setLastRect(newRect);
    if (buttons) {
      dispatch(setParams(newRect)); // Update the redux state
    } else if (screens) {
      dispatch(setParamsSCreen(newRect));
    }

    // Optionally dispatch to disable button drawing
    if (vFeed.buttonDrawEnabled) {
      setTimeout(() => {
        dispatch(disableVideoFeedCanvas("buttonDrawEnabled"));
      }, 2000);
    }
  };



  const handleCrop = async () => {
    if (!lastRect) {
      console.error("No rectangle found for cropping.");
      return;
    }

    let { startX, startY, width, height } = lastRect;

    try {
      cropImageApi(startX, startY, width, height).then((res) => {
        if (vFeed.buttonDrawEnabled) {
          const croppedImageURL = base64ToImageUrl(res.cropped_image_base64);
          dispatch(setParams({ imgurl: croppedImageURL }));
        }
      });
    } catch (error) {
      console.error("Error during cropping:", error);
    }
  };



  // Handle left click
  const handleLeftClick = (event) => {
    event.preventDefault(); // Prevent any default behavior if needed

    const x = event.clientX - canvasRect.left + container.scrollLeft;
    const y = event.clientY - canvasRect.top + container.scrollTop;

    dispatch(setWsStatus("robot moving "));
    onClikNavigationLeft(x, y)

  };

  // Handle right click
  const handleRightClick = (event) => {
    event.preventDefault(); // Prevent the default context menu from appearing

    const x = event.clientX - canvasRect.left + container.scrollLeft;
    const y = event.clientY - canvasRect.top + container.scrollTop;

    dispatch(setWsStatus("robot moving "));

    onClikNavigationRight(x, y, gDuration, gBackposition, gForce)

  };

  const handleMouseDownSwipe = (event) =>{
    const x = event.clientX - canvasRect.left + container.scrollLeft;
    const y = event.clientY - canvasRect.top + container.scrollTop;
    if (event.button !== 0) {
      return; // Exit if it's not a left-click (button 0)
    }
    setIsSwipe(true)
    setSX(x)
    setSY(y)
  }

  const handleMouseMoveSwipe = (event) =>{
    if (event.button !== 0) {
      return; // Exit if it's not a left-click (button 0)
    }
    const x = event.clientX - canvasRect.left + container.scrollLeft;
    const y = event.clientY - canvasRect.top + container.scrollTop;
    setEX(x)
    setEY(y)
    if(isSwipe){
      const ctx = globalCanvasRef.current.getContext("2d");
      ctx.clearRect(0, 0, 1920, 1080); // Clear previous drawings
      drawLineWithArrow(ctx , sX ,sY , x, y)
    }
  }

  const handleMouseUpSwipe = (event) =>{
    if (event.button !== 0) {
      return; // Exit if it's not a left-click (button 0)
    }
    setIsSwipe(false)
   const width = Math.floor(eX - sX)
   const height = Math.floor(eY - sY)

   const ctx = globalCanvasRef.current.getContext("2d");
   ctx.clearRect(0, 0, 1920, 1080); // Clear previous drawings

   if(width === 0 && height ===0 && event.button === 0){
    onClikNavigationLeft(sX, sY)
   }else{
   const cmd = `s:${Math.round(sX)}:${Math.round(sY)}:${Math.round(eX)}:${Math.round(eY)}:${1500}:${100}`
   swipeCommandApi(cmd)
   }
  }
  return (
    <>
      <Box
        sx={{
          bgcolor: "#E4E7ED",
          display: "flex",
          overflow: "auto",
          position: "relative",
          width: "100%",
          height: "100%",
        }}
        ref={containerRef}
      >
        <>
          <img
            src={`${process.env.REACT_APP_BASE_VD_URL}/my_camera`}
            // src={dut}
            width={1920}
            height={1080}
            alt="video"
            id="video-stream"
            // crossOrigin="anonymous"
            style={{
              display: "block",
              position: "absolute",
              zIndex: 2,
              objectFit: "contain", // Maintain aspect ratio, don't stretch
            }}
          />
          <canvas
            ref={videoCanvasRef}
            width={1920}
            height={1080}
            style={{
              display: "block",
              position: "absolute",
              zIndex: 2,
            }}
          />
        {(elements || ocr ) &&  <ScreenElementsComponent
            ref={drawCanvasRef}
            rect={{ startX, startY, width, height }}
            width={1920}
            height={1080}
            canvasRect={canvasRect}
            container={container}
          /> }
        </>
        {vFeed.buttonDrawEnabled ? (
          <canvas
            ref={drawCanvasRef}
            width={1920}
            height={1080}
            style={{
              display: "block",
              position: "absolute",
              zIndex: 2,
              cursor: "crosshair",
            }}
            onMouseDown={handleMouseDown}
            onMouseMove={handleMouseMove}
            onMouseUp={handleMouseUp}
          />
        ) : vFeed.globalNavigationEnabled ? (
          <canvas
            ref={globalCanvasRef}
            width={1920}
            height={1080}
            top={100}
            style={{
              display: "block",
              position: "absolute",
              zIndex: 4,
              cursor: "pointer",
            }}
            onClick={handleLeftClick} // Left click handler
            onContextMenu={handleRightClick} // Right click handler
            // onMouseDown={handleMouseDownSwipe}
            // onMouseMove={handleMouseMoveSwipe}
            // onMouseUp={handleMouseUpSwipe}
          />
        ) : vFeed.MouseAssist ? (
          <MouseCanvasComponent
            ref={globalCanvasRef}
            width={1920}
            height={1080}
            top={100}
            canvasRect={canvasRect}
            container={container}
          />
        ) : vFeed.swipeCanvas ? (
          <SwipeCanvasComponent
            ref={globalCanvasRef}
            width={1920}
            height={1080}
            top={100}
            canvasRect={canvasRect}
            container={container}
          />
        ) : (
          <canvas
            ref={elementReft}
            width={1920}
            height={1080}
            style={{ display: "block", position: "absolute", zIndex: 2 }}
          />
        )}
        <canvas ref={cropCanvasRef} style={{ display: "none" }} />
        {/* {!wsStatus && (
          <h6 style={{ color: "red" }}>error connecting to video feed</h6>
        )} */}
        {/* <LoadingScreenModal loading={wsStatus} message={wsStatus} /> */}
      </Box>
    </>
  );
});

export default LiveCameraFeed;
