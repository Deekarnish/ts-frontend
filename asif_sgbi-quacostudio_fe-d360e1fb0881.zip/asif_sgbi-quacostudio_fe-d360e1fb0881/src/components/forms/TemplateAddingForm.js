import React, { useEffect, useState } from "react";
import {
  Box,
  Button,
  TextField,
  FormControl,
  InputLabel,
  Autocomplete,
} from "@mui/material";
import { useForm, Controller } from "react-hook-form";
import { useDispatch, useSelector } from "react-redux";
import { getDutTypes } from "../store/dutTypesSlice";

import { postTemplate, updateTemplate, duplicateTemplate } from "../store/templateSlice";
import { setOpenTemplate, setTypeTemplateModal } from "../store/templateModalSlice";

const TemplateForm = ({ isEditMode, initialValues }) => {
  const dispatch = useDispatch();
  const { data: dutTypes } = useSelector((state) => state.dutTypes);
  const { control, handleSubmit, reset, watch } = useForm({ defaultValues: initialValues || {} });
  
  const [templateName, setTemplateName] = useState("");

  useEffect(() => {
    dispatch(getDutTypes());
    if (isEditMode) {
      reset(initialValues);
    }
  }, [isEditMode, initialValues, dispatch, reset]);

  const onSubmit = (data) => {
    if (isEditMode === "edit") {
      dispatch(updateTemplate(data));
    } else if (isEditMode === "duplicate") {
      dispatch(duplicateTemplate(data));
    } else {
      dispatch(postTemplate(data));
    }
    dispatch(setOpenTemplate(false));
  };

  return (
    <Box component="form" onSubmit={handleSubmit(onSubmit)} sx={{ p: 3 }}>
      {/* Template Name Input */}
      <FormControl fullWidth sx={{ mb: 2 }}>
        <Controller
          name="templateName"
          control={control}
          render={({ field }) => (
            <TextField
              {...field}
              label="Template Name"
              variant="outlined"
              fullWidth
              value={templateName}
              onChange={(e) => {
                field.onChange(e);
                setTemplateName(e.target.value);
              }}
              sx={{
                "& .MuiOutlinedInput-root": {
                  "& fieldset": {
                    borderColor: 'rgba(0, 0, 0, 0.23)', // Default border color
                  },
                  "&:hover fieldset": {
                    borderColor: '#0075FF', // Border color on hover
                  },
                  "&.Mui-focused fieldset": {
                    borderColor: '#0075FF', // Border color when focused
                  },
                },
              }}
            />
          )}
        />
      </FormControl>

      {/* DUT Selection Dropdown with Search */}
      <FormControl fullWidth sx={{ mb: 2 }}>
        <Controller
          name="dutId"
          control={control}
          render={({ field }) => (
            <Autocomplete
              {...field}
              options={dutTypes}
              getOptionLabel={(option) => option.type}
              value={dutTypes.find((dut) => dut.id === field.value) || null}
              onChange={(event, newValue) => {
                field.onChange(newValue ? newValue.id : "");
              }}
              renderInput={(params) => (
                <TextField
                  {...params}
                  label="Select DUT"
                  variant="outlined"
                  fullWidth
                />
              )}
              sx={{ 
                "& .MuiOutlinedInput-root": {
                  "& fieldset": {
                    borderColor: 'rgba(0, 0, 0, 0.23)', // Default border color
                  },
                  "&:hover fieldset": {
                    borderColor: '#0075FF', // Border color on hover
                  },
                  "&.Mui-focused fieldset": {
                    borderColor: '#0075FF', // Border color when focused
                  },
                },
              }}
            />
          )}
        />
      </FormControl>

      {/* Action Buttons */}
      <Box sx={{ textAlign: "right", mt: 2 }}>
        <Button
          variant="outlined"
          onClick={() => dispatch(setOpenTemplate(false))}
          sx={{ mr: 2 , bgcolor:"red" }}
        >
          Cancel
        </Button>
        <Button type="submit" variant="contained" sx={{ bgcolor: "#0075FF" }}>
          {isEditMode ? (isEditMode === "duplicate" ? "Duplicate" : "Save") : "Create"}
        </Button>
      </Box>
    </Box>
  );
};

export default TemplateForm;
