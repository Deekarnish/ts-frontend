import {
  useTheme,
  useMediaQuery,
  Grid,
  Typography,
  Input,
} from "@mui/material";
import {
  Button,
  Box,
  TextField,
  Select,
  MenuItem,
  FormControl,
  InputLabel,
  FormHelperText,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import { useForm, Controller } from "react-hook-form";
import { convertLBH } from "../../utils/funcs";
import { useDispatch, useSelector } from "react-redux";
import { postDuts, updateDut } from "../store/dutSlice";
import { getDutTypes } from "../store/dutTypesSlice";
import DialogContent from "@mui/material/DialogContent";
import { setOpenModal } from "../store/dutModalSlice";
import { setDutDetails } from "../store/dutDetailsSlice";

const DutAddingForm = (props) => {
  const { isEditMode, initialValues } = props;
  const theme = useTheme();

  const dispatch = useDispatch();
  const { status, error } = useSelector((state) => state.duts);
  const { data: dutTypes } = useSelector((state) => state.dutTypes);
  const [dutname, setDutName] = useState("");
  const dut = useSelector((state) => state.dutDetails);
  const [isReadOnly , setIsReadOnly] = useState(false)
  const [values, setValues] = useState(initialValues);

  const isXs = useMediaQuery(theme.breakpoints.only("xs"));

  const textFieldStyle = {
    m: 1,
    mt: 0,
    mb: 0,
    borderRadius: 2,
    fontSize: 12,
    backgroundColor: "#E9F3FC",
    "& .MuiOutlinedInput-root": {
      "& fieldset": {
        border: "none",
      },
      "&:hover fieldset": {
        border: "none",
      },
      "&.Mui-focused fieldset": {
        border: "none",
      },
    },
    "& .MuiInputBase-root": {
      height: "35px",
    },
    "& .MuiInputLabel-root": {
      fontSize: "0.7rem",
      top: "-5px",
      // color: hasError ? 'red' : 'inherit',
    },
    "& .MuiInputLabel-shrink": {
      display: "none",
    },
  };

  const labelTypoGrapgyStyle = {
    fontSize: 13,
    ml: 1,
    color: "#4B4B50",
  };
  useEffect(() => {
    dispatch(getDutTypes());
    if (isEditMode && isEditMode !== "info") {
      const LBH = convertLBH(initialValues.lbh);
      let initialValuesWithLBH = { ...initialValues, ...LBH };
      setValues(initialValuesWithLBH);
    }
  }, []);

  const {
    register,
    handleSubmit,
    watch,
    formState: { errors },
    control,
    reset,
  } = useForm({ defaultValues: isEditMode ? values : {} });
  const watchedManufacturer = watch("manufacturer");
  const watchedModelNumber = watch("model_number");
  const watchedFirmWareVersion = watch("firmware_version");
  useEffect(() => {
    setDutName(
      `${watchedManufacturer}-${watchedModelNumber}-${watchedFirmWareVersion}`
    );
  }, [watchedManufacturer, watchedModelNumber, watchedFirmWareVersion]);

  useEffect(() => {
    if (isEditMode === "info") {
      const LBH = convertLBH(dut.lbh);
      let initialValuesWithLBH = { ...dut, ...LBH };
      setValues(initialValuesWithLBH);
      reset(initialValuesWithLBH);
      setIsReadOnly(true)
    }
    if (isEditMode) {
      reset(values);
    }
  }, [isEditMode]);

  const onSubmit = async (data) => {
    let lbh = `${data.length}:${data.breadth}:${data.height}`;
    let name = `${data.manufacturer}-${data.model_number}-${data.firmware_version}`;
    if (isEditMode === "duplicate") {
      name = name + "-copy";
    }
    let newData = { ...data, lbh: lbh, name: name };
    if (isEditMode === "edit") {
      dispatch(updateDut({ id: data.id, data: newData }));
      dispatch(setOpenModal(false));
      //   console.log(data);
    } else {
      dispatch(postDuts(newData));
      if (status === "idle") {
        dispatch(setOpenModal(false));
        
      } else if (error) {
        console.log(error.detail);
        // alert(error.detail);
        // dispatch(setOpenModal(false));
      }
    }
  };

  return (
    <Box>
      <form
        onSubmit={handleSubmit((data) => {
          // console.log("handleSubmit called", data);
          onSubmit(data);
        })}
      >
        <DialogContent
          divider
          sx={{
            boxShadow: `0px -2px 4px #CDE5FA, 0px 4px 6px #CDE5FA`,
            m: 1,
            borderRadius: 2,
          }}
        >
          <Grid container spacing={2}>
            {/* Manufacturer and Serial Number Fields */}
            <Grid item xs={12} sm={6}>
              <Typography variant="body1" sx={labelTypoGrapgyStyle}>
                Manufacturer
              </Typography>
              <TextField
                id="outlined-basic"
                name="manufacturer"
                label="Manufacturer"
                fullWidth
                {...register("manufacturer", {
                  required: "DUT Manufacturer required",
                })}
                error={Boolean(errors.manufacturer)}
                sx={textFieldStyle}
                autoComplete="off"
                InputProps={{
                  readOnly: isReadOnly, // Conditionally set the form field to read-only
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="body1" sx={labelTypoGrapgyStyle}>
                Serial Number
              </Typography>
              <TextField
                id="outlined-basic"
                name="serial_number"
                label="Serial Number"
                fullWidth
                {...register("serial_number", {
                  required: "DUT serial required",
                })}
                error={Boolean(errors.serial_number)}
                sx={textFieldStyle}
                autoComplete="off"
                InputProps={{
                  readOnly: isReadOnly, // Conditionally set the form field to read-only
                }}
              />
            </Grid>

            {/* Firmware Version and Model Number Fields */}
            <Grid item xs={12} sm={6}>
              <Typography variant="body1" sx={labelTypoGrapgyStyle}>
                Firmware Version
              </Typography>
              <TextField
                id="outlined-basic"
                name="firmware_version"
                label="Firmware Version"
                fullWidth
                {...register("firmware_version", {
                  required: "DUT firmware version required",
                })}
                error={Boolean(errors.firmware_version)}
                sx={textFieldStyle}
                autoComplete="off"
                InputProps={{
                  readOnly: isReadOnly, // Conditionally set the form field to read-only
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="body1" sx={labelTypoGrapgyStyle}>
                Model Number
              </Typography>
              <TextField
                id="outlined-basic"
                name="model_number"
                label="Model Number"
                fullWidth
                {...register("model_number", {
                  required: "Model number required",
                })}
                error={Boolean(errors.model_number)}
                sx={textFieldStyle}
                autoComplete="off"
                InputProps={{
                  readOnly: isReadOnly, // Conditionally set the form field to read-only
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="body1" sx={labelTypoGrapgyStyle}>
                Name
              </Typography>
              <Controller
                name="name"
                control={control}
                defaultValue=""
                // rules={{ required: "Name is required" }}
                render={({ field }) => (
                  <TextField
                    {...field}
                    id="outlined-basic"
                    label="Name"
                    fullWidth
                    error={Boolean(errors.name)}
                    sx={textFieldStyle}
                    autoComplete="off"
                    value={dutname}
                    onChange={(e) => {
                      field.onChange(e);
                      setDutName(e.target.value);
                      
                    }}
                    InputProps={{
                      readOnly: isReadOnly, // Conditionally set the form field to read-only
                    }}
                  />
                )}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <Typography variant="body1" sx={labelTypoGrapgyStyle}>
                Type
              </Typography>
              <FormControl
                fullWidth
                error={Boolean(errors.type)}
                variant="outlined"
                sx={textFieldStyle}
              >
                <InputLabel id="type-label">Type</InputLabel>
                <Controller
                  name="dut_type_id"
                  control={control}
                  defaultValue=""
                  // rules={{ required: "DUT type required" }}
                  render={({ field }) => (
                    <Select
                      {...field}
                      labelId="type-label"
                      id="type"
                      label="Type"
                      InputProps={{
                        readOnly: isReadOnly, // Conditionally set the form field to read-only
                      }}
                    >
                      {dutTypes.map((type, index) => (
                        <MenuItem key={index} value={type.id}>
                          {type.type}
                        </MenuItem>
                      ))}
                    </Select>
                  )}
                />
                {/* <FormHelperText>{errors.type?.message}</FormHelperText> */}
              </FormControl>
            </Grid>
            {/* Height, Length, and Breadth Fields in a Single Line */}
            <Grid item xs={12}>
              <Grid container spacing={2}>
                <Grid item xs={4}>
                  <Typography variant="body1" sx={labelTypoGrapgyStyle}>
                    Height <span style={{color:"#96989B" ,fontSize:10}}>(mm)</span> 
                  </Typography>
                  <Controller
                    name="height"
                    control={control}
                    defaultValue=""
                    rules={{
                      required: "DUT height required",
                      validate: (value) =>
                        Number.isInteger(Number(value)) ||
                        "Please enter a valid integer",
                    }}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        id="outlined-basic"
                        label="Height"
                        type="number"
                        fullWidth
                        error={Boolean(errors.height)}
                        // helperText={errors.height ? errors.height.message : ""}
                        inputProps={{ min: 0 }}
                        sx={textFieldStyle}
                        autoComplete="off"
                        InputProps={{
                          readOnly: isReadOnly, // Conditionally set the form field to read-only
                        }}
                      />
                    )}
                  />
                </Grid>
                <Grid item xs={4}>
                  <Typography variant="body1" sx={labelTypoGrapgyStyle}>
                    Length <span style={{color:"#96989B" ,fontSize:10}}>(mm)</span>
                  </Typography>
                  <Controller
                    name="length"
                    control={control}
                    defaultValue=""
                    rules={{
                      required: "DUT length required",
                      validate: (value) =>
                        Number.isInteger(Number(value)) ||
                        "Please enter a valid integer",
                    }}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        id="outlined-basic"
                        label="Length"
                        type="number"
                        fullWidth
                        error={Boolean(errors.length)}
                        // helperText={errors.length ? errors.length.message : ""}
                        inputProps={{ min: 0 }}
                        sx={textFieldStyle}
                        autoComplete="off"
                        InputProps={{
                          readOnly: isReadOnly, // Conditionally set the form field to read-only
                        }}
                      />
                    )}
                  />
                </Grid>
                <Grid item xs={4}>
                  <Typography variant="body1" sx={labelTypoGrapgyStyle}>
                    Breadth <span style={{color:"#96989B" ,fontSize:10}}>(mm)</span>
                  </Typography>
                  <Controller
                    name="breadth"
                    control={control}
                    defaultValue=""
                    rules={{
                      required: "DUT breadth required",
                      validate: (value) =>
                        Number.isInteger(Number(value)) ||
                        "Please enter a valid integer",
                    }}
                    render={({ field }) => (
                      <TextField
                        {...field}
                        id="outlined-basic"
                        label="Breadth"
                        type="number"
                        fullWidth
                        error={Boolean(errors.breadth)}
                        // helperText={errors.breadth ? errors.breadth.message : ""}
                        inputProps={{ min: 0 }}
                        sx={textFieldStyle}
                        autoComplete="off"
                        InputProps={{
                          readOnly: isReadOnly, // Conditionally set the form field to read-only
                        }}
                      />
                    )}
                  />
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </DialogContent>
        {isEditMode !== "info" && (
          <Box sx={{ width: "95%", textAlign: "right", mb: 1 }}>
            <Button
              type="button"
              variant="contained"
              sx={{
                bgcolor: "white",
                mr: 1,
                border: "1px solid black",
                borderRadius: 2,
                height: 33,
                color: "black",
                textTransform: "none",
              }}
              onClick={() => dispatch(setOpenModal(false))}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              variant="contained"
              sx={{
                background: "#0075FF",
                color: "white",
                textTransform: "none",
                height: 35,
                borderRadius: 2,
              }}
            >
              {isEditMode ? "Save" : "Create"}
            </Button>
          </Box>
        )}
      </form>
    </Box>
  );
};

export default DutAddingForm;
