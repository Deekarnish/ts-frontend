import { Box } from '@mui/material';

const CustomBoxScrollbar = ({ children }) => {
  return (
    <Box
      sx={{
        flexDirection: "column",
        p: 1,
        maxHeight: 300,
        textAlign: "left",
        overflowY: "auto",
        "&::-webkit-scrollbar": {
            width: "7px", // Width of the scrollbar
          },
          "&::-webkit-scrollbar-track": {
            backgroundColor: "#f1f1f1", // Background of the track
          },
          "&::-webkit-scrollbar-thumb": {
            backgroundColor: "#cccc", // Color of the scrollbar thumb
            borderRadius: "8px", // Rounded corners of the thumb
          },
          "&::-webkit-scrollbar-thumb:hover": {
            backgroundColor: "#cccccc", // Color when hovered
        },
      }}
    >
      {children}
    </Box>
  );
};

export default CustomBoxScrollbar;
