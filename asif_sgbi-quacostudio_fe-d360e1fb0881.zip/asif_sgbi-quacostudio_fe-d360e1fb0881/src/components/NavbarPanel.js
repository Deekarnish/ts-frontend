import AppBar from "@mui/material/AppBar";
import Stack from "@mui/material/Stack";
import Toolbar from "@mui/material/Toolbar";
import { ThemeProvider, createTheme } from "@mui/material/styles";
import IconButton from "@mui/material/IconButton";
import sastralogo from "../assest/logos/Sastra Logo.png";
import { Box, Menu, MenuItem, Button } from "@mui/material";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import { useEffect, useRef, useState } from "react";
import ArrowForwardIosOutlinedIcon from "@mui/icons-material/ArrowForwardIosOutlined";
import { useTheme } from "@emotion/react";

import adjustIconD from "../assest/icons/global_toolbar_icons/adjustIcon.svg"
import adjustIconL from "../assest/icons/global_toolbar_icons/adjusiconlight.svg"
import rotateIconD from "../assest/icons/global_toolbar_icons/rotate.svg"
import rotateIconL from "../assest/icons/global_toolbar_icons/rotatelight.svg"
import targetIconD from "../assest/icons/global_toolbar_icons/ProtectionTarget.svg"
import targetIconL from "../assest/icons/global_toolbar_icons/protectionTargetLight.svg"
import lightbulbL from "../assest/icons/global_toolbar_icons/lightbulblight.svg"
import lightbulbD from "../assest/icons/global_toolbar_icons/LightBulb.svg"
import fourarrowD from "../assest/icons/global_toolbar_icons/fourarrow.svg"
import fourarrowL from "../assest/icons/global_toolbar_icons/fourarrowlight.svg"
import cameraIconD from "../assest/icons/global_toolbar_icons/camera.svg"
import cameraIconL from "../assest/icons/global_toolbar_icons/cameralight.svg";
import cursorHandD from "../assest/icons/global_toolbar_icons/cursorHand.svg"
import cursorHandL from "../assest/icons/global_toolbar_icons/cursorHandLight.svg"

import globeIcon from "../assest/icons/rotateglobe.svg";
import rotatecam from "../assest/icons/rotateCam.svg";
import phoneicon from "../assest/icons/phoneicon.svg";
import rotatePhone from "../assest/icons/rotatephone.svg";
import { useDispatch, useSelector } from "react-redux";
import {updateBackPosition , updateForce, updateDuration} from "./store/globalParamsSlice"
import UpArrow, {
  DownArrow,
  LeftArrow,
  RightArrow,
} from "../assest/utils/arrows";
import { useLocation, useNavigate } from "react-router-dom";
import { setOpenModal, setTypeModal } from "./store/dutModalSlice";
import { enableFeature, setClear, setFeature, setPage } from "./store/pageSlice";
import navigationApis, { robotMovementApi } from "../api/navigationApis";
import { disableAllAndEnableFeature, disableVideoFeedCanvas, enableVideoFeedCanvas, resetAllCanvas } from "./store/videoFeedSlice";
import { setFeatureExpand } from "./store/hmiOptionsSlice";
import { setWsStatus } from "./store/ApiLoadingSlice";
import { getDuts } from "./store/dutSlice";
import { clearState } from "./store/dutButtonSlice";
import { clearScreenState } from "./store/dutScreenSlice";
import { clearElementState } from "./store/dutElementSlice";
import { clearOcrState } from "./store/ocrSlice";

const menusx = {
  "&:hover": {
    borderRadius: 2,
    background: "#0075FF",
    color:"#FEFEFE"
  },
};
const nvIcons = {
  pt: 0.5,
  pl: 1,
  pr: 1,
  
  "&:hover": {
    borderRadius: 2,
    color: "white",
    background:"#CDE5FA",
  },
};
const nvIconsActive = {
  pt: 0.5,
  pl: 1,
  pr: 1,
  "&:hover": {
    borderRadius: 2,
    color: "white",   
  },
  background: "linear-gradient(135deg, #33BFFF -26.25%, #5D5CE5 93.75%)",
  borderRadius: 2,
};

const menuItemStyle = {
  display: "inline-flex",
  width: "auto",
  padding: 0.9,
  borderRadius: 2,
  m: 0.3,
  mt: 0,
  bgcolor: "#CDE5FA",
  // padding: '8px 16px',
  "&:hover": {
    background:
      "linear-gradient(90deg, rgba(11,139,217,1) 0%, rgba(46,114,195,1) 72%, rgba(65,101,240,1) 99%)",
  },
};

const stepItemStyle = {
  display: "inline-flex",
  width: "auto",
  padding: 0.9,
  borderRadius: 2,
  pl: 2,
  pr: 2,
  ml: 1,
  border: "1px solid #3391FF",
  // m: 0.3,
  bgcolor: "#CDE5FA",
  // padding: '8px 16px',
  "&:hover": {
    background: "none",
  },
};

const stepItemStyleCam = {
  display: "inline-flex",
  width: "auto",
  padding: 0.9,
  borderRadius: 2,
  // pl: 2,
  // pr: 2,
  // ml: 1,
  border: "1px solid #3391FF",
  // m: 0.3,
  bgcolor: "#CDE5FA",
  // padding: '8px 16px',
  "&:hover": {
    background: "none",
  },
};

const initialState = {
  target: false,
  rotate: false,
  bulbicon: false,
  cursorhand: false,
  camera: false,
  fourarrow: false,
  adjust: false,
};

function AppBarLabel(label) {
  // State and handlers for the dropdown menu
  const theme = useTheme();
  const [anchorEl, setAnchorEl] = useState(null);
  const [anchorEl2, setAnchorEl2] = useState(null);
  const [menuItems, setMenuItems] = useState([]);
  const [subMenuAnchorEl, setSubMenuAnchorEl] = useState(null);
  const [active, setActive] = useState(initialState);
  const [step ,setStep] = useState(20)

  const currentPage = useSelector((state) => state.page.currentPage);

  const vFeed = useSelector(state => state.vFeed)
  const location = useLocation();
  const dispatch = useDispatch();
  const navigate = useNavigate();

  const handleMenuClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  useEffect(() => {
    dispatch(setPage(location.pathname));
  }, [location]);

  const handleMenuClose = () => {
    setAnchorEl(null);
    setSubMenuAnchorEl(null); // Close sub menu as well
  };

  const handleSubMenuOpen = (event) => {
    setSubMenuAnchorEl(event.currentTarget);
  };

  const handleSubMenuClose = () => {
    setSubMenuAnchorEl(null);
  };
  const handleClick = (event, name, items) => {
    setAnchorEl2(event.currentTarget);
    setMenuItems(items);

    setActive((prevActive) => ({
      ...initialState,
      [name]: !prevActive[name],
    }));
     if(active.fourarrow){
      dispatch(disableAllAndEnableFeature('adjustNavigationEnabled'))
     }else{
      dispatch(disableVideoFeedCanvas('adjustNavigationEnabled'))
     }
  };

  const handleClose = () => {
    setAnchorEl2(null);
    dispatch(disableVideoFeedCanvas('adjustNavigationEnabled'))
    setActive((previous)=>({
      ...initialState,
    }))
  };

  const ButtonActiveStyle = {
    background: "linear-gradient(135deg, #33BFFF -26.25%, #5D5CE5 93.75%)",
    textTransform: "none",
    borderRadius: 2,
    color: "white",
  };

  const ButttonNormalStyle = {
    textTransform: "none",
    bgcolor: "none",
    boxShadow: "none",
  };

  const menus = {
    target: [
      { name: "up", icon: <UpArrow /> },
      { name: "down", icon: <DownArrow /> },
      { name: "left", icon: <LeftArrow /> },
      { name: "right", icon: <RightArrow /> },
    ],
    rotate: [],
    bulbicon: [],
    cursorhand: [],
    camera: [],
    fourarrow: [],
    adjust: [],
  };

  const Navigation = ({ step , setStep}) => {
    const handleSetStep = (e) =>{
      let value = Number(e.target.value)
      setStep(value)
    
    }
    const handleMoveRobot = (step,name) =>{
      dispatch(setWsStatus("robot moving"))
      robotMovementApi(step,name)
      .then((response) => {
        dispatch(setWsStatus(false));
      })
      .finally(() => {
        dispatch(setWsStatus(false));
      })
      .catch(() => {
        dispatch(setWsStatus(false));
      });
    }
    return (
      <>
        {menus.target.map((item, index) => (
          <MenuItem key={index} onClick={e=>handleMoveRobot(step,item.name)} sx={menuItemStyle}>
            {item.icon}
          </MenuItem>
        ))}
        <MenuItem
          sx={{
            display: "inline-flex",
            p: 0,
            "&:hover": {
              background: "none",
            },
            fontSize: "12px",
          }}
        >
          Step (mm)
          <Box sx={stepItemStyle}>
            <input
              value={step}
              onChange={e=> handleSetStep(e)}
              type="number"
              style={{
                backgroundColor: "transparent",
                border: "none",
                width: 40,
                height:20
              }}
              onFocus={(e) => e.currentTarget.style.outline = "none"}
            />
          </Box>
        </MenuItem>

      </>
    );
  };

  const TouchParameter = () => {
    const  {gDuration, gBackposition, gForce} = useSelector((state)=>state.globalParameters)
    const dispatch = useDispatch()

    const handleChange = (e) =>{
      if(e.target.name === "backposition"){
        dispatch(updateBackPosition(e.target.value))
      }else if(e.target.name ==="duration"){
        dispatch(updateDuration(e.target.value))
      }else if(e.target.name ==="force"){
        dispatch(updateForce(e.target.value))
      }
    }
    return (
      <>
        <MenuItem
          sx={{
            display: "inline-flex",
            p: 0,
            "&:hover": {
              background: "none",
            },
            fontSize: "12px",
          }}
        >
          Duration (s)
          <Box sx={stepItemStyle}>
            <input
              value={gDuration}
              name="duration"
              style={{
                backgroundColor: "transparent",
                border: "none",
                width: 20,
              }}

              onFocus={(e) => e.currentTarget.style.outline = "none"}
              onChange={handleChange}
            />
          </Box>
        </MenuItem>
        <MenuItem
          sx={{
            display: "inline-flex",
            p: 0,
            ml: 1,
            "&:hover": {
              background: "none",
            },
            fontSize: "12px",
          }}
        >
          Back position (m)
          <Box sx={stepItemStyle}>
            <input
              value={gBackposition}
              name="backposition"
              style={{
                backgroundColor: "transparent",
                border: "none",
                width: 20,
              }}
              onFocus={(e) => e.currentTarget.style.outline = "none"}
              onChange={handleChange}
            />
          </Box>
        </MenuItem>
        <MenuItem
          sx={{
            display: "inline-flex",
            p: 0,
            ml: 1,
            "&:hover": {
              background: "none",
            },
            fontSize: "12px",
          }}
        >
          Force (N)
          <Box sx={stepItemStyle}>
            <input
              value={gForce}
              name="force"
              style={{
                backgroundColor: "transparent",
                border: "none",
                width: 20,
              }}
              onChange={handleChange}
              onFocus={(e) => e.currentTarget.style.outline = "none"}
            />
          </Box>
        </MenuItem>
      </>
    );
  };

  const CamerSwitching = ({ camera, orientation, exposure }) => {
    return (
      <>
        <MenuItem
          sx={{
            display: "inline-flex",
            p: 0,
            "&:hover": {
              background: "none",
            },
            fontSize: "12px",
          }}
        >
          <span style={{ marginRight: "5px" }}>Camera</span>
          <Box sx={stepItemStyleCam}>
            <img
              src={globeIcon}
              alt="arrow up"
              style={{ width: "24px", height: "24px" }}
            />
          </Box>
          <Box sx={stepItemStyleCam}>
            <img
              src={rotatecam}
              alt="arrow up"
              style={{ width: "24px", height: "24px" }}
            />
          </Box>
        </MenuItem>
        <MenuItem
          sx={{
            display: "inline-flex",
            p: 0,
            ml: 1,
            "&:hover": {
              background: "none",
            },
            fontSize: "12px",
          }}
        >
          <span style={{ marginRight: "5px" }}>Orientation</span>
          <Box sx={stepItemStyleCam}>
            <img
              src={phoneicon}
              alt="arrow up"
              style={{ width: "24px", height: "24px" }}
            />
          </Box>
          <Box sx={stepItemStyleCam}>
            <img
              src={rotatePhone}
              alt="arrow up"
              style={{ width: "24px", height: "24px" }}
            />
          </Box>
        </MenuItem>
        <MenuItem
          sx={{
            display: "inline-flex",
            p: 0,
            ml: 1,
            "&:hover": {
              background: "none",
            },
            fontSize: "12px",
          }}
        >
          Exposure (lx . s)
          <Box sx={stepItemStyle}>
            <input
              value={exposure}
              style={{
                backgroundColor: "transparent",
                border: "none",
                width: 20,
              }}
            />
          </Box>
        </MenuItem>
      </>
    );
  };

  const addNewDut = () => {
    dispatch(setOpenModal(true));
    dispatch(setTypeModal(false));
    handleSubMenuClose();
    handleMenuClose();
  };

  const handleChangePage = (page) => {
    navigate(page);
    dispatch(setPage(page));
    // dispatch(resetAll())
    dispatch(getDuts());
    dispatch(clearState())
    dispatch(clearScreenState())
    dispatch(clearElementState())
    dispatch(clearOcrState())
    dispatch(enableFeature(""))
    dispatch(resetAllCanvas())
  };

  const handlecallNavigationApis = (navigation ) =>{
    switch (navigation){
      case 'bulbicon':
        setActive((prevActive) => ({
          ...initialState,
          [navigation]: !prevActive[navigation],
        }));
        if(active[navigation]){
          navigationApis('/light_on')
        }else{
          navigationApis('/light')
        }
        break;
      case 'home':
        dispatch(setWsStatus('Robot homing'));
        navigationApis('/home/')
        .then((response) => {
          dispatch(setWsStatus(false));
        })
        .finally(() => {
          dispatch(setWsStatus(false));
        })
        .catch(() => {
          dispatch(setWsStatus(false));
        });
        break;
    }

    navigationApis()
  }

  const showDutInformations = () =>{
    setActive((prevActive) => ({
      ...initialState,
      ['adjust']: !prevActive['adjust'],
    }));
    dispatch(setTypeModal('info'))
    dispatch(setOpenModal(true))
    
  }

  const handleClickGlobal = (name)=>{
    setActive((prevActive) => ({
      ...initialState,
      [name]: !prevActive[name],
    }));
    if(active.target){
    // dispatch(disableAllAndEnableFeature('globalNavigationEnabled'))
    dispatch(setFeatureExpand({feature:"inspectorPanel",value:true}))
    dispatch(enableVideoFeedCanvas('globalNavigationEnabled'))
    dispatch(setFeature({feature:"elements" , value:false}))
    dispatch(setFeature({feature:"ocr" , value:false}))
    }else{
    dispatch(disableVideoFeedCanvas('globalNavigationEnabled'))
    dispatch(setFeatureExpand({feature:"inspectorPanel",value:false}))
    }
  }
  const clearCanvas = () =>{
     dispatch(clearOcrState())
     dispatch(clearScreenState())
     dispatch(clearState())
     dispatch(clearElementState())
     dispatch(setClear(true))
  }
  return (
    <Toolbar
      sx={{ height: 45, display: "flex", justifyContent: "space-between" }}
    >
      {/* Left side with logo */}
      <Box sx={{ display: "flex", alignItems: "center" }}>
        <IconButton
          sx={{
            p: 1,
            borderRadius: 8,
            backgroundColor: "transparent",
            "&:hover": {
              backgroundColor: "transparent",
              boxShadow: "none",
            },
            boxShadow: "none",
          }}
          onClick={(e) => {
            const isLogoClick = e.target.alt === "Logo";
            if (isLogoClick) {
              handleChangePage("/");
            } else {
              handleMenuClick(e); // Pass the event to handleMenuClick
            }
          }}
        >
          {/* Logo Component */}
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              cursor: "pointer",
            }}
          >
            <img
              src={sastralogo}
              alt="Logo"
              height="70"
              style={{ marginLeft: "-40px" }}
            />
          </Box>

          {/* Dropdown Arrow Component */}
          <Box
            sx={{
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              marginLeft: -5,
              cursor: "pointer",
            }}
          >
            <KeyboardArrowDownIcon />
          </Box>
        </IconButton>

        <Menu
          anchorEl={anchorEl}
          open={Boolean(anchorEl)}
          onClose={handleMenuClose}
          MenuListProps={{
            "aria-labelledby": "logo-button",
          }}
          sx={{ width: 350 }}
          PaperProps={{
            sx: {
              pl: 1,
              pr: 1,
              border: "1px solid #3391FF",
              borderRadius: 2,
            },
          }}
        >
       <MenuItem
            onClick={handleSubMenuOpen}
            sx={
              subMenuAnchorEl
                ? {
                    borderRadius: 2,
                    background: "#0075FF",
                    color:"#FEFEFE"
                  }
                : {
                    "&:hover": {
                      borderRadius: 2,
                      background: "#0075FF",
                      color:"#FEFEFE"
                    },
                  }
            }
          >
            New
            <ArrowForwardIosOutlinedIcon sx={{ ml: 8, fontSize: 18 }} />
          </MenuItem>
          <MenuItem onClick={handleMenuClose} sx={menusx}>
            Import
          </MenuItem>
          <MenuItem onClick={handleMenuClose} sx={menusx}>
            Export
          </MenuItem>
          <MenuItem onClick={handleMenuClose} sx={menusx}>
            Save
          </MenuItem>
          <MenuItem onClick={handleMenuClose} sx={menusx}>
            Save As
          </MenuItem>
          <MenuItem onClick={handleMenuClose} sx={menusx}>
            Properties
          </MenuItem>
        </Menu>
        {/* Sub Menu */}
        <Menu
          anchorEl={subMenuAnchorEl}
          open={Boolean(subMenuAnchorEl)}
          onClose={handleSubMenuClose}
          anchorOrigin={{
            vertical: "top",
            horizontal: "right",
          }}
          transformOrigin={{
            vertical: "top",
            horizontal: "left",
          }}
          PaperProps={{
            sx: {
              pl: 1,
              pr: 1,
              border: "1px solid #3391FF",
              borderRadius: 2,
            },
          }}
        >
          <MenuItem onClick={(e) => addNewDut()} sx={menusx}>
            DUT
          </MenuItem>
          <MenuItem onClick={handleSubMenuClose} sx={menusx}>
            Template
          </MenuItem>
        </Menu>
      </Box>
      {/* Middle with heading */}

      {/* if the the Current current page is hmi enavble the global toolbar options  */}
      {(currentPage === "/hmi" || currentPage === "/hapi" )&& (
        <Box
          sx={{
            boxShadow:"#8CC9FF  0px 0px 0.15em, #8CC9FF 0px 0.15em 0.5em",
            padding: 0.5,
            borderRadius: 2,
            display: "inline-flex",
            gap: 1,
            pl: 0.1,
            pr: 0.1,
          }}
          onClick={clearCanvas}
        >
          <Box
            sx={vFeed.globalNavigationEnabled ? nvIconsActive : nvIcons}
            onClick={(e) => handleClickGlobal('target')}
          >
            <img
              src={vFeed.globalNavigationEnabled ? targetIconL : targetIconD}
              alt="target icon"
              style={{ width: "24px", height: "24px" }}
            />
          </Box>
          <Box
            sx={vFeed.adjustNavigationEnabled ? nvIconsActive : nvIcons}
            onClick={(e) => handleClick(e, "fourarrow", menus.fourarrow)}
          >
            <img
              src={vFeed.adjustNavigationEnabled ? fourarrowL : fourarrowD}
              alt="four arrow Icon"
              style={{ width: "24px", height: "24px" }}
            />
          </Box>
          <Box
            sx={active.bulbicon ? nvIconsActive : nvIcons}
            onClick={(e) => handlecallNavigationApis('bulbicon')}
          >
            <img
              src={active.bulbicon ? lightbulbL : lightbulbD}
              alt="light Icon"
              style={{ width: "24px", height: "24px" }}
            />
          </Box>
          <Box
            sx={active.cursorhand ? nvIconsActive : nvIcons}
            onClick={(e) => handleClick(e, "cursorhand", menus.cursorhand)}
          >
            <img
              src={active.cursorhand ? cursorHandL : cursorHandD}
              alt="cursor hand  Icon"
              style={{ width: "24px", height: "24px"}}
            />
          </Box>
          <Box
            sx={active.camera ? nvIconsActive : nvIcons}
            onClick={(e) => handleClick(e, "camera", menus.camera)}
          >
            <img
              src={active.camera ?  cameraIconL : cameraIconD}
              alt="camera Icon"
              style={{ width: "24px", height: "24px" }}
            />
          </Box>
          <Box
            sx={active.rotate ? nvIconsActive : nvIcons}
            onClick={(e) => handlecallNavigationApis('home')}
          >
            <img
              src={active.rotate ? rotateIconL: rotateIconD}
              alt="rotate Icon"
              style={{ width: "24px", height: "24px" }}
            />
          </Box>
          <Box
            sx={active.adjust ? nvIconsActive : nvIcons}
            onClick={(e) => showDutInformations()}
          >
            <img
              src={active.adjust ? adjustIconL : adjustIconD}
              alt="adjut Icon"
              style={{ width: "24px", height: "24px" }}
            />
          </Box>
          { (vFeed.adjustNavigationEnabled || active.cursorhand || active.camera) && <Menu
            anchorEl={anchorEl2}
            open={Boolean(anchorEl2)}
            onClose={handleClose}
            anchorOrigin={{
              vertical: "top",
              horizontal: "center", // Center the anchor horizontally
            }}
            transformOrigin={{
              vertical: "top",
              horizontal: "center", // Center the transform horizontally
            }}
            PaperProps={{
              sx: {
                display: "flex",
                flexDirection: "row",
                pl: 1,
                pr: 1,
                mt: 6,
                borderRadius: 3,
              },
            }}
          >
            {vFeed.adjustNavigationEnabled && <Navigation step={step}  setStep={setStep}/>}
            {active.cursorhand && (
              <TouchParameter duration={"50"} bposition={"50"} force={"50"} />
            )}
            {active.camera && (
              <CamerSwitching
                camera={false}
                orientation={false}
                exposure={"50"}
              />
            )}
          </Menu> }
        </Box>
      )}
      {/* Right side with two buttons */}

      {/* enable HMI And HAPI Navigation toggle button In the HMI And Hapi page  */}

      {(currentPage === "/hmi" || currentPage === "/hapi") && (
        <Box
          sx={{
            boxShadow:"#8CC9FF  0px 0px 0.15em, #8CC9FF 0px 0.15em 0.5em",
            padding: 0.5,
            borderRadius: 2,
            display: "inline-flex",
          }}
        >
          <Button
            variant="contained"
            size="small"
            sx={currentPage == "/hmi" ? ButtonActiveStyle : ButttonNormalStyle}
            onClick={(e) => handleChangePage("/hmi")}
          >
            HMI
          </Button>
          <Button
            variant="contained"
            size="small"
            sx={currentPage == "/hmi" ? ButttonNormalStyle : ButtonActiveStyle}
            onClick={(e) => handleChangePage("/hapi")}
          >
            HAPI
          </Button>
        </Box>
      )}
    </Toolbar>
  );
}

// Create the dark theme
const darkTheme = createTheme({
  palette: {
    mode: "dark",
    primary: {
      main: "#000000",
    },
  },
});

// Create the light theme
const lightTheme = createTheme({
  palette: {
    mode: "light",
    primary: {
      main: "#FFFFFF",
    },
  },
});

export default function MainNavBar() {
  // State to manage theme mode
  const [darkMode, setDarkMode] = useState(false);

  return (
    <ThemeProvider theme={darkMode ? darkTheme : lightTheme}>
      <Stack spacing={2} sx={{ flexGrow: 1 }}>
        <AppBar position="static" color="primary" enableColorOnDark>
          {AppBarLabel()}
        </AppBar>
      </Stack>
    </ThemeProvider>
  );
}
