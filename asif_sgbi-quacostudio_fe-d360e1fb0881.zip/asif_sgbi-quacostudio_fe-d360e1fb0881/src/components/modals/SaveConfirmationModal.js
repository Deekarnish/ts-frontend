import React from 'react';
import {
  Dialog,
  DialogTitle,
  DialogContent,
  DialogActions,
  Button,
  Typography,
  IconButton,
} from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';

const ConfirmationDialog = ({ open, title, message, onConfirm, onCancel }) => {
  return (
    <Dialog
      open={open}
      onClose={onCancel}
      aria-labelledby="confirmation-dialog-title"
      PaperProps={{
        sx: { borderRadius: 3, padding: 1, width: 260 },
      }}
    >
      {/* Title Section */}
      {/* <DialogTitle
        id="confirmation-dialog-title"
        sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}
      >
        <Typography variant="h6">{title}</Typography>
        <IconButton edge="end" onClick={onCancel}>
          <CloseIcon />
        </IconButton>
      </DialogTitle> */}

      {/* Message Section */}
      <DialogContent dividers sx={{ py: 2 , textAlign:"center" }}>
        <Typography variant="body1">{message}</Typography>
      </DialogContent>

      {/* Action Buttons */}
      <DialogActions sx={{ px: 4, pb: 1, justifyContent: 'space-between' }}>
        <Button onClick={onCancel} variant="outlined" color="secondary">
          Cancel
        </Button>
        <Button onClick={onConfirm} variant="contained" color="primary" autoFocus>
          Confirm
        </Button>
      </DialogActions>
    </Dialog>
  );
};

export default ConfirmationDialog;
