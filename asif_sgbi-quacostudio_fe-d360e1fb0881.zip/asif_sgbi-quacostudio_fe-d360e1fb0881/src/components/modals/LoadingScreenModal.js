import Modal from "@mui/material/Modal";
import { Box, Typography } from "@mui/material";

const style = {
  
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  bgcolor: "#2F2F37",
  border: "2px solid #000",
  color: "white",
  boxShadow: 24,
  borderRadius: 3,
  p:1.5,
  width: "30%",
  display: "flex",
  justifyContent: "center",  // Centers the text horizontally
  alignItems: "center",  // Centers the text vertically
  textAlign: "left",  // Ensures the text is aligned in the center
};

const LoadingScreenModal = ({ loading, message , }) => {
  
  return (
    <Modal
      open={loading}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
      sx={{
        display: 'flex',
        justifyContent: 'center',
        alignItems: 'center',
        textAlign: "left",
      }}
    >
      <Box sx={style}>
        <Typography
          sx={{
            '&::after': {
              content: '""',
              display: 'inline-block',
              width: '0.8em',
              height: '1em',
              backgroundColor: 'transparent',
              animation: 'dots 1.5s steps(5, end) infinite',
            },
          }}
        >
          {` ${message} `}
        </Typography>
      </Box>
    </Modal>
  );
};

export default LoadingScreenModal;
