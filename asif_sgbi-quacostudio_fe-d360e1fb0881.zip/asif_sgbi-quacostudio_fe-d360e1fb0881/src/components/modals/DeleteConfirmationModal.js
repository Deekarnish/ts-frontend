import { Typography , Modal , Box ,Button } from "@mui/material";

const style = {
position: "absolute",
top: "50%",
left: "50%",
transform: "translate(-50%, -50%)",
// width: 400,
bgcolor: "background.paper",
border: "2px solid #000",
boxShadow: 24,
p: 4,
pb:2,
display: "flex",
flexDirection: "column",
justifyContent: "space-between",
borderRadius:3,

// height: 200,
};

const DeleteConfirmationModal = ({
    openDeleteConfirmation,
    setOpenDeleteConfirmation,
    handleDelete,
  }) => {
    const handleClose = () =>{
      setOpenDeleteConfirmation(false)
    }
    return (
      <Modal
        open={openDeleteConfirmation}
        onClose={e =>handleClose()}
        aria-labelledby="modal-modal-title"
        aria-describedby="modal-modal-description"
      >
        <Box sx={style}>
          <Typography id="modal-modal-title" component="h2">
            Are you sure you want to delete ?
          </Typography>
          <Box
            sx={{
              display: "flex",
              justifyContent: "space-between",
              mt: 2,
              width: "100%",
            }}
          >
            <Button
              onClick={handleClose}
              variant="outlined"
              sx={{ flex: 1, mr: 1 , borderRadius:2 ,pl:1.5,pr:1.5 ,border:"1px solid black" , color:"black"}}
            >
              No
            </Button>
            <Button
              onClick={e => handleDelete()}
              variant="contained"
              color="primary"
              sx={{ flex: 1, ml: 1 ,borderRadius:2 ,pl:1.5,pr:1.5, bgcolor:"#0075FF"}}
            >
              Yes
            </Button>
          </Box>
        </Box>
      </Modal>
    );
  };
  

export default DeleteConfirmationModal