import * as React from 'react';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DutAddingForm from '../forms/DutAddingForm';
import { Box, IconButton } from '@mui/material';
import CloseIcon from '@mui/icons-material/Close';
import { useDispatch, useSelector } from 'react-redux';
import { setOpenModal } from '../store/dutModalSlice';

export default function DutAddingModal(props) {

  const {initialValues}= props
 
  const open = useSelector(state=>state.dutmodal.modal)
  const isEdit = useSelector(state=>state.dutmodal.isEdit)

  const dispatch  = useDispatch()

  const handleClose = () => {
    dispatch(setOpenModal(false))
  };

  const descriptionElementRef = React.useRef(null);
  React.useEffect(() => {
    if (open) {
      const { current: descriptionElement } = descriptionElementRef;
      if (descriptionElement !== null) {
        descriptionElement.focus();
      }
    }
  }, [open]);

  return (
    <React.Fragment>
      <Dialog
        open={open}
        onClose={handleClose}
        scroll='paper'
        aria-labelledby="scroll-dialog-title"
        aria-describedby="scroll-dialog-description"
        PaperProps={{
          sx: {
            borderRadius: 3, // You can adjust the value as needed
            width: 'auto', // Adjust the width as needed
            // maxWidth: '50%', // Disable the default maxWidth
          },
        }}
      >
        <DialogTitle sx={{ bgcolor: "#0075FF", color: "white", height: 20, fontSize: 15 }}>
            <Box sx={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' ,mt:-1 }}>
                {isEdit ==='edit' ? "Edit DUT" : isEdit ==='duplicate'? "Duplicate DUT": isEdit ==='info'? "DUT Informations" :"Add New DUT"}
                <IconButton onClick={handleClose} sx={{ color: "white" }}>
                   <CloseIcon/>
                </IconButton>
            </Box>
        </DialogTitle>      
          <DutAddingForm isEditMode={isEdit} initialValues={initialValues}/>
      </Dialog>
    </React.Fragment>
  );
}
