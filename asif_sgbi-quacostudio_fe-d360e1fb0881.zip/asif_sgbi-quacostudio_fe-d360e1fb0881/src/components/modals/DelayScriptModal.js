import { Typography, Modal, Box, Button, TextField } from "@mui/material";
import { useState } from "react";
import { useDispatch, useSelector } from "react-redux";
import { setOpenDelay } from "../store/dutModalSlice";
import { createHapiScript } from "../store/hapiScriptSlice";
import { setHapiValues } from "../store/hapiSlice";

const style = {
  position: "absolute",
  top: "50%",
  left: "50%",
  transform: "translate(-50%, -50%)",
  bgcolor: "background.paper",
  border: "2px solid #000",
  boxShadow: 24,
  p: 4,
  pb: 2,
  display: "flex",
  flexDirection: "column",
  justifyContent: "space-between",
  borderRadius: 3,
};

const AddDelayModal = ({
}) => {
  const [delayValue, setDelayValue] = useState(1000); // State to store the delay value
  const dispatch = useDispatch()
  const { openDelay } = useSelector(state => state.dutmodal)
  const { hapiId } = useSelector((state) => state.hapivalues)

  const handleClose = () => {
    dispatch(setOpenDelay(false))
  };

  const handleInputChange = (e) => {
    setDelayValue(e.target.value);
    dispatch(setHapiValues({feature: "delay", value: e.target.value }))
  };

  const handleAddClick = () => {
    console.log("test")
    dispatch(setHapiValues({ feature: "hapiScriptName", value: `delay ${delayValue}ms`}))
    const hapiScriptData = {
        hapi_id: parseInt(hapiId),
        api: `delay:${delayValue}:`,
        name: `delay ${delayValue}ms`,
        element_id: "DLY:0",
      };
      // console.log(scriptId, "print id");
        dispatch(createHapiScript(hapiScriptData));
    handleClose(); // Close the modal after adding the delay
    dispatch(setOpenDelay(false))
  };

  return (
    <Modal
      open={openDelay}
      onClose={handleClose}
      aria-labelledby="modal-modal-title"
      aria-describedby="modal-modal-description"
    >
      <Box sx={style}>
        <Typography variant="h6" sx={{ mb: 2 }} id="modal-modal-title">
          Add Delay (in milliseconds)
        </Typography>
        <TextField
          label="Delay (ms)"
          type="number"
          value={delayValue}
          onChange={handleInputChange}
          fullWidth
          sx={{ mb: 2 }}
        />
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            width: "100%",
          }}
        >
          <Button
            onClick={handleClose}
            variant="outlined"
            sx={{
              flex: 1,
              mr: 1,
              borderRadius: 2,
              pl: 1.5,
              pr: 1.5,
              border: "1px solid black",
              color: "black",
            }}
          >
            Cancel
          </Button>
          <Button
            onClick={handleAddClick}
            variant="contained"
            color="primary"
            sx={{
              flex: 1,
              ml: 1,
              borderRadius: 2,
              pl: 1.5,
              pr: 1.5,
              bgcolor: "#0075FF",
            }}
            disabled={!delayValue} // Disable button if no delay value is provided
          >
            Add
          </Button>
        </Box>
      </Box>
    </Modal>
  );
};

export default AddDelayModal;
