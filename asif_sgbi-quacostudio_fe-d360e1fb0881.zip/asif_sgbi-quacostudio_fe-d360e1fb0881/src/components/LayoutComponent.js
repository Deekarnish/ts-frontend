import React, { useRef } from 'react'
import { Outlet } from 'react-router-dom'
import MainNavBar from './NavbarPanel'
import { Box } from '@mui/material';

const LayoutComponent = () => {

  return (
    <>
     <MainNavBar/>
    <main>
        <Box sx={{height:18}}></Box>
        <Outlet />
    </main>
    </>
  )
}

export default LayoutComponent