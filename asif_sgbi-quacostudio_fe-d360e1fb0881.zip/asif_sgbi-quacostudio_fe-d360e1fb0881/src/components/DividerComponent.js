import { Divider, Typography, Box } from '@mui/material';

const DividerWithText = ({text}) => {
  return (
    <Box sx={{ width: '100%', textAlign: 'center', my: 2 }}>
      <Divider sx={{ position: 'relative' }}>
        <Typography 
          variant="caption" 
          sx={{
            px: 2, 
            backgroundColor: 'white', 
            position: 'relative', 
            zIndex: 1,
          }}
        >
          {text}
        </Typography>
      </Divider>
    </Box>
  );
};

export default DividerWithText;