// dutButtonSlice.js

import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axiosInstance from '../../api/axiosConfig';

/**
 * Define the base URL for the API.
 * Replace 'http://your-api-url.com/api/dutButtons' with your actual API endpoint.
 */


/**
 * Initial state for the Redux slice.
 * This includes the list of DUT buttons, loading state, error messages,
 * and other specific parameters relevant to DUT buttons.
 */
const initialState = {
  buttons: [],            // List of DUT buttons fetched from the server
  loading: false,         // Indicates if an API call is in progress
  error: null,            // Stores error messages from failed API calls
  selectedButton: null,   // Stores a single DUT button's details
  imgurl: null,
  name: "",
  startX: 0,
  startY: 0,
  width: 0,
  height : 0,
  x: 0,
  y: 0,
  exposure: 500,
  light: false,
  duration: 50,
  backposition: 50,
  force: 50,
  create:false,
  update:false,
  id:false,
  position: "",
  activeIndex:false
};

/**
 * Async thunk to fetch all DUT buttons.
 * Makes a GET request to the API and handles success and error responses.
 */
export const fetchDutButtons = createAsyncThunk(
  'dutButtons/fetchAll',
  async (_, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.get('');
      return response.data; // Assumes the response data is an array of buttons
    } catch (error) {
      // Handles errors and passes them to the reducer
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

/**
 * Async thunk to fetch a single DUT button by its ID.
 * Makes a GET request to the API with the button's ID.
 */
export const fetchDutButtonById = createAsyncThunk(
  'dutButtons/fetchById',
  async (id, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.get(`buttons/by_dut/${id}`);
      return response.data; // Assumes the response data is the button object
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

/**
 * Async thunk to create a new DUT button.
 * Makes a POST request to the API with the new button's data.
 */
let ongoingRequest = null; // To track the ongoing request

export const createDutButton = createAsyncThunk(
  'dutButtons/create',
  async (dutButtonData, { rejectWithValue }) => {
    try {
      if (ongoingRequest) {
        return rejectWithValue('A request is already in progress. Please wait.');
      }

      // Create an AbortController for the current request
      const abortController = new AbortController();
      ongoingRequest = abortController;
      const response = await axiosInstance.post('/create_buttons/', dutButtonData ,{
        signal: abortController.signal, // Pass the signal to axios
      });
      ongoingRequest = null;
      return response.data; // Assumes the response data is the created button
    } catch (error) {
      ongoingRequest = null;
      if (axiosInstance.isCancel(error)) {
        // Handle request cancellation if needed
        return rejectWithValue('Request canceled');
      }
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

/**
 * Async thunk to update an existing DUT button by its ID.
 * Makes a PUT request to the API with the button's ID and updated data.
 */
export const updateDutButton = createAsyncThunk(
  'dutButtons/update',
  async ({ id, dutButtonData }, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.put(`/dut_buttons/${id}`, dutButtonData);
      return response.data; // Assumes the response data is the updated button
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

/**
 * Async thunk to delete a DUT button by its ID.
 * Makes a DELETE request to the API with the button's ID.
 */
export const deleteDutButton = createAsyncThunk(
  'dutButtons/delete',
  async (id, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.delete(`/dut_buttons/${id}`);
      return response.data; // Assumes the response data contains confirmation
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

/**
 * Creates the Redux slice for DUT buttons.
 * Defines reducers for synchronous actions and extraReducers for handling async thunks.
 */
const dutButtonSlice = createSlice({
  name: 'dutButtonList',
  initialState,
  reducers: {
    /**
     * Reducer to set multiple parameters in the state.
     * Accepts an object payload where keys match the state properties to be updated.
     */
    setParams(state, action) {
      // Iterate over the keys in the payload and update corresponding state properties
      Object.keys(action.payload).forEach(key => {
        if (key in state) {
          state[key] = action.payload[key];
        }
      });
    },
    clearState(state) {
      // Reset the state to its initial values
      return {
        ...initialState,       // Reset all fields to their initial values
        buttons: state.buttons // Preserve the current buttons array
      };
    },
    // Additional synchronous reducers can be added here if needed
    reset: () => initialState,
  },
  extraReducers: (builder) => {
    builder
      // Handles pending, fulfilled, and rejected states for fetching all buttons
      .addCase(fetchDutButtons.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchDutButtons.fulfilled, (state, action) => {
        state.loading = false;
        state.buttons = action.payload;
      })
      .addCase(fetchDutButtons.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Handles pending, fulfilled, and rejected states for fetching a button by ID
      .addCase(fetchDutButtonById.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchDutButtonById.fulfilled, (state, action) => {
        state.loading = false;
        state.selectedButton = action.payload;
        state.buttons = action.payload
      })
      .addCase(fetchDutButtonById.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Handles pending, fulfilled, and rejected states for creating a new button
      .addCase(createDutButton.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createDutButton.fulfilled, (state, action) => {
        state.loading = false;
        state.buttons.push(action.payload);
        state.id= action.payload.id
      })
      .addCase(createDutButton.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Handles pending, fulfilled, and rejected states for updating a button
      .addCase(updateDutButton.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateDutButton.fulfilled, (state, action) => {
        state.loading = false;
        const index = state.buttons.findIndex(button => button.id === action.payload.id);
        if (index !== -1) {
          state.buttons[index] = action.payload;
        }
      })
      .addCase(updateDutButton.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Handles pending, fulfilled, and rejected states for deleting a button
      .addCase(deleteDutButton.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteDutButton.fulfilled, (state, action) => {
        state.loading = false;
        // Assumes the action.meta.arg contains the ID of the deleted button
        const deletedId = action.meta.arg;
        state.buttons = state.buttons.filter(button => button.id !== deletedId);
      })
      .addCase(deleteDutButton.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

/**
 * Exporting the synchronous action creators and the reducer.
 * The reducer will be used to configure the Redux store.
 */
export const { setParams  , clearState ,reset} = dutButtonSlice.actions;
export default dutButtonSlice.reducer;
