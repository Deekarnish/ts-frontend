import { configureStore, createAction } from "@reduxjs/toolkit";
import dutSlice from "./dutSlice";
import dutTypesSlice from "./dutTypesSlice";
import pageSlice from "./pageSlice";
import dutButtonSlice from "./dutButtonSlice";
import dutDetailsSlice from "./dutDetailsSlice";
import dutModalSlice from "./dutModalSlice";
import videoFeedSlice from "./videoFeedSlice";
import dutScreenSlice from "./dutScreenSlice";
import hmiOptionsSlice from "./hmiOptionsSlice";
import ApiLoadingSlice from "./ApiLoadingSlice";
import hapiPageSlice from "./hapiPageSlice";
import hapiSlice from "./hapiSlice";
import hapiScriptSlice from "./hapiScriptSlice";
import screenElements from "./dutElementSlice";
import hapiScriptsRun from "./hapiScriptRunSlice"
import globalParameters from "./globalParamsSlice";
import templateModalSlice from "./templateModalSlice";
import templateSlice from "./templateSlice";
import ocrSlice from "./ocrSlice";
// Create a reset action
// export const resetAll = createAction('resetAll');

const store = configureStore({
    reducer: {
        duts: dutSlice,
        template:templateSlice,
        dutTypes: dutTypesSlice,
        page: pageSlice,
        dutButtons: dutButtonSlice,
        dutDetails: dutDetailsSlice,
        ocr:ocrSlice,
        dutmodal: dutModalSlice,
        templtemodal:templateModalSlice,
        vFeed: videoFeedSlice,
        dutScreen: dutScreenSlice,
        hmiOptionsSlice: hmiOptionsSlice,
        loading: ApiLoadingSlice,
        hapipage: hapiPageSlice,
        hapivalues: hapiSlice,
        hapiScripts: hapiScriptSlice,
        screenelements: screenElements,
        hapiScriptRun:hapiScriptsRun,
        globalParameters:globalParameters
    },
    // Handle reset action in each slice
    // middleware: (getDefaultMiddleware) =>
    //     getDefaultMiddleware().concat((storeAPI) => (next) => (action) => {
    //         if (action.type === resetAll.type) {
    //             Object.keys(storeAPI.getState()).forEach(sliceKey => {
    //                 storeAPI.dispatch({ type: `${sliceKey}/reset` });
    //             });
    //         }
    //         return next(action);
    //     }),
});

export default store;
