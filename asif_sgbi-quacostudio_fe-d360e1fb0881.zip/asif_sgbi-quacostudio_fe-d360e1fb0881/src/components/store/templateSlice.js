import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axiosInstance from '../../api/axiosConfig';

// Thunks for CRUD operations
export const postTemplate = createAsyncThunk('template/post', async (payload, { rejectWithValue }) => {
  try {
    const response = await axiosInstance.post('/create_template/', payload);
    return response.data;
  } catch (error) {
    if (error.response) {
      return rejectWithValue(error.response.data);
    } else if (error.request) {
      return rejectWithValue('No response received from the server.');
    } else {
      return rejectWithValue('Error in setting up the request.');
    }
  }
});

export const updateTemplate = createAsyncThunk('template/update', async ({ id, payload }, { rejectWithValue }) => {
  try {
    const response = await axiosInstance.put(`/update_template/${id}/`, payload);
    return response.data;
  } catch (error) {
    if (error.response) {
      return rejectWithValue(error.response.data);
    } else if (error.request) {
      return rejectWithValue('No response received from the server.');
    } else {
      return rejectWithValue('Error in setting up the request.');
    }
  }
});

export const duplicateTemplate = createAsyncThunk('template/duplicate', async (id, { rejectWithValue }) => {
  try {
    const response = await axiosInstance.post(`/duplicate_template/${id}/`);
    return response.data;
  } catch (error) {
    if (error.response) {
      return rejectWithValue(error.response.data);
    } else if (error.request) {
      return rejectWithValue('No response received from the server.');
    } else {
      return rejectWithValue('Error in setting up the request.');
    }
  }
});

export const postDuts = createAsyncThunk('dut/post', async (payload, { rejectWithValue }) => {
  try {
    const response = await axiosInstance.post('/create_dut/', payload);
    return response.data;
  } catch (error) {
    if (error.response) {
      return rejectWithValue(error.response.data);
    } else if (error.request) {
      return rejectWithValue('No response received from the server.');
    } else {
      return rejectWithValue('Error in setting up the request.');
    }
  }
});

// Slice for templates
const templateSlice = createSlice({
  name: 'template',
  initialState: {
    templates: [],
    loading: false,
    error: null,
  },
  reducers: {
    // Add any synchronous actions here if needed
  },
  extraReducers: (builder) => {
    builder
      // Handle postTemplate
      .addCase(postTemplate.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(postTemplate.fulfilled, (state, action) => {
        state.loading = false;
        state.templates.push(action.payload);
      })
      .addCase(postTemplate.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      // Handle updateTemplate
      .addCase(updateTemplate.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateTemplate.fulfilled, (state, action) => {
        state.loading = false;
        const index = state.templates.findIndex(template => template.id === action.payload.id);
        if (index !== -1) {
          state.templates[index] = action.payload;
        }
      })
      .addCase(updateTemplate.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      // Handle duplicateTemplate
      .addCase(duplicateTemplate.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(duplicateTemplate.fulfilled, (state, action) => {
        state.loading = false;
        state.templates.push(action.payload);
      })
      .addCase(duplicateTemplate.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      // Handle postDuts
      .addCase(postDuts.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(postDuts.fulfilled, (state, action) => {
        state.loading = false;
        // Handle the new DUT if you want to add it to the state
      })
      .addCase(postDuts.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  }
});

export default templateSlice.reducer;
