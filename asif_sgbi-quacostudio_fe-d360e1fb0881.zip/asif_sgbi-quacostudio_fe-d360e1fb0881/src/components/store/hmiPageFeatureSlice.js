import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  buttonExpand: false,
  indicatorExpand: false,
  screenExapand: false,
  ocrExpand: false,
  keyPadExapand: false,
  propertiesGeneral:true,
  propertiesRegion:true,
  propertiesGlobal:true
};

const HmipageSlice = createSlice({
  name: "hmipage",
  initialState,
  reducers: {
    disableAllAndEnableFeature(state, action) {
      const featureToEnable = action.payload;
       state = initialState
      // Enable the passed feature
      if (featureToEnable in state) {
        state[featureToEnable] = true;
      }
    },
    reset: () => initialState,
  },
});

export const {
  setVideoFeedCanvas,
  enableVideoFeedCanvas,
  disableVideoFeedCanvas,
  disableAllAndEnableFeature
  ,reset 
} = videoFeedSlice.actions;
export default videoFeedSlice.reducer;
