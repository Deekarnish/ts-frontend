import { createSlice } from '@reduxjs/toolkit';


const initialState = {
  // hapiScriptList: [], // List of scripts to run
  hapiScriptIndex: 0, // Current script index
  isRunning: false,   // Whether the scripts are running
  isPaused: false,    // Whether the scripts are paused
};

const hapiScriptSlice = createSlice({
  name: 'hapiScriptsRun',
  initialState,
  reducers: {
    // setHapiScriptList: (state, action) => {
    //   state.hapiScriptList = action.payload;
    // },
    clearHapiState(state) {
      const { hapiScriptList } = state;

      // Reset state to initial values except for hapiNameList and activeIndex
      Object.assign(state, initialState);

      // Restore hapiNameList and activeIndex
      state.hapiScriptList = hapiScriptList;
 
    },
    startRunning: (state) => {
      state.isRunning = true;
      state.isPaused = false;
    },
    pauseRunning: (state) => {
      state.isPaused = true;
    },
    stopRunning: (state) => {
      state.isRunning = false;
      state.isPaused = false;
      state.hapiScriptIndex = 0; // Optionally reset the index
    },
    resumeRunning: (state) => {
      state.isPaused = false;
    },
  },
});

export const {
  // setHapiScriptList,
  startRunning,
  pauseRunning,
  stopRunning,
  resumeRunning,
} = hapiScriptSlice.actions;





  export default hapiScriptSlice.reducer;