import { createSlice } from "@reduxjs/toolkit";
import Cookies from "js-cookie";

const initialState = {
  currentPage: Cookies.get("currentPage"), // default page
  clearscreen:false,
  buttons: false,
  indicators: false,
  ocr: false,
  screens: false,
  keypad: false,
  elements:false,
  autoSave:false
};

const pageSlice = createSlice({
  name: "page",
  initialState,
  reducers: {
    setPage(state, action) {
      state.currentPage = action.payload;
      Cookies.set("currentPage", action.payload, { expires: 1 });
    },
    setClear(state, action) {
      state.clearscreen = action.payload;
    },
    setFeature(state, action) {
      // action.payload should be an object with feature names and their states
      const { feature, value } = action.payload;
      if (feature in state) {
        state[feature] = value;
      }
    },
    // Optionally, you can add individual reducers for each feature if needed
    enableFeature(state, action) {
      const featureToEnable = action.payload;

      // First, disable all features by setting them to false
      Object.keys(state).forEach((feature) => {
        state[feature] = false;
      });

      // Then enable the specific feature passed in the payload
      if (featureToEnable in state) {
        state[featureToEnable] = true;
        state["currentPage"] =Cookies.get("currentPage")
      }
    },
    disableFeature(state, action) {
      const feature = action.payload;
      if (feature in state) {
        state[feature] = false;
      }
    },
    reset: () => initialState,
  },
});

export const { setPage, setFeature, enableFeature, disableFeature ,reset,setClear } =
  pageSlice.actions;
export default pageSlice.reducer;
