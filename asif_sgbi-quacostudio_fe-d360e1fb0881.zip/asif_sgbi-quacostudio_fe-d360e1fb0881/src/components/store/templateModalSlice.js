import { createSlice } from '@reduxjs/toolkit';

const initialState = {
   modal:false,
   isEdit:false
};


const modalSlice = createSlice({
  name: 'templatemodal',
  initialState,
  reducers: {
    setOpenTemplate(state, action) {
      state.modal = action.payload;;
    },
    setTypeTemplateModal(state, action) {
        state.isEdit = action.payload;;
      },
    reset: () => initialState,
  },
});

export const { setOpenTemplate , setTypeTemplateModal ,reset} = modalSlice.actions;
export default modalSlice.reducer;