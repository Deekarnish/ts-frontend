import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axiosInstance from '../../api/axiosConfig';

// Initial state for OCR slice
const initialState = {
  ocrElements: [],
  loading: false,
  error: null,
  selectedOcr: null, // To track the currently selected OCR element
  extractedText: "", // Holds the OCR extracted text
  isProcessing: false, // Used to track if OCR is being processed
  isDrawingElement:false,
  addOcr:false,
  updateOcr:false,
  name:"",
  color:true,
  hsv:false,
  TextCorrection:false,
  TextDetection:false,
  ocrLanguage:"EN",
  engine:"Sastra_OCR",
  model:"english_g2",
  sX:0,
  sY:0,
  sW:0,
  sH:0,
  ocrKeywords:"",
  id:null
};

// Async thunk for fetching OCR elements
export const fetchOcrElements = createAsyncThunk(
  'ocr/fetchOcrElements',
  async (screenId, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.get(`/get_ocrs_by_screen/${screenId}`);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

// Async thunk for creating a new OCR element
export const createOcrElement = createAsyncThunk(
  'ocr/createOcrElement',
  async (ocrData, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.post('/create_ocr_field/', ocrData);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

// Async thunk for updating an OCR element
export const updateOcrElement = createAsyncThunk(
  'ocr/updateOcrElement',
  async ({ id, ocrData }, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.put(`/ocr/${id}/`, ocrData);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

// Async thunk for deleting an OCR element
export const deleteOcrElement = createAsyncThunk(
  'ocr/deleteOcrElement',
  async (id, { rejectWithValue }) => {
    try {
      await axiosInstance.delete(`/ocr/${id}/`);
      return id;
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

// Slice
const ocrSlice = createSlice({
  name: 'ocr',
  initialState,
  reducers: {
    // Sync action to set OCR element parameters
    setOcrParams(state, action) {
      Object.keys(action.payload).forEach(key => {
        if (key in state) {
          state[key] = action.payload[key];
        }
      });
    },
    // Sync action to set the selected OCR element
    setSelectedOcr(state, action) {
      state.selectedOcr = action.payload;
    },
    // Sync action to clear OCR state
    clearOcrState(state) {
      return {
        ...initialState,
        ocrElements: state.ocrElements, // Preserve the current elements array
      };
    },
    clearError(state) {
      state.error = null;
    },
    reset: () => initialState,
  },
  extraReducers: (builder) => {
    builder
      // Handle fetch OCR elements
      .addCase(fetchOcrElements.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchOcrElements.fulfilled, (state, action) => {
        state.loading = false;
        state.ocrElements = action.payload;
        // state.selectedOcr = action.payload.id;
      })
      .addCase(fetchOcrElements.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      // Handle create OCR element
      .addCase(createOcrElement.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createOcrElement.fulfilled, (state, action) => {
        state.loading = false;
        state.ocrElements.push(action.payload);
        state.selectedOcr = action.payload.id;
        state.id = action.payload.id 
      })
      .addCase(createOcrElement.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      // Handle update OCR element
      .addCase(updateOcrElement.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateOcrElement.fulfilled, (state, action) => {
        state.loading = false;
        const index = state.ocrElements.findIndex(el => el.id === action.payload.id);
        if (index !== -1) {
          state.ocrElements[index] = action.payload;
        }
      })
      .addCase(updateOcrElement.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      // Handle delete OCR element
      .addCase(deleteOcrElement.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteOcrElement.fulfilled, (state, action) => {
        state.loading = false;
        state.ocrElements = state.ocrElements.filter(el => el.id !== action.payload);
      })
      .addCase(deleteOcrElement.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export const { setSelectedOcr, clearError, reset, setOcrParams, clearOcrState } = ocrSlice.actions;

export default ocrSlice.reducer;

