import { createSlice } from "@reduxjs/toolkit";
import Cookies from "js-cookie";

const initialState = {
    wsStatus:false
};

const ApiLoadingSlice = createSlice({
  name: "loading",
  initialState,
  reducers: {
    setWsStatus(state, action) {
      state.wsStatus = action.payload;
    },
    reset: () => initialState,
  },
});

export const { setWsStatus ,reset } =
ApiLoadingSlice.actions;
export default ApiLoadingSlice.reducer;
