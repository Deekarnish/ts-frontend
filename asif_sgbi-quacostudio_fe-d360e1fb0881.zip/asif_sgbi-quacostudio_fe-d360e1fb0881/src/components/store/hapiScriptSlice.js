import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axiosInstance from "../../api/axiosConfig";
// import { resetAll } from "./store";

// Thunks for API interactions

// Fetch all Hapi scripts and store them in hapiScriptList
export const fetchHapiScripts = createAsyncThunk(
  'hapiScriptSlice/fetchHapiScripts',
  async (id, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.get(`lowlevel_script/by-hapi/${id}/`);
      return response.data; // Assumes the API returns a list of Hapi scripts
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

// Create a new Hapi script
export const createHapiScript = createAsyncThunk(
  'hapiScriptSlice/createHapiScript',
  async (hapiScriptData, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.post(`/lowlevel_script/`,null, {
        params: hapiScriptData
    });
      return response.data; // Assumes the response data is the created Hapi script
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

// Update an existing Hapi script
export const updateHapiScript = createAsyncThunk(
  'hapiScriptSlice/updateHapiScript',
  async ({ id, hapiScriptData }, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.put(`/update_lowlevel_script/${id}/`, hapiScriptData);
      return response.data; // Assumes the response data is the updated Hapi script
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

// Delete a Hapi script
export const deleteHapiScript = createAsyncThunk(
  'hapiScriptSlice/deleteHapiScript',
  async (id, { rejectWithValue }) => {
    try {
      await axiosInstance.delete(`/delete_lowlevel_script/${id}/`);
      return id; // Return the ID of the deleted Hapi script
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

const initialState = {
  hapiScriptName: "",
  hapiScriptList: [],
  hapiId:null,
  hapiScriptType: "",
  hapiScriptAction: "",
  loading: false,
  error: null,
  hapiActiveScript:false,
  hapiScriptIndex:null,
  scriptId:null,
  // element_id:null,
  hapiScriptRunIndex:false
};

const hapiScriptSlice = createSlice({
  name: "hapiScriptSlice",
  initialState,
  reducers: {
    setHapiScriptValues(state, action) {
      const { feature, value } = action.payload;
      if (feature in state) {
        state[feature] = value;
      }
    },
    setHapiScriptName(state, action) {
      state.hapiScriptName = action.payload;
    },
    setCurrentScriptIndex: (state, action) => {
      state.hapiScriptRunIndex = action.payload;
    },
    resetAllScripts(state, action) {
      state = initialState;
    },
    clearHapiScriptState(state) {
      const { hapiScriptList ,hapiId } = state;

      // Reset state to initial values except for hapiNameList and activeIndex
      Object.assign(state, initialState);

      // Restore hapiNameList and activeIndex
      state.hapiScriptList = hapiScriptList;
      state.hapiId= hapiId
 
    },
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchHapiScripts.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchHapiScripts.fulfilled, (state, action) => {
        state.loading = false;
        state.hapiScriptList = action.payload;
      })
      .addCase(fetchHapiScripts.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(createHapiScript.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createHapiScript.fulfilled, (state, action) => {
        state.loading = false;
        state.hapiScriptList.push(action.payload); // Add the new Hapi script to the list
        state.scriptId = action.payload.id
      })
      .addCase(createHapiScript.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(updateHapiScript.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateHapiScript.fulfilled, (state, action) => {
        state.loading = false;
        const index = state.hapiScriptList.findIndex(script => script.id === action.payload.id);
        if (index !== -1) {
          state.hapiScriptList[index] = action.payload; // Update the Hapi script in the list
        }
      })
      .addCase(updateHapiScript.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(deleteHapiScript.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteHapiScript.fulfilled, (state, action) => {
        state.loading = false;
        state.hapiScriptList = state.hapiScriptList.filter(script => script.id !== action.payload); // Remove the deleted Hapi script
      })
      .addCase(deleteHapiScript.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
  },
});

export const { setHapiScriptValues,setCurrentScriptIndex, setHapiScriptName,resetAllScripts ,clearHapiScriptState} = hapiScriptSlice.actions;
export default hapiScriptSlice.reducer;
