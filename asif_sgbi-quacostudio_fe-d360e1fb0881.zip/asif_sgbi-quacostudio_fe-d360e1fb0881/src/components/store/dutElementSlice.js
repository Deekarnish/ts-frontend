import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axiosInstance from '../../api/axiosConfig';
import { light } from '@mui/material/styles/createPalette';
// Initial state
const initialState = {
  screenelements: [],
  loading: false,
  error: null,
  selectedElement: null, // Can be used to track the currently selected element
  elemUrl: null,
  name: "",
  updateElement:false,
  sX: 0,
  sY: 0,
  sW: 0,
  sH : 0,
  light:false,
  isDrawingElement:false,
  addElement:false,
  id:null
};

// Async thunk for fetching screen elements
// Fetch screen elements by screen ID
export const fetchScreenElements = createAsyncThunk(
  'screenElements/fetchScreenElements',
  async (screenId, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.get(`/screen_element_by_screen/${screenId}`);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);
// Async thunk for creating a new screen element
export const createScreenElement = createAsyncThunk(
  'screenElements/createScreenElement',
  async (elementData, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.post('/create_screen_element/', elementData);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

// Async thunk for updating an existing screen element
export const updateScreenElement = createAsyncThunk(
  'screenElements/updateScreenElement',
  async ({ id, elementData }, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.put(`/update_screen_element/${id}/`, elementData);
      return response.data;
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

// Async thunk for deleting a screen element
export const deleteScreenElement = createAsyncThunk(
  'screenElements/deleteScreenElement',
  async (id, { rejectWithValue }) => {
    try {
      await axiosInstance.delete(`/delete_screen_element/${id}/`);
      return id;
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

// Slice
const screenElementsSlice = createSlice({
  name: 'screenElements',
  initialState,
  reducers: {
    // Optionally add some synchronous actions, like setting a selected element
    setElementParams(state, action) {
      // Iterate over the keys in the payload and update corresponding state properties
     
      Object.keys(action.payload).forEach(key => {
        if (key in state) {
          state[key] = action.payload[key];
        }
      });
    },
    setSelectedElement(state, action) {
      state.selectedElement = action.payload;
    },
    clearElementState(state) {
      // Reset the state to its initial values
      return {
        ...initialState,       // Reset all fields to their initial values
        screenelements: state.screenelements // Preserve the current buttons array
      };
    },
    clearError(state) {
      state.error = null;
    },
    reset: () => initialState,
  },
  extraReducers: (builder) => {
    builder
      // Handle fetch
      .addCase(fetchScreenElements.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchScreenElements.fulfilled, (state, action) => {
        state.loading = false;
        state.screenelements = action.payload;
        state.selectedElement = action.payload.id
      })
      .addCase(fetchScreenElements.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      // Handle create
      .addCase(createScreenElement.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createScreenElement.fulfilled, (state, action) => {
        state.loading = false;
        state.screenelements.push(action.payload);
        state.selectedElement = action.payload.id
        state.id = action.payload.id
      })
      .addCase(createScreenElement.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      // Handle update
      .addCase(updateScreenElement.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateScreenElement.fulfilled, (state, action) => {
        state.loading = false;
        const index = state.screenelements.findIndex(el => el.id === action.payload.id);
        if (index !== -1) {
          state.screenelements[index] = action.payload;
        }
      })
      .addCase(updateScreenElement.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      // Handle delete
      .addCase(deleteScreenElement.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteScreenElement.fulfilled, (state, action) => {
        state.loading = false;
        state.screenelements = state.screenelements.filter(el => el.id !== action.payload);
      })
      .addCase(deleteScreenElement.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export const { setSelectedElement, clearError ,reset , setElementParams, clearElementState } = screenElementsSlice.actions;

export default screenElementsSlice.reducer;
