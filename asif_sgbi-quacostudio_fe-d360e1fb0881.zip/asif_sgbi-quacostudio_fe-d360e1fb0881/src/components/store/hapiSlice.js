import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axiosInstance from "../../api/axiosConfig";

// Thunks for API interactions

// Fetch all Hapis and store them in hapiNameList
export const fetchHapis = createAsyncThunk(
  "hapislice/fetchHapis",
  async (id, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.get(`/hapi/by-dut/${id}`);
      return response.data; // Assumes the API returns a list of Hapis
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

// Create a new Hapi
export const createHapi = createAsyncThunk(
  "hapislice/createHapi",
  async (hapiData, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.post(`/create_hapi/`, hapiData);
      return response.data; // Assumes the response data is the created Hapi
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

// Update an existing Hapi
export const updateHapi = createAsyncThunk(
  "hapislice/updateHapi",
  async ({ id, hapiData }, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.put(`/hapis/${id}/`, hapiData);
      return response.data; // Assumes the response data is the updated Hapi
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

// Delete a Hapi
export const deleteHapi = createAsyncThunk(
  "hapislice/deleteHapi",
  async (id, { rejectWithValue }) => {
    try {
      await axiosInstance.delete(`/delete_hapi/${id}/`);
      return id; // Return the ID of the deleted Hapi
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

const initialState = {
  force: 100,
  speed: 1500,
  duration: 5,
  autoSave:false,
  backposition: 25,
  move: true,
  tReturn: true,
  nameError:false,
  touch: false,
  taps: 2,
  delay:1000,
  text:null,
  elementName: "",
  screenName:"",
  command: "",
  gap:40,
  hapiName: "",
  hapiScriptName: "",
  hapiId: null,
  hapiApiName: "",
  activeIndex: false,
  activeHapiName: "",
  hapiNameList: [],
  hapiType: "BTN",
  hapiAction: "",
  loading: false,
  error: null,
  matching:75,
  element_id:"",
  cx:0,
  cy:0,
  sx:0,
  sy:0,
  ex:0,
  ey:0,
  ox:0,
  oy:0,
};

const hapiSlice = createSlice({
  name: "hapislice",
  initialState,
  reducers: {
    setHapiValues(state, action) {
      const { feature, value } = action.payload;
      if (feature in state) {
        state[feature] = value;
      }
    },
    setHapiName(state, action) {
      state.hapiName = action.payload;
    },
    enableHapiFeature(state, action) {
      const featureToEnable = action.payload;
      Object.keys(state).forEach((feature) => {
        state[feature] = false;
      });
      if (featureToEnable in state) {
        state[featureToEnable] = true;
      }
    },
    disableHapiFeature(state, action) {
      const feature = action.payload;
      if (feature in state) {
        state[feature] = false;
      }
    },

    disableEnableMouseAssist(state, action) {
      // Disable all mouse assist states
      state.touch = false;
      state.tReturn = false;
      // Enable only the specified state based on the action payload
      const assistType = action.payload;
    
      if (assistType in state) {
        state[assistType] = true;
      }
    },
    

    clearHapiState(state) {
      const {
        hapiNameList,
        activeIndex,
        hapiId,
        command,
        hapiAction,
        hapiType,
      } = state;

      // Reset state to initial values except for hapiNameList and activeIndex
      Object.assign(state, initialState);

      // Restore hapiNameList and activeIndex
      state.hapiNameList = hapiNameList;
      state.activeIndex = activeIndex;
      state.hapiId = hapiId;
      state.command = command;
      state.hapiAction = hapiAction;
      state.hapiType = hapiType;
    },
    resethapiSlice: () => initialState,
  },
  extraReducers: (builder) => {
    builder
      .addCase(fetchHapis.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchHapis.fulfilled, (state, action) => {
        state.loading = false;
        state.hapiNameList = action.payload;
      })
      .addCase(fetchHapis.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(createHapi.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createHapi.fulfilled, (state, action) => {
        state.loading = false;
        state.hapiNameList.push(action.payload); // Add the new Hapi to the list
      })
      .addCase(createHapi.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(updateHapi.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateHapi.fulfilled, (state, action) => {
        state.loading = false;
        const index = state.hapiNameList.findIndex(
          (hapi) => hapi.id === action.payload.id
        );
        if (index !== -1) {
          state.hapiNameList[index] = action.payload; // Update the Hapi in the list
        }
      })
      .addCase(updateHapi.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      .addCase(deleteHapi.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteHapi.fulfilled, (state, action) => {
        state.loading = false;
        state.hapiNameList = state.hapiNameList.filter(
          (hapi) => hapi.id !== action.payload
        ); // Remove the deleted Hapi
      })
      .addCase(deleteHapi.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

export const { setHapiValues, setHapiName, clearHapiState, resethapiSlice ,disableEnableMouseAssist } =
  hapiSlice.actions;
export default hapiSlice.reducer;
