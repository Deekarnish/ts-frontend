import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  screenEnabled: false,
  buttonEnabled: false,
  elementEnabled: false,
  buttonDrawEnabled: false,
  globalNavigationEnabled: false,
  adjustNavigationEnabled:false,
  MouseAssist:false,
  swipeCanvas:false
};

const videoFeedSlice = createSlice({
  name: "vFeed",
  initialState,
  reducers: {
    setVideoFeedCanvas(state, action) {
      // action.payload should be an object with feature names and their states
      const { feature, value } = action.payload;
      if (feature in state) {
        state[feature] = value;
      }
    },
    // Optionally, you can add individual reducers for each feature if needed
    enableVideoFeedCanvas(state, action) {
      const feature = action.payload;
      if (feature in state) {
        state[feature] = true;
      }
    },
    resetAllCanvas(state, action){
      return {
        ...state,  // Keeps other parts of the state intact
        ...initialState // Resets the canvas-related state
      };
    },
    disableVideoFeedCanvas(state, action) {
      const feature = action.payload;
      if (feature in state) {
        state[feature] = false;
      }
    },
    disableAllAndEnableFeature(state, action) {
      const featureToEnable = action.payload;

      // Iterate over all keys in the state
      for (const feature in state) {
        if (state.hasOwnProperty(feature)) {
          // Disable all features
          state[feature] = false;
        }
      }

      // Enable the passed feature
      if (featureToEnable in state) {
        state[featureToEnable] = true;
      }
    },
  },
});

export const {
  setVideoFeedCanvas,
  enableVideoFeedCanvas,
  disableVideoFeedCanvas,
  disableAllAndEnableFeature,
  resetAllCanvas
} = videoFeedSlice.actions;
export default videoFeedSlice.reducer;
