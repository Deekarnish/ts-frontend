import { createSlice } from '@reduxjs/toolkit';

const initialState = {
  gDuration: 5, 
  gBackposition: 25, 
  gForce: 100, 
};

const globalParametersSlice = createSlice({
  name: 'globalParameters',
  initialState,
  reducers: {
    updateDuration: (state, action) => {
      state.gDuration = action.payload;
    },
    updateBackPosition: (state, action) => {
      state.gBackposition = action.payload;
    },
    updateForce: (state, action) => {
      state.gForce = action.payload;
    },
    updateAllParameters: (state, action) => {
      return { ...state, ...action.payload };
    },
    resetParameters: () => initialState,
  },
});

export const {
    updateDuration,
    updateBackPosition,
    updateForce,
  updateAllParameters,
  resetParameters,
} = globalParametersSlice.actions;

export default globalParametersSlice.reducer;
