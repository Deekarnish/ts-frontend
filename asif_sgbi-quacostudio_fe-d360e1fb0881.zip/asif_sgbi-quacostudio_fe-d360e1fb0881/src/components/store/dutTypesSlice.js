import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axiosInstance from "../../api/axiosConfig";

const initialState = {
  data: [],
  status: 'idle',
  error: null
};

export const getDutTypes = createAsyncThunk('dut/get/types', async () => {
    const response = await axiosInstance.get('/list_dut_types/');
    return response.data;
  });

  const dutTypesSlice = createSlice({
    name: 'dutTypes',
    initialState,
    reducers: {
      fetchDuts(state, action) {
        state.data = action.payload;
      },
      reset: () => initialState,
    },
    extraReducers: (builder) => {
      builder
        .addCase(getDutTypes.pending, (state) => {
          state.status = 'loading';
          state.error = null; // Reset error to null
        })
        .addCase(getDutTypes.fulfilled, (state, action) => {
          state.data = action.payload;
          state.status = 'idle';
        })
        .addCase(getDutTypes.rejected, (state, action) => {
          state.status = 'error';
          state.error = action.payload; // Capture the error message
        })
    }
  });
  
  export const { fetchDutTypes,reset, } = dutTypesSlice.actions;
  export default dutTypesSlice.reducer;
  