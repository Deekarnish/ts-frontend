import { createSlice ,createAsyncThunk} from '@reduxjs/toolkit';
import Cookies from 'js-cookie';
import axiosInstance from "../../api/axiosConfig";

// Define the initial state for the DUT slice
const initialState = {
  id: Cookies.get('dutId') || null, // Retrieve the DUT ID from cookies or set to null if not present
  manufacturer: '',
  serial_number: '',
  firmware_version: '',
  model_number: '',
  name: '',
  lbh: '',
  dut_type_id: null,
};

// Create the DUT slice
const dutSlice = createSlice({
  name: 'dutDetails',
  initialState,
  reducers: {
    setDutDetails(state, action) {
      const { id, manufacturer, serial_number, firmware_version, model_number, name, lbh, dut_type_id } = action.payload;
      state.id = id;
      state.manufacturer = manufacturer;
      state.serial_number = serial_number;
      state.firmware_version = firmware_version;
      state.model_number = model_number;
      state.name = name;
      state.lbh = lbh;
      state.dut_type_id = dut_type_id;
      Cookies.set('dutId', id, { expires: 1 }); // Store the DUT ID in cookies for 1 day
    },
    clearDutDetails(state) {
      state.id = null;
      state.manufacturer = '';
      state.serial_number = '';
      state.firmware_version = '';
      state.model_number = '';
      state.name = '';
      state.lbh = '';
      state.dut_type_id = null;
      Cookies.remove('dutId'); // Remove the DUT ID from cookies
    },
    reset: () => initialState,
  },
});

// Export the actions and reducer
export const { setDutDetails, clearDutDetails ,reset } = dutSlice.actions;
export default dutSlice.reducer;

// Async thunk to fetch DUT details based on ID
export const fetchDutDetails = createAsyncThunk(
    'dut/fetchDutDetails',
    async (dutId, { dispatch }) => {
      const response = await axiosInstance.get(`/dut/${dutId}`);
      dispatch(setDutDetails(response.data));
      console.log(response.data , 'details of dut')
      return response.data;
    }
  );