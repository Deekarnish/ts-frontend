import { createSlice } from '@reduxjs/toolkit';

const initialState = {
   modal:false,
   isEdit:false,
   openDelay:false,
};


const modalSlice = createSlice({
  name: 'dutmodal',
  initialState,
  reducers: {
    setOpenModal(state, action) {
      state.modal = action.payload;;
    },
    setTypeModal(state, action) {
        state.isEdit = action.payload;;
      },
    setOpenDelay(state,action){
      state.openDelay=action.payload
    },
    reset: () => initialState,
  },
});

export const { setOpenModal , setTypeModal ,setOpenDelay,reset} = modalSlice.actions;
export default modalSlice.reducer;
