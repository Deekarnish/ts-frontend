import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  hapiGeneral:true,
  hapiElements:false,
  hapiTapParams:false,
  hapiResponse:false,
  addNewHapi:false,
  delayParamenters:true
};

const hapiPageSlice = createSlice({
  name: "hapipage",
  initialState,
  reducers: {
    setHapiFeature(state, action) {
      // action.payload should be an object with feature names and their states
      const { feature, value } = action.payload;
      if (feature in state) {
        state[feature] = value;
      }
    },
    // Optionally, you can add individual reducers for each feature if needed
    enableHapiFeature(state, action) {
      const featureToEnable = action.payload;

      // First, disable all features by setting them to false
      Object.keys(state).forEach((feature) => {
        state[feature] = false;
      });

      // Then enable the specific feature passed in the payload
      if (featureToEnable in state) {
        state[featureToEnable] = true;
      }
    },
    disableHapiFeature(state, action) {
      const feature = action.payload;
      if (feature in state) {
        state[feature] = false;
      }
    },
    reset: () => initialState,
  },
});

export const { setHapiFeature, enableHapiFeature, disableHapiFeature ,reset} =
hapiPageSlice.actions;
export default hapiPageSlice.reducer;
