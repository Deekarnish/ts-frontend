import { createSlice, createAsyncThunk } from "@reduxjs/toolkit";
import axiosInstance from "../../api/axiosConfig";

const initialState = {
  data: [],
  status: 'idle',
  error: null
};

export const getDuts = createAsyncThunk('dut/get', async () => {
  const response = await axiosInstance.get('/list_duts/');
  return response.data;
});

export const postDuts = createAsyncThunk('dut/post', async (payload, { rejectWithValue }) => {
  try {
    const response = await axiosInstance.post('/create_dut/', payload);
    return response.data;
  } catch (error) {
    if (error.response) {
      return rejectWithValue(error.response.data);
    } else if (error.request) {
      return rejectWithValue('No response received from the server.');
    } else {
      return rejectWithValue('Error in setting up the request.');
    }
  }
});

export const searchDuts = createAsyncThunk('dut/search', async (query, { rejectWithValue }) => {
  try {
    const response = await axiosInstance.get('/duts/search/', { params: { 'name': query } });
    return response.data;
  } catch (error) {
    if (error.response) {
      return rejectWithValue(error.response.data);
    } else if (error.request) {
      return rejectWithValue('No response received from the server.');
    } else {
      return rejectWithValue('Error in setting up the request.');
    }
  }
});

export const deleteDut = createAsyncThunk('dut/delete', async (id, { rejectWithValue }) => {
  try {
    await axiosInstance.delete(`/delete_dut/${id}/`);
    return id;
  } catch (error) {
    if (error.response) {
      return rejectWithValue(error.response.data);
    } else if (error.request) {
      return rejectWithValue('No response received from the server.');
    } else {
      return rejectWithValue('Error in setting up the request.');
    }
  }
});

export const updateDut = createAsyncThunk('dut/update', async ({ id, data }, { rejectWithValue }) => {
  try {
    const response = await axiosInstance.put(`/update_dut/${id}/`, data);
    return response.data;
  } catch (error) {
    if (error.response) {
      return rejectWithValue(error.response.data);
    } else if (error.request) {
      return rejectWithValue('No response received from the server.');
    } else {
      return rejectWithValue('Error in setting up the request.');
    }
  }
});

const dutSlice = createSlice({
  name: 'duts',
  initialState,
  reducers: {
    fetchDuts(state, action) {
      state.data = action.payload;
    },
    addDut(state, action) {
      state.data.push(action.payload);
    },
    reset: () => initialState,
  },
  extraReducers: (builder) => {
    builder
      .addCase(getDuts.pending, (state) => {
        state.status = 'loading';
        state.error = null; // Reset error to null
      })
      .addCase(getDuts.fulfilled, (state, action) => {
        state.data = action.payload;
        state.status = 'idle';
      })
      .addCase(getDuts.rejected, (state, action) => {
        state.status = 'error';
        state.error = action.payload; // Capture the error message
      })
      .addCase(postDuts.pending, (state) => {
        state.status = 'loading';
        state.error = null; // Reset error to null
      })
      .addCase(postDuts.fulfilled, (state, action) => {
        state.data = [action.payload, ...state.data
        ]
        state.status = 'idle';
        state.error = null
      })
      .addCase(postDuts.rejected, (state, action) => {
        state.status = 'error';
        state.error = action.payload; // Capture the error message
      })
      .addCase(deleteDut.pending, (state) => {
        state.status = 'loading';
        state.error = null; // Reset error to null
      })
      .addCase(deleteDut.fulfilled, (state, action) => {
        state.data = state.data.filter(dut => dut.id !== action.payload);
        state.status = 'idle';
      })
      .addCase(deleteDut.rejected, (state, action) => {
        state.status = 'error';
        state.error = action.payload; // Capture the error message
      })
      .addCase(updateDut.pending, (state) => {
        state.status = 'loading';
        state.error = null; // Reset error to null
      })
      .addCase(updateDut.fulfilled, (state, action) => {
        const index = state.data.findIndex(dut => dut.id === action.payload.id);
        if (index !== -1) {
          state.data[index] = action.payload;
        }
        state.status = 'idle';
      })
      .addCase(updateDut.rejected, (state, action) => {
        state.status = 'error';
        state.error = action.payload; // Capture the error message
      })
      .addCase(searchDuts.pending, (state) => {
        state.status = 'loading';
        state.error = null;
      })
      .addCase(searchDuts.fulfilled, (state, action) => {
        state.data = action.payload;
        state.status = 'idle';
      })
      .addCase(searchDuts.rejected, (state, action) => {
        state.status = 'error';
        state.error = action.payload;
      });
  }
});

export const { fetchDuts,  addDut ,reset } = dutSlice.actions;
export default dutSlice.reducer;
