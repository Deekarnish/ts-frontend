import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  buttonExpand: false,
  indicatorExpand: false,
  screenExapand: false,
  ocrExpand: false,
  keyPadExapand: false,
  propertiesGeneral:true,
  propertiesRegion:false,
  propertiesGlobal:false,
  inspectorPanel:false,
  ocrGeneral:false
};

const hmiOptionsSlice = createSlice({
    name: "hmipage",
    initialState,
    reducers: {
      setFeatureExpand(state, action) {
        const { feature, value } = action.payload;

        // Update the specified feature's state
        if (feature in state) {
          state[feature] = value;
        }
      },
      disableAllAndEnableOption(state, action) {
        const featureToEnable = action.payload;
        
        // Reset all features to their initial values
        Object.keys(state).forEach((key) => {
          state[key] = initialState[key];
        });
  
        // Enable the passed feature
        if (featureToEnable in state) {
          state[featureToEnable] = true;
        }
      },
      reset: () => initialState,
    },
  });
  
export const {
  disableAllAndEnableOption,
  setFeatureExpand,
  reset
} = hmiOptionsSlice.actions;
export default hmiOptionsSlice.reducer;
