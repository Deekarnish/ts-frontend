// dutButtonSlice.js

import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import axiosInstance from '../../api/axiosConfig';

/**
 * Define the base URL for the API.
 * Replace 'http://your-api-url.com/api/dutButtons' with your actual API endpoint.
 */


/**
 * Initial state for the Redux slice.
 * This includes the list of DUT buttons, loading state, error messages,
 * and other specific parameters relevant to DUT buttons.
 */
const initialState = {
  screens: [],            // List of DUT buttons fetched from the server
  loadingScreen: false,         // Indicates if an API call is in progress
  error: null,            // Stores error messages from failed API calls
  selected: null,   // Stores a single DUT button's details
  imgurl: null,
  name: "",
  startX: 0,
  startY: 0,
  width: 0,
  height : 0,
  x: 0,
  y: 0,
  exposure: 500,
  light: false,
  duration: 50,
  backposition: 50,
  force: 50,
  create:false,
  update:false,
  id:false,
  position:"",
  activeIndex:""
};

/**
 * Async thunk to fetch all DUT buttons.
 * Makes a GET request to the API and handles success and error responses.
 */
export const fetchDutScreens = createAsyncThunk(
  'dutScreen/fetchAll',
  async (_, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.get('');
      return response.data; // Assumes the response data is an array of buttons
    } catch (error) {
      // Handles errors and passes them to the reducer
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

/**
 * Async thunk to fetch a single DUT button by its ID.
 * Makes a GET request to the API with the button's ID.
 */
export const fetchDutScreenById = createAsyncThunk(
  'dutScreen/fetchById',
  async (id, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.get(`/screens_by_dut/${id}`);
      return response.data; // Assumes the response data is the button object
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

/**
 * Async thunk to create a new DUT button.
 * Makes a POST request to the API with the new button's data.
 */

let ongoingRequest = null; // To track the ongoing request
export const createDutScreen = createAsyncThunk(
  'dutScreen/create',
  async (dutScreenData, { rejectWithValue }) => {
    try {
              // Check if there's already an ongoing request
      if (ongoingRequest) {
        return rejectWithValue('A request is already in progress. Please wait.');
      }

      // Create an AbortController for the current request
      const abortController = new AbortController();
      ongoingRequest = abortController;
      const response = await axiosInstance.post('/dut_screens/', dutScreenData,{
      signal: abortController.signal,
      });
      ongoingRequest = null;
      return response.data; // Assumes the response data is the created button
    } catch (error) {
      ongoingRequest = null;
      if (axiosInstance.isCancel(error)) {
        // Handle request cancellation if needed
        return rejectWithValue('Request canceled');
      }
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

/**
 * Async thunk to update an existing DUT button by its ID.
 * Makes a PUT request to the API with the button's ID and updated data.
 */
export const updateDutScreen = createAsyncThunk( 
  'dutScreen/update',
  async ({ id, dutScreenData }, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.put(`/update_dut_screens/${id}`, dutScreenData);
      return response.data; // Assumes the response data is the updated button
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

/**
 * Async thunk to delete a DUT button by its ID.
 * Makes a DELETE request to the API with the button's ID.
 */
export const deleteDutScreen = createAsyncThunk(
  'dutScreen/delete',
  async (id, { rejectWithValue }) => {
    try {
      const response = await axiosInstance.delete(`/delete_dut_screens/${id}`);
      return response.data; // Assumes the response data contains confirmation
    } catch (error) {
      return rejectWithValue(error.response?.data || error.message);
    }
  }
);

/**
 * Creates the Redux slice for DUT buttons.
 * Defines reducers for synchronous actions and extraReducers for handling async thunks.
 */
const dutScreenSlice = createSlice({
  name: 'dutScreenList',
  initialState,
  reducers: {
    /**
     * Reducer to set multiple parameters in the state.
     * Accepts an object payload where keys match the state properties to be updated.
     */
    setParamsSCreen(state, action) {
      // Iterate over the keys in the payload and update corresponding state properties
      Object.keys(action.payload).forEach(key => {
        if (key in state) {
          state[key] = action.payload[key];
        }
      });
    },
    clearScreenState(state) {
      // Reset the state to its initial values
      return {
        ...initialState,       // Reset all fields to their initial values
        screens: state.screens // Preserve the current buttons array
      };
    },
    // Additional synchronous reducers can be added here if needed
    reset: () => initialState,
  },
  extraReducers: (builder) => {
    builder
      // Handles pending, fulfilled, and rejected states for fetching all buttons
      .addCase(fetchDutScreens.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchDutScreens.fulfilled, (state, action) => {
        state.loading = false;
        state.screens = action.payload;
      })
      .addCase(fetchDutScreens.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Handles pending, fulfilled, and rejected states for fetching a button by ID
      .addCase(fetchDutScreenById.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(fetchDutScreenById.fulfilled, (state, action) => {
        state.loading = false;
        state.selectedScreen = action.payload;
        state.screens = action.payload
      })
      .addCase(fetchDutScreenById.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Handles pending, fulfilled, and rejected states for creating a new button
      .addCase(createDutScreen.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(createDutScreen.fulfilled, (state, action) => {
        state.loading = false;
        state.screens.push(action.payload);
        state.id = action.payload.id
      })
      .addCase(createDutScreen.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Handles pending, fulfilled, and rejected states for updating a button
      .addCase(updateDutScreen.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(updateDutScreen.fulfilled, (state, action) => {
        state.loading = false;
        const index = state.screens.findIndex(button => button.id === action.payload.id);
        if (index !== -1) {
          state.screens[index] = action.payload;
        }
      })
      .addCase(updateDutScreen.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      })
      
      // Handles pending, fulfilled, and rejected states for deleting a button
      .addCase(deleteDutScreen.pending, (state) => {
        state.loading = true;
        state.error = null;
      })
      .addCase(deleteDutScreen.fulfilled, (state, action) => {
        state.loading = false;
        // Assumes the action.meta.arg contains the ID of the deleted button
        const deletedId = action.meta.arg;
        state.screens = state.screens.filter(screen => screen.id !== deletedId);
      })
      .addCase(deleteDutScreen.rejected, (state, action) => {
        state.loading = false;
        state.error = action.payload;
      });
  },
});

/**
 * Exporting the synchronous action creators and the reducer.
 * The reducer will be used to configure the Redux store.
 */
export const { setParamsSCreen  , clearScreenState ,reset} = dutScreenSlice.actions;
export default dutScreenSlice.reducer;
