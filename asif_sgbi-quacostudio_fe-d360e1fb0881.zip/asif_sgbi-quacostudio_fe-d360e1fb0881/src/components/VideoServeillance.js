import React, { useEffect, useRef } from "react";
import { Box, Typography } from "@mui/material";

const VideoSurveillance = () => {
  const canvasRef = useRef(null);

  return (
    <Box
      sx={{
        border: "1px solid #4B4B50",
        ml: 1,
        borderRadius: 1,
        height: "90%",
        width: "95%", // Make the Box responsive
        boxShadow:
          "rgba(9, 30, 66, 0.25) 0px 4px 8px -2px, rgba(9, 30, 66, 0.08) 0px 0px 0px 1px",
        position: "relative", // Ensures child elements are positioned relative to this box
        overflow: "hidden", // Ensures the floating text stays within the box
      }}
    >
      <Box sx={{ textAlign: "center" ,position:"absolute",top:0,zIndex:3,width:"100%"}}>
        {/* <Typography
          sx={{
            fontSize: "14px", // Adjusts the font size
            fontWeight: "bold", // Makes the text bold
            color: "#0058BF", // Sets the text color
            bgcolor:"transparent",
            textTransform: "uppercase", // Transforms the text to uppercase
            letterSpacing: "1.5px", // Adds space between letters
            mb: 2, // Adds margin to the bottom
            // pt: 2, // Adds padding to the top
            fontFamily: "'Roboto', sans-serif", // Sets a custom font family
            whiteSpace: "nowrap", // Prevents text from wrapping
            animation: "floatText 10s linear infinite", // Applies the animation
            "@keyframes floatText": {
              "0%": {
                transform: "translateX(100%)", // Start position off-screen right
              },
              "100%": {
                transform: "translateX(-100%)", // End position off-screen left
              },
            },
          }}
        >
          Surveillance Camera
        </Typography> */}
      </Box>
      <Box
        sx={{
          width: "100%",
          height: "100%", // Deduct space for the top Typography
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
        }}
      >
        <img
          src={`${process.env.REACT_APP_BASE_SV_URL}/my_camera`}
          // src={dut}
          width="100%"
          height="100%"
          alt="video"
          id="video-stream"
          // crossOrigin="anonymous"
          style={{
            display: "block",
            position: "absolute",
            zIndex: 2,
            // objectFit: "contain", // Maintain aspect ratio, don't stretch
          }}
        />
      </Box>
      {/* <Box sx={{ width: "100%", position: "absolute", bottom: 0, left: 0 }}>
        <Typography
          sx={{
            fontSize: 13,
            color: "#96989B",
            whiteSpace: "nowrap", // Prevents text from wrapping
            animation: "floatText 10s linear infinite", // Applies the animation
            "@keyframes floatText": {
              "0%": {
                transform: "translateX(100%)", // Start position off-screen right
              },
              "100%": {
                transform: "translateX(-100%)", // End position off-screen left
              },
            },
          }}
        >
          Under development
        </Typography>
      </Box> */}
    </Box>
  );
};

export default VideoSurveillance;
