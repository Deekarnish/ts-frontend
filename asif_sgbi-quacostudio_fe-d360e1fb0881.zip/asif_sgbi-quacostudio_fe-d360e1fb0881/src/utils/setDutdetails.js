

export default function setButtonDetails(details){
    const roi = splitRectString(details.button_roi)
    const imgurl = base64ToImageUrl(details.button_image, 'image/png')
    const buttondetails = {...details , ...roi , imgurl:imgurl , name:details.button_name ,position: details.button_position}
    
    return buttondetails
}


function splitRectString(str) {
    // Split the string by colon
    const parts = str.split(':');
    
    // Ensure there are exactly 4 parts
    if (parts.length !== 4) {
        throw new Error('Invalid format. Expected format: "top:left:right:bottom".');
    }
    
    // Convert parts to numbers and return the object
    return {
        startX: parseFloat(parts[0]),
        startY: parseFloat(parts[1]),
        width: parseFloat(parts[2]),
        height: parseFloat(parts[3]),
    };
}

export function base64ToImageUrl(base64String, mimeType = 'image/jpeg') {
    return `data:${mimeType};base64,${base64String}`;
}