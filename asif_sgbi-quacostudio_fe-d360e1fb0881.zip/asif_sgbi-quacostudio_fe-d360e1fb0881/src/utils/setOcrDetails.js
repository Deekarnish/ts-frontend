

export default function setOcrDetails(details){
    const roi = splitRectString(details.ocr_roi)
    // const imgurl = base64ToImageUrl(details.button_image, 'image/png')
    const screendetails = {...details , ...roi  , name:details.ocr_name}
    
    return screendetails
}


function splitRectString(str) {
    // Split the string by colon
    const parts = str.split(':');
    
    // Ensure there are exactly 4 parts
    if (parts.length !== 4) {
        throw new Error('Invalid format. Expected format: "top:left:right:bottom".');
    }
    
    // Convert parts to numbers and return the object
    return {
        sX: parseFloat(parts[0]),
        sY: parseFloat(parts[1]),
        sW: parseFloat(parts[2]),
        sH: parseFloat(parts[3]),
    };
}