
 export function convertLBH(lbh){
    const lbhString = lbh;
    // Split the string by the colon (":") delimiter
    const [l, b, h] = lbhString.split(':');

    // Convert the string values to numbers (optional, if you need them as numbers)
    const length = parseFloat(l);
    const breadth = parseFloat(b);
    const height = parseFloat(h);

    return {length:length, breadth: breadth, height: height}
 }

 export function splitValues(input) {
   return input.split(':');
 }
 //function for convert pixel values to mm assuming that  DPI of the screen is 96  mm = pixel / DPI * 25.4
 export const pixelsToMM = (pixels) => (pixels / 96) * 25.4;

 export const loadScript = (src) => {
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = src;
    script.async = true;
    script.onload = () => resolve(script);
    script.onerror = () => reject(new Error(`Failed to load script: ${src}`));
    document.body.appendChild(script);
  });
};


export const areDocumentsDifferent = (doc1, doc2) => {
  const keys1 = Object.keys(doc1);
  const keys2 = Object.keys(doc2);

  // Find the common keys between both documents
  const commonKeys = keys1.filter(key => keys2.includes(key));

  // Compare the values of the common keys
  for (let key of commonKeys) {
    if (doc1[key] !== doc2[key]) {
      return true; // Return true if any common key has different values
    }
  }

  return false; // Return false if all common keys have the same values
};

