import './App.css';
import { createBrowserRouter, createRoutesFromElements ,Route,RouterProvider } from 'react-router-dom';
import { ThemeProvider, createTheme } from '@mui/material/styles';
import LayoutComponent from './components/LayoutComponent';
import { LandingPage } from './Pages/LandingPage';
import HmiPage from './Pages/HmiPage';
import { useState } from 'react';
import HapiPage from './Pages/HapiPage';

function App() {
 const router = createBrowserRouter(createRoutesFromElements(
  <Route path='/' element={<LayoutComponent/>}>
    <Route index element={<LandingPage/>}></Route>
    <Route path='/hmi' element={<HmiPage/>}></Route>
    <Route path='/hapi' element={<HapiPage/>}></Route>
  </Route>
 ))

   // State to manage theme mode
   const [darkMode, setDarkMode] = useState(false)

   // Toggle between dark mode and light mode
   const handleThemeChange = () => {
     setDarkMode(!darkMode);
   };
 
   // Create the dark theme
   const darkTheme = createTheme({
     palette: {
       mode: 'dark',
       primary: {
         main: '#00000',
       },
     },
     typography: {
      "fontFamily": `Inter`,
     },
     breakpoints: {
      values: {
        xs: 0,
        sm: 600,
        md: 900,
        lg: 1200,
        xl: 1600,
      },
    },
   });
 
   // Create the light theme
   const lightTheme = createTheme({
     palette: {
       mode: 'light',
       primary: {
         main: '#FFFFFF',
         button:'#0069E6'
 
       },
     },
    //  typography: {
    //   "fontFamily": `Inter`,
    //  },
     breakpoints: {
      values: {
        xs: 0,
        sm: 600,
        md: 900,
        lg: 1200,
        xl: 1600,
      },
    },
   });

  return (
    <div className="App">
      <ThemeProvider theme={darkMode ? darkTheme : lightTheme}>
          <RouterProvider router={router}/>
      </ThemeProvider>
    </div>
  );
}

export default App;