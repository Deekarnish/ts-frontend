import axiosInstance from "./axiosConfig";

export const navigationApis = async (path) => {
  try {
    const response = await axiosInstance.get(path);
    console.log(response.data); // Handle the response data
  } catch (error) {
    console.error("Error fetching data:", error); // Handle error
  }
  // return response
};

export const robotMovementApi = async (step, direction) => {
  try {
    const response = await axiosInstance.post(
      `/navbar_movement/${parseInt(step)}/${direction}`
    );
    console.log(response.data); // Handle the response data
    return response.data;
  } catch (error) {
    console.error("Error fetching data:", error); // Handle error
  }
  // return response
};

export const onClikNavigationLeft = async (x, y,) => {
  try {
    const response = await axiosInstance.post(
      `/onclick_navigation/${parseInt(x)}/${parseInt(y)}/`, // Endpoint URL
      // { image_base64: imageData } // Body parameter`
    );
    console.log(response.data); // Handle the response data
    return response.data; // Return response data if needed
  } catch (error) {
    console.error("Error fetching data:", error); // Handle error
    //   throw error; // Optional: rethrow error if you want to handle it further up the call stack
  }
};

export const onClikNavigationRight = async (
  x,
  y,
  duration,
  back_pos,
  force
) => {
  try {
    const response = await axiosInstance.post(
      `/right_onclick_navigation/${parseInt(x)}/${parseInt(
        y
      )}/${duration}/${back_pos}/${force}/`, // Endpoint URL
      // { image_base64: imageData } // Body parameter
    );
    console.log(response.data); // Handle the response data
    return response.data; // Return response data if needed
  } catch (error) {
    console.error("Error fetching data:", error); // Handle error
    //   throw error; // Optional: rethrow error if you want to handle it further up the call stack
  }
};

export const movetoElementPosition = async (pos) => {
  try {
    const response = await axiosInstance.post(`/move_to_element_pos/${pos}/`);
    return response.data; // Handle the response data
  } catch (error) {
    console.error("Error fetching data:", error); // Handle error
  }
  // return response
};

export const getScreenNameByElementId = async (elem_id) => {
  try {
    const response = await axiosInstance.get(
      `/get_screen_by_element/${elem_id}/`
    );
    return response.data; // Handle the response data
  } catch (error) {
    console.error("Error fetching data:", error); // Handle error
  }
  // return response
};

export const hapiLowLevelScriptRun = async (api, elem_id) => {
  try {
    const response = await axiosInstance.get(
      `/low_level_apitest/${api}/${elem_id}/`
    );
    return response.data; // Handle the response data
  } catch (error) {
    console.error("Error fetching data:", error); // Handle error
  }
  // return response
};
export const runScriptsSequentially = async (hapiScriptList, onApiCall, isRunningRef, isPausedRef) => {
  for (const item of hapiScriptList) {
    if (!isRunningRef.current) {
      console.log("Script execution stopped.");
      return;
    }

    if (onApiCall) {
      onApiCall(item.api, item.order);
    }

    try {
      // Wait while paused
      while (isPausedRef.current) {
        await new Promise(resolve => setTimeout(resolve, 100));
      }

      const result = await hapiLowLevelScriptRun(item.api, item.element_id);
      console.log("Script run result:", result);
      let elem = item.element_id.split(':')
      if (onApiCall && elem[0] === "OCR") {
        onApiCall(item.api, item.order, result);  // Send the result as the third argument
      }
    } catch (error) {
      console.error("Error running script:", error);
      // Decide how to handle errors here, e.g., continue to the next script or stop execution.
    }
  }
};


export const cropImageApi = async (x, y ,x2 ,y2) => {
  try {
    const response = await axiosInstance.post(`/crop_btn/${parseInt(x)}/${parseInt(y)}/${parseInt(x2)}/${parseInt(y2)}`);
    return response.data; // Handle the response data
  } catch (error) {
    console.error("Error fetching data:", error); // Handle error
  }
  // return response
};
export const swipeCommandApi = async (script) => {
  try {
    const response = await axiosInstance.post(`/swipe_pxl_to_mm/${script}`);
    return response.data; // Handle the response data
  } catch (error) {
    console.error("Error fetching data:", error); // Handle error
  }
  // return response
};
export const cropElementApi = async (data) => {
  try {
    const response = await axiosInstance.post(`/crop_element/`,data);
    return response.data; // Handle the response data
  } catch (error) {
    console.error("Error fetching data:", error); // Handle error
  }
  // return response
};

export const runSingleScript = async (scriptItem, onApiCall, isRunningRef, isPausedRef) => {
  if (!isRunningRef.current) {
    console.log("Script execution stopped.");
    return;
  }

  if (onApiCall) {
    onApiCall(scriptItem.api, scriptItem.order);
  }

  try {
    // Wait while paused
    while (isPausedRef.current) {
      await new Promise(resolve => setTimeout(resolve, 100));
    }

    const result = await hapiLowLevelScriptRun(scriptItem.api, scriptItem.element_id);
    console.log("Script run result:", result);

    // Check if the script is related to OCR and send the result as the third argument
    let elem = scriptItem.element_id.split(':');
    if (onApiCall && elem[0] === "OCR") {
      onApiCall(scriptItem.api, scriptItem.order, result);  // Pass the result to onApiCall as the third argument
    }
  } catch (error) {
    console.error("Error running script:", error);
    // Handle error as needed (e.g., notify the user, retry, or log the error)
  }
};

export default navigationApis;
