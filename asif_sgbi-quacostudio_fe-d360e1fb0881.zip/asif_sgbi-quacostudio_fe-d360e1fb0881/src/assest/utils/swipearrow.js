

export const drawLineWithArrow = (
    ctx, 
    startX, 
    startY, 
    endX, 
    endY, 
    gapOffsetX = 0, 
    gapOffsetY = 0, 
    arrowLength = 20, // Length of arrowhead
    arrowAngle = Math.PI / 6 // Angle of arrowhead (30 degrees)
) => {
    // Calculate adjusted positions based on gap offset
    const adjustedStartX = startX + gapOffsetX;
    const adjustedStartY = startY + gapOffsetY;
    const adjustedEndX = endX + gapOffsetX;
    const adjustedEndY = endY + gapOffsetY;

    // Draw the main line
    ctx.beginPath();
    ctx.moveTo(adjustedStartX, adjustedStartY);
    ctx.lineTo(adjustedEndX, adjustedEndY);
    ctx.strokeStyle = "green"; // Line color
    ctx.lineWidth = 4; // Line width
    ctx.stroke();

    // Calculate the angle of the line
    const angle = Math.atan2(adjustedEndY - adjustedStartY, adjustedEndX - adjustedStartX);

    // Calculate the points for the arrowhead
    const arrowX1 = adjustedEndX - arrowLength * Math.cos(angle - arrowAngle);
    const arrowY1 = adjustedEndY - arrowLength * Math.sin(angle - arrowAngle);
    const arrowX2 = adjustedEndX - arrowLength * Math.cos(angle + arrowAngle);
    const arrowY2 = adjustedEndY - arrowLength * Math.sin(angle + arrowAngle);

    // Draw the two sides of the arrowhead
    ctx.beginPath();
    ctx.moveTo(adjustedEndX, adjustedEndY);
    ctx.lineTo(arrowX1, arrowY1);
    ctx.lineTo(arrowX2, arrowY2);
    ctx.lineTo(adjustedEndX, adjustedEndY);
    ctx.fillStyle = "green"; // Arrowhead color
    ctx.fill();
};

export default drawLineWithArrow