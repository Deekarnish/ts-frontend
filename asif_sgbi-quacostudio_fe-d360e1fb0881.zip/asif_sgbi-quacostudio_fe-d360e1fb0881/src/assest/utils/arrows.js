import uparrow from '../icons/arrowup.svg'
import downarrow from '../icons/arrowdown.svg'
import leftarrow from '../icons/arrowleft.svg'
import rightarrow from '../icons/arrowright.svg'

export  const UpArrow = () =>{ return  <img src={uparrow} alt="arrow up" style={{ width: '24px', height: '24px' }} />};

export const DownArrow = () =>{ return  <img src={downarrow} alt="arrow down" style={{ width: '24px', height: '24px' }} />};

export const LeftArrow= () =>{ return  <img src={leftarrow} alt="arrow left" style={{ width: '24px', height: '24px' }} />};

export const RightArrow = () =>{ return  <img src={rightarrow} alt="arrow right" style={{ width: '24px', height: '24px' }} />};

export default UpArrow;

