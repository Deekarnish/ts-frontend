import * as React from "react";
import Box from "@mui/material/Box";
import ListItem from "@mui/material/ListItem";
import { duration, List, Menu, MenuItem } from "@mui/material";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemText from "@mui/material/ListItemText";
import { FixedSizeList } from "react-window";
import { useDispatch, useSelector } from "react-redux";
import { splitValues } from "../utils/funcs";
import { clearHapiState, disableEnableMouseAssist, setHapiValues } from "../components/store/hapiSlice";
import deleteIcon from "../assest/icons/delete-icon.svg";
import DeleteConfirmationModal from "../components/modals/DeleteConfirmationModal";
import {
  deleteHapiScript,
  setHapiScriptValues,
} from "../components/store/hapiScriptSlice";
import SingleScripTest from "./RunSingleScript";

const menusx = {
  width: 120,
  "&:hover": {
    borderRadius: 2,
    // background:"linear-.(90deg, rgba(11,139,217,1) 0%, rgba(46,114,195,1) 72%, rgba(65,101,240,1) 99%)",
    bgcolor: "#3391FF",
    color:"#FEFEFE"
  },
};
const ButtonActive = {
  mb: 1,
  borderRadius: 2,
  ml: 1,
  mr: 1,
  height: 35,
  // color: "white",
  border: "1px solid #3391FF",
};

const ButtonNormalState = {
  mb: 1,
  borderRadius: 2,
  mr: 1,
  ml: 1,
  height: 35,
  "&:hover": {
    bgColor: "#CDE5FA",
  },
};

export default function ScriptList() {
  const { hapiScriptList, hapiScriptIndex, hapiScriptRunIndex } = useSelector(
    (state) => state.hapiScripts
  );
  const dispatch = useDispatch();
  const [scriptId, setScriptId] = React.useState(null);
  const [anchorEl, setAnchorEl] = React.useState(false);
  const [openDeleteConfirmation, setOpenDeleteConfirmation] =
    React.useState(false);

  const handleDelete = () => {
    dispatch(deleteHapiScript(scriptId));
    setOpenDeleteConfirmation(false);
  };

  const handleClickScript = (item, index) => {
    const values = splitValues(item.api);
    let scriptData = {};
    dispatch(setHapiScriptValues({ feature: "hapiScriptIndex", value: index }));
    dispatch(setHapiScriptValues({ feature: "scriptId", value: item.id }));
   
    // dispatch(
    //   setHapiValues({ feature: "element_id", value: item.element_id })
    // );
    const type = item.element_id.split(":");

    if (type && type[0]) {
      switch (type[0]) {
        case "BTN":
          dispatch(setHapiValues({ feature: "hapiType", value: "BTN" }));
          if (values[0] === "f") {
            if (values[1] === "str") {
              dispatch(setHapiValues({ feature: "command", value: "f:str" }));
              dispatch(
                setHapiValues({ feature: "hapiAction", value: "Single tap" })
              );
              scriptData = {
                elementName: values[2],
                duration: values[3],
                backposition: values[4],
                force: values[5],
                hapiApiName: item.api,
                hapiScriptName: item.name,
                element_id:item.element_id
              };
            } else if (values[1] === "mtr") {
              dispatch(setHapiValues({ feature: "command", value: "f:mtr" }));
              dispatch(
                setHapiValues({ feature: "hapiAction", value: "Multi tap" })
              );
              scriptData = {
                elementName: values[2],
                taps: values[3],
                duration: values[4],
                backposition: values[5],
                force: values[6],
                hapiApiName: item.api,
                hapiScriptName: item.name,
                element_id:item.element_id
              };
            }
          } else if (values[0] === "m") {
            dispatch(setHapiValues({ feature: "command", value: "m" }));
            dispatch(setHapiValues({ feature: "hapiAction", value: "Move" }));
            scriptData = {
              elementName: values[1],
              hapiScriptName: item.name,
              element_id:item.element_id
            };
          }
          break;
    
        case "SCR":
          if (values[0] === "m") {
            dispatch(setHapiValues({ feature: "hapiType", value: "SCR" }));
            dispatch(setHapiValues({ feature: "command", value: "m" }));
            dispatch(setHapiValues({ feature: "hapiAction", value: "Move" }));
            scriptData = {
              elementName: values[1],
              hapiScriptName: item.name,
              element_id:item.element_id
            };
          }
          break;
    
        case "CAP":
          dispatch(setHapiValues({ feature: "hapiType", value: "CAP" }));
          dispatch(setHapiValues({ feature: "command", value: "capture" }));
          dispatch(
            setHapiValues({ feature: "hapiAction", value: "Image capture" })
          );
          scriptData = {
            elementName: values[1],
            hapiScriptName: item.name,
            element_id:item.element_id
          };
          break;
    
        case "MAP":
          dispatch(setHapiValues({ feature: "hapiType", value: "MAP" }));
          dispatch(setHapiValues({ feature: "command", value: "f:str" }));
          dispatch(disableEnableMouseAssist("tReturn"));
          dispatch(
            setHapiValues({ feature: "hapiAction", value: "Mouse Assist" })
          );
          scriptData = {
            elementName: "MAP:0",
            cx: values[2],
            cy: values[3],
            duration: values[4],
            tReturn: true,
            backposition: values[5],
            force: values[6],
            hapiApiName: item.api,
            hapiScriptName: item.name,
            element_id:item.element_id
          };
          break;
    
        case "MAT":
          dispatch(setHapiValues({ feature: "hapiType", value: "MAT" }));
          dispatch(setHapiValues({ feature: "command", value: "f:st" }));
          dispatch(
            setHapiValues({ feature: "hapiAction", value: "Mouse Assist" })
          );
          scriptData = {
            elementName: "MAT:0",
            cx: values[2],
            cy: values[3],
            duration: values[4],
            backposition: values[5],
            force: values[6],
            touch: true,
            hapiApiName: item.api,
            hapiScriptName: item.name,
            element_id:item.element_id
          };
          break;
    
        case "SWS":
          dispatch(setHapiValues({ feature: "hapiType", value: "SWS" }));
          dispatch(setHapiValues({ feature: "command", value: "s" }));
          dispatch(
            setHapiValues({ feature: "hapiAction", value: "Swipe" })
          );
          scriptData = {
            elementName: "SWS:0",
            sx: values[1],
            sy: values[2],
            ex: values[3],
            ey: values[4],
            speed: values[5],
            force: values[6],
            hapiApiName: item.api,
            hapiScriptName: item.name,
            element_id:item.element_id
          };
          break;
    
        case "SWD":
          dispatch(setHapiValues({ feature: "hapiType", value: "SWD" }));
          dispatch(setHapiValues({ feature: "command", value: "s:d" }));
          dispatch(
            setHapiValues({ feature: "hapiAction", value: "Swipe" })
          );
          scriptData = {
            elementName: "SWD:0",
            sx: values[2],
            sy: values[3],
            ex: values[4],
            ey: values[5],
            speed: values[6],
            force: values[7],
            gap: values[8],
            hapiApiName: item.api,
            hapiScriptName: item.name,
            element_id:item.element_id
          };
          break;
        case "OCR":
          dispatch(setHapiValues({ feature: "hapiType", value: "OCR" }));
          dispatch(setHapiValues({ feature: "command", value: "ocr" }));
          dispatch(
            setHapiValues({ feature: "hapiAction", value: "OCR"})
          );
          scriptData = {
            elementName: values[2],
            screenName:values[1],
            hapiApiName: item.api,
            hapiScriptName: item.name,
            element_id:item.element_id
          };
          // console.log(scriptData)
          break;
        case "OCT":
          dispatch(setHapiValues({ feature: "hapiType", value: "OCT" }));
          dispatch(setHapiValues({ feature: "command", value: "ocr_touch" }));
          dispatch(
            setHapiValues({ feature: "hapiAction", value: "Touch OCR"})
          );
          scriptData = {
            elementName: values[2],
            screenName:values[1],
            text:values[3],
            matching:values[5],
            duration: values[6],
            backposition: values[7],
            force: values[8],
            ox:values[9],
            oy:values[10],
            hapiApiName: item.api,
            hapiScriptName: item.name,
            element_id:item.element_id
          };
          // console.log(scriptData)
          break;
        case "EMT":
          dispatch(setHapiValues({ feature: "hapiType", value: "EMT" }));
          dispatch(setHapiValues({ feature: "command", value: "f:str" }));
          dispatch(
            setHapiValues({ feature: "hapiAction", value: "Single tap" })
          );
          scriptData = {
            duration: values[3],
            backposition: values[4],
            force: values[5],
            elementName: values[2],
            hapiApiName: item.api,
            hapiScriptName: item.name,
            element_id:item.element_id
          };
          break;
        case "DLY":
          dispatch(setHapiValues({ feature: "hapiType", value: "DLY" }));
          dispatch(setHapiValues({ feature: "command", value: "delay" }));
          dispatch(
            setHapiValues({ feature: "hapiAction", value: "Delay" })
          );
          scriptData = {
            delay: values[1],
            hapiApiName: item.api,
            hapiScriptName: item.name,
            element_id:item.element_id
          };
        break;
  
        default:
          break;
      }
    }
    
    // Loop through each key-value pair in hapiScriptData
    dispatch(clearHapiState());
    for (const feature in scriptData) {
      // console.log(scriptData, "data");
      if (scriptData.hasOwnProperty(feature)) {
        dispatch(setHapiValues({ feature, value: scriptData[feature] }));
      }
    }
    dispatch(setHapiValues({ feature: "hapiApiName", value: item.api }));
  };
  const handleClose = () => {
    setAnchorEl(false);
  };
  const handleRightClick = (e, item, index) => {
    setAnchorEl(e.currentTarget);
    setScriptId(item.id);
  };
  const handleClickDelete = () => {
    setOpenDeleteConfirmation(true);
    handleClose();
  };
  const rightClickMenu = () => {
    return (
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)} // Opens the submenu on click
        onClose={handleClose}
        sx={{ width: 350 }}
        PaperProps={{
          sx: {
            pl: 1,
            pr: 1,
            border: "1px solid #3391FF",
            borderRadius: 2,
          },
        }}
        anchorOrigin={{
          vertical: "top",
          horizontal: "right", // Aligns the submenu to the right side of the main menu
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "left", // Ensures the submenu opens to the right
        }}
      >
        <MenuItem sx={menusx} name="move" onClick={(e) => handleClickDelete()}>
          {""}
          <img
            src={deleteIcon}
            alt="indicator icon"
            style={{
              width: "20px",
              height: "20px",
              textTransform: "none",
              marginRight: "5px",
            }}
          />
          Delete
        </MenuItem>
      </Menu>
    );
  };
  return (
    <Box
      sx={{
        width: "100%",
        maxHeight: "45%",
        maxWidth: 360,
        bgcolor: "background.paper",
        overflowY: "auto",
      }}
    >
      {hapiScriptList.length > 0 && (
        <List component="nav" aria-label="secondary mailbox folder">
          {hapiScriptList.map((item, index) => (
            <ListItemButton
              key={index}
              sx={
                hapiScriptRunIndex === item.order
                  ? {
                      ...ButtonActive,
                      backgroundColor: "#8CC9FF",
                      color: "white",
                      pl: 4,
                    } // Highlight the button when hapiScriptRunIndex matches item.order
                  : index === hapiScriptIndex
                  ? ButtonActive // Apply active style when index matches hapiScriptIndex
                  : ButtonNormalState // Apply normal state
              }
              onClick={(e) => handleClickScript(item, index)}
              onContextMenu={(e) => {
                e.preventDefault();
                handleRightClick(e, item, index); // Function to handle right-click
              }}
            >
              <ListItemText
                sx={{ fontWeight: "normal" }} // Normal text styling
                primary={item.name}
              />
              {index === hapiScriptIndex && <SingleScripTest edit={false}/>}
            </ListItemButton>
          ))}
        </List>
      )}
      {rightClickMenu()}
      <DeleteConfirmationModal
        openDeleteConfirmation={openDeleteConfirmation}
        setOpenDeleteConfirmation={setOpenDeleteConfirmation}
        handleDelete={handleDelete}
      />
    </Box>
  );
}
