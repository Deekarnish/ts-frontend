import {
  Box,
  Button,
  IconButton,
  Typography,
  Grid,
  TextField,
  Checkbox,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import ArrowCircleDown from "../assest/icons/arrow-right-circle.svg";
import ArrowCircleRight from "../assest/icons/arrow-circle.svg";
import { useDispatch, useSelector } from "react-redux";
import { setFeatureExpand } from "../components/store/hmiOptionsSlice";
import demiCrop from "../assest/images/694979.png";
import editIcon from "../assest/icons/edit-icon.svg";
import { enableVideoFeedCanvas } from "../components/store/videoFeedSlice";
import { setHapiFeature } from "../components/store/hapiPageSlice";

const SetResponse = () => {
  const feature = useSelector((state) => state.page);
  const [sides, setSides] = useState({ top: 0, left: 0, bottom: 0, right: 0 });
  const dispatch = useDispatch();
  const vFeed = useSelector((state) => state.vFeed);
  const { hapiResponse } = useSelector((state) => state.hapipage);

  const handleExpandClick = () => {
    dispatch(
      setHapiFeature({
        feature: "hapiResponse",
        value: !hapiResponse,
      })
    );
  };

  return (
    <Box
      sx={{
        border: "1px solid #DFE3EB",
        boxShadow:
          "rgba(9, 30, 66, 0.25) 0px 4px 8px -2px, rgba(9, 30, 66, 0.08) 0px 0px 0px 1px",
        m: 1,
        borderRadius: 2,
        "&:hover": {
          borderColor: "#33BFFF", // Change border color on hover
        },
      }}
    >
      <Box>
        <IconButton
          sx={{ "&:hover": { bgcolor: "transparent" } }}
          onClick={handleExpandClick}
        >
          <img
            src={hapiResponse ? ArrowCircleDown : ArrowCircleRight}
            alt="toggle icon"
            style={{ width: "24px", height: "24px" }}
          />
          <Typography sx={{ ml: 1 }}>Set Response flags</Typography>
        </IconButton>
      </Box>
      {hapiResponse && (
        <Box sx={{ flexDirection: "column", p: 1 }}>
          <Grid container spacing={2}>
            <Grid item xs={6}>
              <Grid item xs={12}>
                <Box
                  sx={{
                    display: "flex",
                    alignItems: "center",
                  }}
                >
                  <Checkbox />
                  <Typography
                    component="span"
                    sx={{
                      fontSize: 12,
                      whiteSpace: "nowrap",
                    }}
                  >
                    Response Code
                  </Typography>
                </Box>
              </Grid>
              <Grid item xs={12}>
                <Box
                  sx={{
                    display: "flex",
                    alignItems: "center",
                  }}
                >
                  <Checkbox />
                  <Typography
                    component="span"
                    sx={{
                      fontSize: 12,
                      whiteSpace: "nowrap",
                    }}
                  >
                    Response String
                  </Typography>
                </Box>
              </Grid>
            </Grid>
            <Grid item xs={6}>
              <Grid container>
                <Grid item xs={12}>
                  <Box
                    sx={{
                      display: "flex",
                      alignItems: "center",
                    }}
                  >
                    <Checkbox />
                    <Typography
                      component="span"
                      sx={{
                        fontSize: 12,
                        whiteSpace: "nowrap",
                      }}
                    >
                      Proof image
                    </Typography>
                  </Box>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Box>
      )}
    </Box>
  );
};

export default SetResponse;
