import {
  Box,
  Button,
  IconButton,
  Typography,
  FormHelperText,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import ArrowCircleDown from "../assest/icons/arrow-right-circle.svg";
import ArrowCircleRight from "../assest/icons/arrow-circle.svg";
import { alpha, styled } from "@mui/material/styles";
import InputBase from "@mui/material/InputBase";
import InputLabel from "@mui/material/InputLabel";
import FormControl from "@mui/material/FormControl";
import { useDispatch, useSelector } from "react-redux";
import { setHapiFeature } from "../components/store/hapiPageSlice";
import { setHapiValues } from "../components/store/hapiSlice";
import { Autorenew } from "@mui/icons-material";
import {
  setHapiScriptValues,
  updateHapiScript,
} from "../components/store/hapiScriptSlice";


const BootstrapInput = styled(InputBase)(({ theme, error }) => ({
  "label + &": {
    marginTop: theme.spacing(3),
  },
  "& .MuiInputBase-input": {
    borderRadius: 4,
    position: "relative",
    backgroundColor: theme.palette.mode === "light" ? "#F3F6F9" : "#1A2027",
    border: "1px solid",
    borderColor: error
      ? "red" // Apply red border when error exists
      : theme.palette.mode === "light"
      ? "#E0E3E7"
      : "#2D3843",
    fontSize: 16,
    width: "100%",
    padding: "10px 12px",
    transition: theme.transitions.create([
      "border-color",
      "background-color",
      "box-shadow",
    ]),
    fontFamily: [
      "-apple-system",
      "BlinkMacSystemFont",
      '"Segoe UI"',
      "Roboto",
      '"Helvetica Neue"',
      "Arial",
      "sans-serif",
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',
    ].join(","),
    "&:focus": {
      boxShadow: `${alpha(theme.palette.primary.main, 0.25)} 0 0 0 0.2rem`,
      borderColor: error ? "red" : theme.palette.primary.main, // Red border on focus if error
    },
  },
}));

const GeneralSettingsHapi = () => {
  const dispatch = useDispatch();
  const { hapiGeneral } = useSelector((state) => state.hapipage);
  const {
    hapiApiName,
    hapiScriptName,
    hapiId,
    hapiAction,
    hapiType,
    taps,
    touch,
    tReturn,
    text,
    matching,
    force,
    backposition,
    command,
    duration,
    elementName,
    nameError,
    screenName,
    speed,
    cx,
    cy,
    sx,
    sy,
    ex,
    ey,
    ox,
    oy,
    gap,
    delay,
    element_id 
  } = useSelector((state) => state.hapivalues);
  const { scriptId} = useSelector((state) => state.hapiScripts);
  const [hapiApi, setHapiApi] = useState(hapiApiName);
  const [edit, setEdit] = useState(false);
  const handleExpandClick = () => {
    if (hapiGeneral) {
      dispatch(setHapiFeature({ feature: "hapiGeneral", value: false }));
    } else {
      dispatch(setHapiFeature({ feature: "hapiGeneral", value: true }));
    }
  };
  const handleChangeName = (e) => {
    dispatch(
      setHapiValues({ feature: "hapiScriptName", value: e.target.value })
    );
    if (e.target.value) {
      dispatch(setHapiFeature({ feature: "hapiElements", value: true }));
    }
  };
  useEffect(() => {
    dispatch(setHapiFeature({ feature: "hapiGeneral", value: true }));
  }, []);

  const updateHapiData = () => {
    const hapiScriptData = {
      hapi_id: parseInt(hapiId),
      api: hapiApi,
      name: hapiScriptName,
      element_id: element_id,
    };
    if (scriptId) {
      let id = scriptId;
      dispatch(updateHapiScript({ id, hapiScriptData }));
    }
  };

  const handleUpdateHpiApi = () => {
    let api = "";
    if (hapiType === "CAP" || hapiAction === "Move") {
      api = `${command}:${elementName}:`;
      setHapiApi(api);
    } else {
      if (hapiAction === "Single tap") {
        if(hapiType === "EMT"){
        api = `${command}:${elementName}:${duration}:${backposition}:${force}:`;
        }else{
          api = `${command}:${elementName}:${duration}:${backposition}:${force}:`;
        }  
        setHapiApi(api);
      } else if (hapiAction === "Multi tap") {
        api = `${command}:${elementName}:${taps}:${duration}:${backposition}:${force}:`;
        setHapiApi(api);
      } else if (hapiAction === "Mouse Assist") {
        api = `${command}:${cx}:${cy}:${duration}:${backposition}:${force}:`;
        if (touch) {
          dispatch(
            setHapiValues({ feature: "element_id", value: "MAT:0" })
          );
        } else if (tReturn) {
          dispatch(
            setHapiValues({ feature: "element_id", value: "MAP:0" })
          );
        }
        setHapiApi(api);
      } else if (hapiAction === "Swipe") {
        if (hapiType === "SWD") {
          dispatch(
            setHapiValues({ feature: "element_id", value: "SWD:0" })
          );
          api = `${command}:${sx}:${sy}:${ex}:${ey}:${speed}:${force}:${gap}:`;
        } else if (hapiType === "SWS") {
          dispatch(
            setHapiValues({ feature: "element_id", value: "SWS:0" })
          );
          api = `${command}:${sx}:${sy}:${ex}:${ey}:${speed}:${force}:`;
        }
        setHapiApi(api);
      }else if(hapiAction === "OCR"){
        dispatch(
          setHapiValues({ feature: "element_id", value: "OCR:0" })
        );
        api = `${command}:${screenName}:${elementName}:`;
        setHapiApi(api);
      }else if(hapiAction === "Touch OCR"){
        // dispatch(
        //   setHapiScriptValues({ feature: "element_id", value: "OCT:0" })
        // );
        api = `${command}:${screenName}:${elementName}:${text}:rtn:${matching}:${duration}:${backposition}:${force}:${ox}:${oy}`;
        setHapiApi(api);
      }
      else if(hapiAction ==="Delay"){
        api =  `${command}:${delay}`;
        setHapiApi(api);
      }
    }

    dispatch(setHapiValues({ feature: "hapiApiName", value: api }));
  };
  useEffect(() => {
    handleUpdateHpiApi();
  }, [
    command,
    force,
    backposition,
    taps,
    element_id,
    elementName,
    duration,
    speed,
    cx,
    cy,
    sx,
    sy,
    ex,
    ey,
    gap,
    ox,
    oy,
    screenName,
    delay,
    text,
    matching,
  ]);
  return (
    <Box
      sx={{
        border: "1px solid #DFE3EB",
        boxShadow:
          "rgba(9, 30, 66, 0.25) 0px 4px 8px -2px, rgba(9, 30, 66, 0.08) 0px 0px 0px 1px",
        m: 1,
        borderRadius: 2,
        "&:hover": {
          borderColor: "#33BFFF", // Change border color on hover
        },
      }}
    >
      <Box display="flex" alignItems="center" justifyContent="space-between">
        <IconButton
          sx={{ "&:hover": { bgcolor: "transparent" } }}
          onClick={handleExpandClick}
        >
          <img
            src={hapiGeneral ? ArrowCircleDown : ArrowCircleRight}
            alt="toggle icon"
            style={{ width: "24px", height: "24px" }}
          />
          <Typography sx={{ ml: 1 }}>General</Typography>
        </IconButton>
        <IconButton onClick={updateHapiData}>
          {hapiGeneral && <Autorenew />}
        </IconButton>
      </Box>
      {hapiGeneral && (
        <Box sx={{ flexDirection: "column", p: 1 }}>
          <FormControl
            variant="standard"
            sx={{ width: "100%", mb: 2 }} // Adding margin-bottom for spacing
          >
            <InputLabel shrink htmlFor="bootstrap-input">
              Name
            </InputLabel>
            <BootstrapInput
              value={hapiScriptName}
              id="bootstrap-input"
              onChange={handleChangeName}
              error={!!nameError} // Pass the error prop
            />
            {nameError && (
              <FormHelperText
                sx={{ color: "red", mt: 1 }} // Set text color to red and add margin-top
              >
                {nameError}
              </FormHelperText>
            )}
          </FormControl>
          {hapiApiName && (
            <FormControl variant="standard" sx={{ width: "100%" }}>
              <InputLabel shrink htmlFor="bootstrap-input">
                Script
              </InputLabel>
              <BootstrapInput
                id="bootstrap-input"
                //   onChange={(e) => handleChange(e)}
                value={hapiApi}
              />
            </FormControl>
          )}
        </Box>
      )}
    </Box>
  );
};

export default GeneralSettingsHapi;
