import React, { forwardRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { setHapiValues } from "../components/store/hapiSlice";
import { disableVideoFeedCanvas } from "../components/store/videoFeedSlice";
import { createHapiScript } from "../components/store/hapiScriptSlice";
import { setWsStatus } from "../components/store/ApiLoadingSlice";
import { onClikNavigationLeft, onClikNavigationRight } from "../api/navigationApis";

// Use forwardRef to allow the parent component to pass the ref down
const MouseCanvasComponent = forwardRef(
  ({ width, height, canvasRect, container }, ref) => {
    const {hapiApiName ,hapiScriptName ,hapiId,touch ,autoSave  ,command , tReturn, move ,duration , backposition , force ,cx, cy} = useSelector(state => state.hapivalues)
    const { scriptId } = useSelector((state) => state.hapiScripts);

    const dispatch = useDispatch()
    
    const handleRightClickMouseAssist = async (event) => {

      event.preventDefault(); // Prevent the default context menu from appearing
      const x = event.clientX - canvasRect.left + container.scrollLeft;
      const y = event.clientY - canvasRect.top + container.scrollTop;

      try{
      const response = await onClikNavigationRight(x, y, duration, backposition, force)
      if(response){
        dispatch(setHapiValues({ feature: "cx", value: response.result.x}));
        dispatch(setHapiValues({ feature: "cy", value: response.result.y}));
        setTimeout(()=>{
          saveMouseAssist(response.result.x , response.result.y)
        },500) 
      }else{

      }
      
    }catch (error){

    }

    };

    const handleLeftClick = (event) => {
      event.preventDefault(); // Prevent any default behavior if needed
  
      const x = event.clientX - canvasRect.left + container.scrollLeft;
      const y = event.clientY - canvasRect.top + container.scrollTop;
      if(!move){
        return;
      }
      //  
      onClikNavigationLeft(x, y)
        .then((response) => {
          dispatch(setWsStatus(false));
        })
        .finally(() => {
          dispatch(setWsStatus(false));
        })
        .catch(() => {
          dispatch(setWsStatus(false));
        });
    };
    const saveMouseAssist = async (x , y) => {
        let element_id = ""
        if(touch){
            element_id = "MAT:0"
        }else if(tReturn){
            element_id = "MAP:0"
        }
        
  
      if(hapiScriptName){
        dispatch(setHapiValues({feature:"nameError", value:false}))
      }else{
        dispatch(setHapiValues({feature:"nameError", value:"* this field is required"}))
      }
      if(autoSave && hapiScriptName.length > 2 && x && y && (touch || tReturn)){
        const api =  `${command}:${x}:${y}:${duration}:${backposition}:${force}:`;
        const hapiScriptData ={
          hapi_id:parseInt(hapiId),
          api:api,
          name:hapiScriptName,
          element_id:element_id
        }
        dispatch(createHapiScript(hapiScriptData));
        let scriptName = ''
        let name = hapiScriptName.split("-")
        if (name[1]) {
          scriptName = name[0] + "-" + (parseInt(name[1]) + 1);
         }else{
          scriptName = name + "-2"
         }
        dispatch(setHapiValues({feature:"hapiScriptName", value:scriptName}))
      }else if((!scriptId && hapiScriptName.length > 2 && x && y && (touch || tReturn))){
        const api =  `${command}:${x}:${y}:${duration}:${backposition}:${force}:`;
        const hapiScriptData ={
          hapi_id:parseInt(hapiId),
          api:api,
          name:hapiScriptName,
          element_id:element_id
        }
        dispatch(createHapiScript(hapiScriptData));
       dispatch(disableVideoFeedCanvas("MouseAssist"))
      }
    };
    
    return (
      <canvas
        ref={ref}
        width={width}
        height={height}
        style={{ display: "block", position: "absolute", zIndex: 2 }}
        onClick={handleLeftClick} // Left click handler
        onContextMenu={handleRightClickMouseAssist} // Right click handler (context menu)
        // onMouseLeave={saveMouseAssist} // Mouse leave handler
      />
    );
  }
);

export default MouseCanvasComponent;
