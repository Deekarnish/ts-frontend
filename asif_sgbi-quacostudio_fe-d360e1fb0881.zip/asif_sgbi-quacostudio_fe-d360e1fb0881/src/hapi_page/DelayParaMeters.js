import {
  Box,
  IconButton,
  Typography,
  FormControl,
  InputLabel,
} from "@mui/material";
import React from "react";
import ArrowCircleDown from "../assest/icons/arrow-right-circle.svg";
import ArrowCircleRight from "../assest/icons/arrow-circle.svg";
import { useDispatch, useSelector } from "react-redux";
import { setHapiFeature } from "../components/store/hapiPageSlice";
import { setHapiValues } from "../components/store/hapiSlice";
import CustomBoxScrollbar from "../components/CustomBoxComponent";
import { alpha, styled } from "@mui/material/styles";
import InputBase from "@mui/material/InputBase";

const BootstrapInput = styled(InputBase)(({ theme, error }) => ({
  "label + &": {
    marginTop: theme.spacing(3),
  },
  "& .MuiInputBase-input": {
    borderRadius: 4,
    position: "relative",
    backgroundColor: theme.palette.mode === "light" ? "#F3F6F9" : "#1A2027",
    border: "1px solid",
    borderColor: error
      ? "red" // Apply red border when error exists
      : theme.palette.mode === "light"
      ? "#E0E3E7"
      : "#2D3843",
    fontSize: 16,
    width: "100%",
    padding: "10px 12px",
    transition: theme.transitions.create([
      "border-color",
      "background-color",
      "box-shadow",
    ]),
    fontFamily: [
      "-apple-system",
      "BlinkMacSystemFont",
      '"Segoe UI"',
      "Roboto",
      '"Helvetica Neue"',
      "Arial",
      "sans-serif",
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',
    ].join(","),
    "&:focus": {
      boxShadow: `${alpha(theme.palette.primary.main, 0.25)} 0 0 0 0.2rem`,
      borderColor: error ? "red" : theme.palette.primary.main, // Red border on focus if error
    },
  },
}));

const DelayParameters = () => {
  const dispatch = useDispatch();

  const { delayParamenters } = useSelector((state) => state.hapipage);
  const { delay } = useSelector((state) => state.hapivalues);

  const handleExpandClick = () => {
    dispatch(
      setHapiFeature({ feature: "delayParamenters", value: !delayParamenters })
    );
  };

  const handleChangeDelay = (e) => {
    dispatch(setHapiValues({ feature: "delay", value: e.target.value }));
  };
  return (
    <Box
      sx={{
        border: "1px solid #DFE3EB",
        boxShadow:
          "rgba(9, 30, 66, 0.25) 0px 4px 8px -2px, rgba(9, 30, 66, 0.08) 0px 0px 0px 1px",
        m: 1,
        borderRadius: 2,
        "&:hover": {
          borderColor: "#33BFFF", // Change border color on hover
        },
      }}
    >
      <Box>
        <IconButton
          sx={{ "&:hover": { bgcolor: "transparent" } }}
          onClick={handleExpandClick}
        >
          <img
            src={delayParamenters ? ArrowCircleDown : ArrowCircleRight}
            alt="toggle icon"
            style={{ width: "24px", height: "24px" }}
          />
          <Typography sx={{ ml: 1 }}>Delay parameters</Typography>
        </IconButton>
      </Box>
      {delayParamenters && (
        <CustomBoxScrollbar>
          <FormControl
            variant="standard"
            sx={{ width: "100%", mb: 2 }} // Adding margin-bottom for spacing
          >
            <InputLabel shrink htmlFor="bootstrap-input">
              Delay (ms)
            </InputLabel>
            <BootstrapInput
              value={delay}
              id="bootstrap-input"
              type="number"
              onChange={handleChangeDelay}
            />
          </FormControl>
        </CustomBoxScrollbar>
      )}
    </Box>
  );
};

export default DelayParameters;
