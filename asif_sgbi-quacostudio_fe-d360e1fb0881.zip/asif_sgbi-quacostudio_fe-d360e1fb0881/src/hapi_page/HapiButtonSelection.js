import {
  Box,
  IconButton,
  Typography,
  Select,
  MenuItem,
  Grid,
  TextField,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import ArrowCircleDown from "../assest/icons/arrow-right-circle.svg";
import ArrowCircleRight from "../assest/icons/arrow-circle.svg";
import { useDispatch, useSelector } from "react-redux";
import { setHapiFeature } from "../components/store/hapiPageSlice";
import { setHapiValues } from "../components/store/hapiSlice";

import {
  createHapiScript,
  setHapiScriptValues,
} from "../components/store/hapiScriptSlice";

const HapiButtonsSelect = () => {
  const feature = useSelector((state) => state.page);
  const dispatch = useDispatch();
  const { hapiElements } = useSelector((state) => state.hapipage);
  const {
    hapiType,
    command,
    elementName,
    hapiApiName,
    hapiScriptName,
    hapiId,
    taps,
    force,
    backposition,
    speed,
    duration,
    hapiAction,
  } = useSelector((state) => state.hapivalues);
  const { scriptId, element_id } = useSelector((state) => state.hapiScripts);
  const { buttons } = useSelector((state) => state.dutButtons);
  const { screens } = useSelector((state) => state.dutScreen);
  const [hapiApi, setHapiApi] = useState(hapiApiName);
  const handleExpandClick = () => {
    dispatch(setHapiFeature({ feature: "hapiElements", value: !hapiElements }));
  };

  const handleSelectOption = (event) => {
    dispatch(
      setHapiScriptValues({
        feature: "element_id",
        value: `${hapiType}:${event.id}`,
      })
    );

    let api = "";
    if (hapiType === "BTN") {
      dispatch(
        setHapiValues({ feature: "elementName", value: event.button_name })
      );
      if (hapiAction === "Single tap") {
        api = `${command}:${event.button_name}:${duration}:${backposition}:${force}:`;
      } else if (hapiAction === "Multi tap") {
        api = `${command}:${event.button_name}:${taps}:${duration}:${backposition}:${force}:`;
      } else if (hapiAction === "Move") {
        api = `${command}:${event.button_name}:`;
      }
    } else if (hapiType === "CAP" || hapiType === "SCR") {
      dispatch(
        setHapiValues({ feature: "elementName", value: event.screen_name })
      );
      api = `${command}:${event.screen_name}:`;
    }

    setHapiApi(api); // This will set the hapiApi state

    // Ensure the API is set before dispatching the action
    setTimeout(() => {
      dispatch(setHapiValues({ feature: "hapiApiName", value: api }));

      const hapiScriptData = {
        hapi_id: parseInt(hapiId),
        api: api,
        name: hapiScriptName,
        element_id: `${hapiType}:${event.id}`,
      };
      console.log(scriptId, "print id");
      if (!scriptId) {
        dispatch(createHapiScript(hapiScriptData));
      }
    }, 0);
  };
  const handleUpdateHpiApi = () => {
    let api = "";
    if (hapiType === "CAP" || hapiType === "SCR") {
      api = `${command}:${elementName}:`;
      setHapiApi(api);
    } else {
      if (hapiAction === "Single tap") {
        api = `${command}:${elementName}:${duration}:${backposition}:${force}:`;
        setHapiApi(api);
      } else if (hapiAction === "Multi tap") {
        api = `${command}:${elementName}:${taps}:${duration}:${backposition}:${force}:`;
        setHapiApi(api);
      }
    }

    dispatch(setHapiValues({ feature: "hapiApiName", value: hapiApi }));
    // const hapiScriptData = {
    //     hapi_id:parseInt(hapiId),
    //     api:hapiApi,
    //     name:hapiScriptName,
    //     element_id:element_id
    // }
    // if(scriptId){
    //     let id = scriptId
    //     dispatch(updateHapiScript({id,hapiScriptData}))
    // }
  };
  // useEffect(()=>{
  //   setTimeout(()=>{
  //     handleUpdateHpiApi()
  //   },2000)
  // },[hapiApiName])
  useEffect(() => {
    dispatch(setHapiFeature({ feature: "hapiElements", value: true }));
  }, []);
  return (
    <Box
      sx={{
        border: "1px solid #DFE3EB",
        boxShadow:
          "rgba(9, 30, 66, 0.25) 0px 4px 8px -2px, rgba(9, 30, 66, 0.08) 0px 0px 0px 1px",
        m: 1,
        borderRadius: 2,
        "&:hover": {
          borderColor: "#33BFFF", // Change border color on hover
        },
      }}
    >
      <Box>
        <IconButton
          sx={{ "&:hover": { bgcolor: "transparent" } }}
          onClick={handleExpandClick}
        >
          <img
            src={hapiElements ? ArrowCircleDown : ArrowCircleRight}
            alt="toggle icon"
            style={{ width: "24px", height: "24px" }}
          />
          <Typography sx={{ ml: 1 }}>Elements</Typography>
        </IconButton>
      </Box>
      {hapiElements && hapiScriptName.length > 2 && (
        <Box sx={{ flexDirection: "column", p: 1 }}>
          <Grid container spacing={2}>
            {/* <Grid item xs={5}>
              <Box
                sx={{
                  position: "relative", // Relative positioning for the container
                  borderRadius: 2,
                  height: "100%",
                  width: "100%",
                  maxHeight: { xs: 120, md: 120 },
                }}
              >
                <Box
                  component="img"
                  sx={{
                    borderRadius: 2,
                    height: "100%", // Adjust the height as needed
                    width: "100%", // Adjust the width as needed
                    maxHeight: { xs: 100, md: 100 },
                    objectFit: "cover", // Ensure the image covers the area without distortion
                  }}
                  alt="Small Image"
                  src={feature.buttons ? demiCrop : demiCrop} // Replace with your image source
                />
              </Box>
            </Grid> */}
            <Grid item xs={12}>
              <Grid container spacing={1}>
                <Grid item xs={12}>
                  <Typography sx={{ mb: 0.5 }}>Name</Typography>
                  <Select
                    size="small"
                    variant="outlined"
                    sx={{
                      height: "30px",
                      width: "100%",
                      pl: 1,
                      "& .MuiInputBase-input": {
                        padding: "0px", // Adjust padding as needed
                      },
                    }}
                    MenuProps={{
                      PaperProps: {
                        style: {
                          maxHeight: 200, // Set the maximum height for the dropdown
                        },
                      },
                    }}
                    value={elementName}
                  >
                    {(hapiType === "BTN" ? buttons : screens).map(
                      (item, index) => (
                        <MenuItem
                          key={index}
                          value={
                            hapiType === "BTN"
                              ? item.button_name
                              : item.screen_name
                          }
                          onClick={(e) => handleSelectOption(item)}
                        >
                          {hapiType === "BTN"
                            ? item.button_name
                            : item.screen_name}
                        </MenuItem>
                      )
                    )}
                  </Select>
                </Grid>

                <Grid item xs={12}>
                  <Typography sx={{ mb: 0.5 }}>Type</Typography>
                  <TextField
                    size="small"
                    variant="outlined"
                    // type="number"
                    value={hapiType === "BTN" ? "Button" : "Screen"}
                    sx={{ width: "100%" }}
                    InputProps={{
                      sx: {
                        height: "30px",
                        "& .MuiInputBase-input": {
                          padding: "10px", // Adjust padding as needed
                        },
                      },
                    }}
                  />
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Box>
      )}
    </Box>
  );
};

export default HapiButtonsSelect;
