import { Alert, IconButton, Snackbar } from "@mui/material";
import settingsIcon from "../assest/icons/video-player-play.svg";
import playbutton from "../assest/icons/play-button.svg";
import { useDispatch, useSelector } from "react-redux";
import { runSingleScript } from "../api/navigationApis";
import { useRef, useState } from "react";
import { setCurrentScriptIndex } from "../components/store/hapiScriptSlice";

const SingleScripTest = ({ edit }) => {
  const dispatch = useDispatch();
  const [isRunning, setIsRunning] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [open, setOpen] = useState(false);
  const [snackbarContent, setSnackbarContent] = useState({
    title: "",
    body: "",
  });
  const { hapiScriptList, hapiScriptIndex } = useSelector(
    (state) => state.hapiScripts
  );

  const { hapiApiName, element_id } = useSelector((state) => state.hapivalues);
  const isRunningRef = useRef(true);
  const isPausedRef = useRef(false);

  const onApiCall = (api, order, response) => {
    console.log(`Currently running API: ${api} for Element ID: ${order}`);
    dispatch(setCurrentScriptIndex(order));
    if (response) {
      setSnackbarContent({
        title: "OCR Output",
        body: response,
      });
      setOpen(true);
      setTimeout(() => {
        setOpen(false);
      }, 3000);
    }
  };

  const handleRunScript = async () => {
    isRunningRef.current = true;
    const item = hapiScriptList[hapiScriptIndex];
    let scriptItem = {};
    if (edit) {
      scriptItem = {
        api: hapiApiName,
        element_id: element_id,
        order: item.order,
      };
    } else {
      scriptItem = {
        api: item.api,
        element_id: item.element_id,
        order: item.order,
      };
    }

    try {
      await runSingleScript(scriptItem, onApiCall, isRunningRef, isPausedRef);
    } finally {
      setIsRunning(false);
    }
    setIsPaused(false);
    dispatch(setCurrentScriptIndex(false));
  };
  const handleClose = () => {
    setOpen(false);
  };
  return (
    <>
      <IconButton onClick={handleRunScript}>
        <img
          src={!edit ? playbutton : settingsIcon}
          alt="Setting Icon"
          style={{ width: "24px", height: "24px" }}
        />
      </IconButton>

      <Snackbar
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
        open={open}
        autoHideDuration={6000}
        onClose={handleClose}
      >
        <Alert
          onClose={handleClose}
          severity="success"
          variant="filled"
          sx={{ width: "100%" }}
        >
          <strong>{snackbarContent.title}</strong>
          <div>{snackbarContent.body}</div>
        </Alert>
      </Snackbar>
    </>
  );
};

export default SingleScripTest;
