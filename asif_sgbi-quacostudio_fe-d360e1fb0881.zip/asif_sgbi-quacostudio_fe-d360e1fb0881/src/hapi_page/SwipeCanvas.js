import React, { forwardRef, useState, useRef } from "react";
import { useDispatch, useSelector } from "react-redux";
import { setHapiValues } from "../components/store/hapiSlice";
import { disableVideoFeedCanvas } from "../components/store/videoFeedSlice";
import { createHapiScript } from "../components/store/hapiScriptSlice";
import { onClikNavigationRight, swipeCommandApi } from "../api/navigationApis";
import { pixelsToMM } from "../utils/funcs";
import drawLineWithArrow from "../assest/utils/swipearrow";

// Use forwardRef to allow the parent component to pass the ref down
const SwipeCanvasComponent = forwardRef(
  ({ width, height, canvasRect, container }, ref) => {
    const {
      hapiApiName,
      hapiScriptName,
      hapiType,
      hapiId,
      touch,
      tReturn,
      duration,
      backposition,
      force,
      speed,
      sy,
      sx,
      autoSave
    } = useSelector((state) => state.hapivalues);
    const { scriptId } = useSelector((state) => state.hapiScripts);
    const gap = 40; // Example gap value
    const Double = true; // Toggle double line drawing

    const [position, setPosition] = useState({
      startX: 0,
      startY: 0,
      endX: 0,
      endY: 0,
    });

    const dispatch = useDispatch();
    const isDrawing = useRef(false); // To track if the drawing is happening

    // Function to draw a line on the canvas
    const drawLine = (
      ctx,
      startX,
      startY,
      endX,
      endY,
      gapOffsetX = 0,
      gapOffsetY = 0
    ) => {
      ctx.beginPath();
      ctx.moveTo(startX + gapOffsetX, startY + gapOffsetY);
      ctx.lineTo(endX + gapOffsetX, endY + gapOffsetY);
      ctx.strokeStyle = "green"; // Set line color
      ctx.lineWidth = 2; // Set line width
      ctx.stroke();
    };

    const handleMouseDown = (event) => {
      event.preventDefault();
      const startX = event.clientX - canvasRect.left + container.scrollLeft;
      const startY = event.clientY - canvasRect.top + container.scrollTop;

      setPosition((prev) => ({ ...prev, startX, startY }));
      isDrawing.current = true; // Start drawing mode
    };

    const handleMouseMove = (event) => {
      if (!isDrawing.current) return; // Only draw if the mouse is down

      const endX = event.clientX - canvasRect.left + container.scrollLeft;
      const endY = event.clientY - canvasRect.top + container.scrollTop;

      setPosition((prev) => ({ ...prev, endX, endY }));

      const ctx = ref.current.getContext("2d");
      ctx.clearRect(0, 0, width, height); // Clear previous drawings

      // Draw the main line
      drawLineWithArrow(ctx, position.startX, position.startY, endX, endY);

      // If Double is true, calculate the perpendicular offsets and draw two additional lines
      if (hapiType === "SWD") {
        const dx = endX - position.startX;
        const dy = endY - position.startY;
        const length = Math.sqrt(dx * dx + dy * dy); // Calculate length of the line
        const offsetX = (gap / 2) * (dy / length); // Perpendicular offset for X
        const offsetY = (gap / 2) * (-dx / length); // Perpendicular offset for Y

        // Draw the two parallel lines
        drawLine(
          ctx,
          position.startX,
          position.startY,
          endX,
          endY,
          offsetX,
          offsetY
        ); // Upper line
        drawLine(
          ctx,
          position.startX,
          position.startY,
          endX,
          endY,
          -offsetX,
          -offsetY
        ); // Lower line
      }
    };

    const handleMouseUp = async() => {
      if (!isDrawing.current) return;
      // Convert pixel values to millimeters

      const startXMM = position.startX;
      const startYMM = position.startY;
      const endXMM = position.endX;
      const endYMM = position.endY;
      // Dispatching the coordinates once drawing is finished
      dispatch(setHapiValues({ feature: "sx", value: Math.round(startXMM) }));
      dispatch(setHapiValues({ feature: "sy", value: Math.round(startYMM) }));
      dispatch(setHapiValues({ feature: "ex", value: Math.round(endXMM) }));
      dispatch(setHapiValues({ feature: "ey", value: Math.round(endYMM) }));

      // onClikNavigationRight(position.endX, position.endY, duration, backposition, force);
      isDrawing.current = false; // Stop drawing

      const ctx = ref.current.getContext("2d");
      ctx.clearRect(0, 0, width, height); // Clear previous drawings
      
      const swipe = await saveSWipeAction(`s:${Math.round(startXMM)}:${Math.round(startYMM)}:${Math.round(endXMM)}:${Math.round(endYMM)}:${speed}:${100}`)
    };
    const saveSWipeAction = async (cmd) => {
      let element_id = "";
      if (hapiType === "SWS") {
        element_id = "SWS:0";
      } else if (hapiType === "SWD") {
        element_id = "SWD:0";
      }

      try {
        // Await the API call to complete
        const apiResponse = await swipeCommandApi(cmd);
         
        if (apiResponse) {
          // Only proceed with dispatch if necessary conditions are met
          if(autoSave && hapiScriptName.length > 2){
        
           const hapiScriptData = {
            hapi_id: parseInt(hapiId),
            api: apiResponse, // Use the successful API response here
            name: hapiScriptName,
            element_id: element_id,
          };
          dispatch(createHapiScript(hapiScriptData)); // Dispatch after API call
          let scriptName = ''
          let name = hapiScriptName.split("-")
          if (name[1]) {
            scriptName = name[0] + "-" + (parseInt(name[1]) + 1);
           }else{
            scriptName = name + "-2"
           }
          dispatch(setHapiValues({feature:"hapiScriptName", value:scriptName}))
          }else if(!scriptId && hapiScriptName.length > 2) {
            const hapiScriptData = {
              hapi_id: parseInt(hapiId),
              api: apiResponse, // Use the successful API response here
              name: hapiScriptName,
              element_id: element_id,
            };
            dispatch(disableVideoFeedCanvas("swipeCanvas"));
            dispatch(createHapiScript(hapiScriptData)); // Dispatch after API call   
          }else{
            
          }
        } else {
          console.error("API response was null or invalid.");
          dispatch(disableVideoFeedCanvas("swipeCanvas"));
        }
      } catch (error) {
        console.error("Error during saveSwipeAction:", error);
        dispatch(disableVideoFeedCanvas("swipeCanvas"));
      }
    };
    return (
      <canvas
        ref={ref}
        width={width}
        height={height}
        style={{ display: "block", position: "absolute", zIndex: 2 }}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        // onMouseLeave={saveSWipeAction}
      />
    );
  }
);

export default SwipeCanvasComponent;
