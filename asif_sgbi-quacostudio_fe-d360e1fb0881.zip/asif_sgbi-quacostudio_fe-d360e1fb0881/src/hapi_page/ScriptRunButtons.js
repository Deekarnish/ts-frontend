import { Box, Snackbar, Alert } from "@mui/material";
import React, { useState, useEffect, useRef } from "react";
import playbutton from "../assest/icons/play-button.svg";
import playNormal from "../assest/icons/playButtonIcons/playicon.svg"
import pausebutton from "../assest/icons/pause-button.svg";
import stopbutton from "../assest/icons/stop-button.svg";
import continuebutton from "../assest/icons/continue-button.svg";
import {
  hapiLowLevelScriptRun,
  runScriptsSequentially,
} from "../api/navigationApis";
import { useSelector, useDispatch } from "react-redux";
import { setCurrentScriptIndex } from "../components/store/hapiScriptSlice";

const nvIcons = {
  pt: 0.7,
  pl: 1,
  pr: 1,
  pb:0.6,
  background: "#CDE5FA",
  borderRadius: 2,
  "&:hover": {
    color: "white",
    cursor:"pointer"
   
  },
};

const nvIconsActive = {
  pt: 0.7,
  pl: 1,
  pr: 1,
  pb:0.6,
  "&:hover": {
    borderRadius: 2,
    color: "white",
     cursor:"pointer"
  },
  background: "linear-gradient(135deg, #33BFFF -26.25%, #5D5CE5 93.75%)",
  
  borderRadius: 2,
};

const ScriptRunButtons = () => {
  const dispatch = useDispatch();
  const { hapiScriptList, hapiScriptIndex } = useSelector(
    (state) => state.hapiScripts
  );

  const [isRunning, setIsRunning] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [open, setOpen] = useState(false);
  const [snackbarContent, setSnackbarContent] = useState({
    title: "",
    body: "",
  });
  const isRunningRef = useRef(true);
  const isPausedRef = useRef(false);

  const handleApiCall = (api, order, response) => {
    console.log(`Currently running API: ${api} for Element ID: ${order}`);
    dispatch(setCurrentScriptIndex(order));
    if (response) {
      setSnackbarContent({
        title: "OCR Output",
        body: response,
      });
      setOpen(true);
      setTimeout(() => {
        setOpen(false);
      }, 3000);
    }
  };

  const handleRunScript = async () => {
    isRunningRef.current = true;
    setIsRunning(true);
    try {
      await runScriptsSequentially(
        hapiScriptList,
        handleApiCall,
        isRunningRef,
        isPausedRef
      );
    } finally {
      setIsRunning(false);
    }
    setIsPaused(false);
    dispatch(setCurrentScriptIndex(false));
  };

  const handlePauseScript = () => {
    isPausedRef.current = true;
    setIsPaused(true);
    console.log("Pause clicked, isPaused set to:", true);
  };

  const handleResumeScript = () => {
    isPausedRef.current = false;
    setIsPaused(false);
    console.log("Resume clicked, isPaused set to:", false);
  };

  const handleStopScript = () => {
    isRunningRef.current = false;
    setIsRunning(false);
    setIsPaused(false);
    console.log("Stop clicked, isRunning set to:", false);
  };
  const handleClose = () => {
    setOpen(false);
  };
  return (
    <Box
      sx={{
        boxShadow:  "0px 2px 10px 0px rgba(0, 68, 128, 0.25)",
        padding: 0.5,
        borderRadius: 2,
        display: "inline-flex",
        border: "1px solid rgba(185, 218, 247, 0.70)",
        gap: 1,
        // pl: 0.1,
        // pr: 0.1,
        mb: 1,
        // ml: 1,
        mt: 1,
        justifyContent: "center", // Center horizontally
        alignItems: "center", // Center vertically
        width: "90%",
      }}
    >
      <Box
        sx={isRunning && !isPaused ? nvIconsActive : nvIcons}
        onClick={handleRunScript}
      >
        <img
          src={playbutton}
          alt="play"
          style={{ width: "24px", height: "24px" }}
        />
      </Box>
      <Box sx={isPaused ? nvIconsActive : nvIcons} onClick={handlePauseScript}>
        <img
          src={pausebutton}
          alt="pause"
          style={{ width: "24px", height: "24px" }}
        />
      </Box>
      <Box sx={nvIcons} onClick={handleStopScript}>
        <img
          src={stopbutton}
          alt="stop"
          style={{ width: "24px", height: "24px" }}
        />
      </Box>
      <Box sx={nvIcons} onClick={handleResumeScript}>
        <img
          src={continuebutton}
          alt="resume"
          style={{ width: "24px", height: "24px" }}
        />
      </Box>
      <Snackbar
        anchorOrigin={{ vertical: "top", horizontal: "center" }}
        open={open}
        autoHideDuration={6000}
        onClose={handleClose}
      >
        <Alert
          onClose={handleClose}
          severity="success"
          variant="filled"
          sx={{ width: "100%" }}
        >
          <strong>{snackbarContent.title}</strong>
          <div>{snackbarContent.body}</div>
        </Alert>
      </Snackbar>
    </Box>
  );
};

export default ScriptRunButtons;
