import { Menu, MenuItem } from "@mui/material";
import { useDispatch } from "react-redux";
import { setHapiValues } from "../../components/store/hapiSlice";
import { useState } from "react";
import { setOpenDelay } from "../../components/store/dutModalSlice";

const menusx = {
  width: 150,
  "&:hover": {
    borderRadius: 2,
    // background:"linear-.(90deg, rgba(11,139,217,1) 0%, rgba(46,114,195,1) 72%, rgba(65,101,240,1) 99%)",
    bgcolor: "#3391FF",
    color:"#FEFEFE"
  },
};

const ExtraOptions = ({handleCloseSubmenu,anchorElSub,handleClose}) => {
    const dispatch = useDispatch()
   

    const handleSelect = (option) => {
     if(option === "imgCapture"){
        dispatch(setHapiValues({ feature: "hapiAction", value: "Image capture" }));
        dispatch(setHapiValues({feature:"hapiType" , value:"CAP"}))
        dispatch(setHapiValues({feature:"command" , value:"capture"}))
        handleCloseSubmenu()
        handleClose()
     }else if(option === "Ocr"){
      dispatch(setHapiValues({ feature: "hapiAction", value: "Ocr" }));
      dispatch(setHapiValues({feature:"hapiType" , value:"OCR"}))
      dispatch(setHapiValues({feature:"command" , value:"ocr"}))
      handleCloseSubmenu()
      handleClose()
     }else if(option ==="Delay"){
      dispatch(setHapiValues({ feature: "hapiAction", value: "Delay" }));
      dispatch(setHapiValues({feature:"hapiType" , value:"DLY"}))
      dispatch(setHapiValues({feature:"command" , value:"delay"}))
      dispatch(setOpenDelay(true))
      handleCloseSubmenu()
      handleClose()
     }
    }
    return (
      <Menu
        anchorEl={anchorElSub}
        open={Boolean(anchorElSub)} // Opens the submenu on click
        onClose={handleCloseSubmenu}
        sx={{ width: 400 }}
        PaperProps={{
          sx: {
            pl: 1,
            pr: 1,
            border: "1px solid #3391FF",
            borderRadius: 2,
          },
        }}
        anchorOrigin={{
          vertical: "top",
          horizontal: "right", // Aligns the submenu to the right side of the main menu
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "left", // Ensures the submenu opens to the right
        }}
      >
        <MenuItem onClick={e =>handleSelect('imgCapture')} sx={menusx} >
          Image capture
        </MenuItem>
        {/* <MenuItem onClick={e =>handleSelect('Ocr')} sx={menusx} >
          Ocr
        </MenuItem> */}
        <MenuItem onClick={e =>handleSelect('Delay')} sx={menusx} >
          Delay
        </MenuItem>
      </Menu>
    );
  };

export default ExtraOptions