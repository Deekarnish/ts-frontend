import { Menu, MenuItem } from "@mui/material";
import { useDispatch } from "react-redux";
import { setHapiValues } from "../../components/store/hapiSlice";
import { disableAllAndEnableFeature, enableVideoFeedCanvas } from "../../components/store/videoFeedSlice";

const menusx = {
    width: 150,
    "&:hover": {
      borderRadius: 2,
      // background:"linear-.(90deg, rgba(11,139,217,1) 0%, rgba(46,114,195,1) 72%, rgba(65,101,240,1) 99%)",
      bgcolor: "#3391FF",
      color:"#FEFEFE"
    },
  };

const Swipe = ({handleCloseSubmenu,anchorElSub,handleClose}) => {
    const dispatch = useDispatch()
    const handleSelect = (option) => {
        dispatch(setHapiValues({ feature: "hapiAction", value: "Swipe" }));
        dispatch(setHapiValues({feature:"hapiType" , value:option}))
        dispatch(disableAllAndEnableFeature("swipeCanvas"))
        if(option === "SWS"){
            dispatch(setHapiValues({feature:"command" , value:"s"}))
        }else if(option ==="SWD"){
            dispatch(setHapiValues({feature:"command" , value:"s:d"}))
        }   
        handleCloseSubmenu()
        handleClose()
    }
    return (
      <Menu
        anchorEl={anchorElSub}
        open={Boolean(anchorElSub)} // Opens the submenu on click
        onClose={handleCloseSubmenu}
        sx={{ width: 400 }}
        PaperProps={{
          sx: {
            pl: 1,
            pr: 1,
            border: "1px solid #3391FF",
            borderRadius: 2,
          },
        }}
        anchorOrigin={{
          vertical: "top",
          horizontal: "right", // Aligns the submenu to the right side of the main menu
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "left", // Ensures the submenu opens to the right
        }}
      >
        <MenuItem sx={menusx} name="button" onClick={e=>handleSelect("SWS")}>
          Single 
        </MenuItem>
        <MenuItem sx={menusx} name="screen" onClick={e=>handleSelect("SWD")} >
          Double
        </MenuItem>
        {/* <MenuItem sx={menusx} name="move">
          Ocr
        </MenuItem> */}
      </Menu>
    );
  };

  export default Swipe