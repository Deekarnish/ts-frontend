import { Grid, Menu, MenuItem, Select } from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { setHapiValues } from "../../components/store/hapiSlice";



const Tap = ({handleCloseSubmenu,anchorElSub,handleClose}) => {

    const { hapiAction, hapiType } = useSelector((state) => state.hapivalues);
    const dispatch = useDispatch()

    const handleClickAction = (event) => {
        dispatch(setHapiValues({ feature: "hapiAction", value: event }));
        if(event ==='Single tap'){
          dispatch(setHapiValues({ feature: "command", value: "f:str" }));
        }else if(event ==='Multi tap'){
          dispatch(setHapiValues({ feature: "command", value: "f:mtr" }));
        }
    
        handleClose();
        handleCloseSubmenu();
      };
      const handleClickType = (event) => {
        dispatch(setHapiValues({ feature: "hapiType", value: event }));
        // handleClose();
        // handleCloseSubmenu();
      };
    return (
      <Menu
        anchorEl={anchorElSub}
        open={Boolean(anchorElSub)} // Opens the submenu on click
        onClose={handleCloseSubmenu}
        sx={{ width: 400 }}
        PaperProps={{
          sx: {
            // pl: 1,
            // pr: 1,
            border: "1px solid #3391FF",
            borderRadius: 2,
          },
        }}
        anchorOrigin={{
          vertical: "top",
          horizontal: "right", // Aligns the submenu to the right side of the main menu
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "left", // Ensures the submenu opens to the right
        }}
      >
        <MenuItem>
          <Grid container spacing={1}>
            <Grid item xs={12} container direction="column">
              <Grid item>Type</Grid>
              <Grid item>
                <Select
                  size="small"
                  variant="outlined"
                  sx={{
                    height: "35px",
                    width: 200,
                    pl: 1,
                    "& .MuiInputBase-input": {
                      padding: "0px", // Adjust padding as needed
                    },
                  }}
                  value={hapiType}
                >
                  <MenuItem value="BTN" onClick={e =>handleClickType("BTN")}>
                    Button{" "}
                  </MenuItem>
                  <MenuItem  value="EMT" onClick={e =>handleClickType("EMT")}>
                    Screen
                  </MenuItem>
                  {/* <MenuItem  value="OCR" onClick={e =>handleClickType("OCR")}>
                    Ocr
                  </MenuItem> */}
                </Select>
              </Grid>
            </Grid>

            <Grid item xs={12} container direction="column">
              <Grid item>Action</Grid>
              <Grid item>
                <Select
                  size="small"
                  variant="outlined"
                  sx={{
                    height: "35px",
                    width: 200,
                    pl: 1,
                    "& .MuiInputBase-input": {
                      padding: "0px", // Adjust padding as needed
                    },
                  }}
                >
                  <MenuItem
                    value="Single tap"
                    onClick={(e) => handleClickAction("Single tap")}
                  >
                    Single Tap
                  </MenuItem>
                  <MenuItem
                    value="Multi tap"
                    onClick={(e) => handleClickAction("Multi tap")}
                  >
                    multi Tap
                  </MenuItem>
                </Select>
              </Grid>
            </Grid>
          </Grid>
        </MenuItem>
      </Menu>
    );
  };


  export default Tap