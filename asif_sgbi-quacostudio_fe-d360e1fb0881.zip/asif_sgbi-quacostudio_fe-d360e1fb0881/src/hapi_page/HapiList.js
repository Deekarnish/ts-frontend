import React, { useEffect, useState } from "react";
import {
  Box,
  TextField,
  Menu,
  MenuItem,
  List,
  ListItemButton,
  ListItemText,
} from "@mui/material";
import { useDispatch, useSelector } from "react-redux";
import { setHapiFeature } from "../components/store/hapiPageSlice";
import {
  createHapi,
  deleteHapi,
  fetchHapis,
  setHapiName,
  setHapiValues,
} from "../components/store/hapiSlice";
import Cookies from "js-cookie";
import DeleteConfirmationModal from "../components/modals/DeleteConfirmationModal";
import { fetchHapiScripts } from "../components/store/hapiScriptSlice";

const ButtonActive = {
  mb: 1,
  borderRadius: 2,
  height:40,
  color: "white",
  background: "linear-gradient(90deg, #33BFFF 0%, #5D5CE5 100%)",

};

const ButtonNormalState = {
  mb: 1,
  borderRadius: 2,
  height:40,
  "&:hover": {
    bgColor: "#CDE5FA",
  },
};

const textFieldStyle = {
  mt: 0,
  mr: 1,
  mb: 0,
  borderRadius: 2,
  fontSize: 12,
  backgroundColor: "#E9F3FC",
  "& .MuiOutlinedInput-root": {
    "& fieldset": {
      border: "none",
    },
    "&:hover fieldset": {
      border: "none",
    },
    "&.Mui-focused fieldset": {
      border: "none",
    },
  },
  "& .MuiInputBase-root": {
    height: "45px",
  },
  "& .MuiInputLabel-root": {
    fontSize: "0.7rem",
    top: "0px",
  },
  "& .MuiInputLabel-shrink": {
    display: "none",
  },
};

const menusx = {
  width: 120,
  "&:hover": {
    borderRadius: 2,
    bgcolor: "#3391FF",
    color:"#FEFEFE"
  },
};

const HapiList = () => {
  const { addNewHapi } = useSelector((state) => state.hapipage);
  const { hapiName, hapiNameList, activeIndex } = useSelector(
    (state) => state.hapivalues
  );
  const [hapiId, setHapitId] = useState(null);
  const [anchorEl, setAnchorEl] = useState(false);
  const [editIndex, setEditIndex] = useState(null); // Track the item being edited
  const [editedName, setEditedName] = useState("");
  const [openDeleteConfirmation, setOpenDeleteConfirmation] = useState(false);
  const dutId = Cookies.get("dutId");
  const dispatch = useDispatch();

  useEffect(() => {
    dispatch(fetchHapis(parseInt(dutId)));
  }, [dispatch, dutId]);

  const handleSaveHapi = () => {
    dispatch(setHapiFeature({ feature: "addNewHapi", value: false }));
    const hapiData = {
      action_name: hapiName,
      dut_id: parseInt(dutId),
    };
    if(hapiName.length > 2){
      dispatch(createHapi(hapiData));
    }
  };

  const handleRename = () => {
    if (editIndex !== null) {
    //   dispatch(renameHapi({ id: hapiId, newName: editedName }));
      setEditIndex(null);
      setEditedName("");
    }
  };

  const handleDelete = () => {
    dispatch(deleteHapi(hapiId))
    setOpenDeleteConfirmation(false)
  };

  const handleClick = (index, item) => {
    dispatch(setHapiValues({ feature: "activeIndex", value: index }));
    dispatch(
      setHapiValues({ feature: "activeHapiName", value: item.action_name })
    );
    dispatch(setHapiValues({ feature: "hapiId", value: item.id }));
    dispatch(fetchHapiScripts(item.id))
    setEditIndex(null); // Exit edit mode when clicking another item
  };

  const handleRightClick = (e, item, index) => {
    setAnchorEl(e.currentTarget);
    setHapitId(item.id);
    setEditIndex(null); // Exit edit mode on right-click
    setEditedName(item.action_name);
    dispatch(setHapiValues({ feature: "activeIndex", value: index }));
  };

  const handleClose = () => {
    setAnchorEl(false);
  };

  const handleClickDelete = () => {
    setOpenDeleteConfirmation(true);
    handleClose();
  };

  const handleEdit = (index, item) => {
    setEditIndex(activeIndex);
    handleClose();
  };

  const rightClickMenu = () => (
    <Menu
      anchorEl={anchorEl}
      open={Boolean(anchorEl)}
      onClose={handleClose}
      PaperProps={{
        sx: {
          pl: 1,
          pr: 1,
          border: "1px solid #3391FF",
          borderRadius: 2,
        },
      }}
      anchorOrigin={{
        vertical: "top",
        horizontal: "right",
      }}
      transformOrigin={{
        vertical: "top",
        horizontal: "left",
      }}
    >
      <MenuItem sx={menusx} onClick={() => handleEdit(editIndex, hapiId)}>
        Rename
      </MenuItem>
      <MenuItem sx={menusx} onClick={handleClickDelete}>
        Delete
      </MenuItem>
    </Menu>
  );

  return (
    <Box
      sx={{
        ml: 1,
        pr: 1,
        borderRadius: 2,
        maxHeight: "30%",
        overflowY: "auto",
      }}
    >
      {addNewHapi && (
        <TextField
          id="outlined-basic"
          name="name"
          label="Enter hapi name"
          fullWidth
          value={hapiName}
          onChange={(e) => dispatch(setHapiName(e.target.value))}
          onMouseLeave={handleSaveHapi}
          sx={textFieldStyle}
        />
      )}
      <List component="nav" aria-label="hapi list">
        {hapiNameList.map((item, index) => (
          <React.Fragment key={index}>
            {editIndex === index ? (
              <TextField
                value={editedName}
                onChange={(e) => setEditedName(e.target.value)}
                onBlur={handleRename}
                autoFocus
                sx={textFieldStyle}
              />
            ) : (
              <ListItemButton
                key={index}
                sx={index === activeIndex ? ButtonActive : ButtonNormalState}
                onClick={() => handleClick(index, item)}
                onContextMenu={(e) => {
                  e.preventDefault();
                  handleRightClick(e, item, index);
                }}
              >
                <ListItemText primary={item.action_name} />
              </ListItemButton>
            )}
          </React.Fragment>
        ))}
      </List>
      {rightClickMenu()}
      <DeleteConfirmationModal
        openDeleteConfirmation={openDeleteConfirmation}
        setOpenDeleteConfirmation={setOpenDeleteConfirmation}
        handleDelete={handleDelete}
      />
    </Box>
  );
};

export default HapiList;
