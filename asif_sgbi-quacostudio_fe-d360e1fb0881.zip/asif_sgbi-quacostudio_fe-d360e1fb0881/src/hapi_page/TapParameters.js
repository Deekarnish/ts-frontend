import {
  Box,
  Button,
  IconButton,
  Typography,
  Grid,
  TextField,
  Checkbox,
  Divider,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import ArrowCircleDown from "../assest/icons/arrow-right-circle.svg";
import ArrowCircleRight from "../assest/icons/arrow-circle.svg";
import { useDispatch, useSelector } from "react-redux";
import { setFeatureExpand } from "../components/store/hmiOptionsSlice";
import demiCrop from "../assest/images/694979.png";
import editIcon from "../assest/icons/edit-icon.svg";
import { enableVideoFeedCanvas } from "../components/store/videoFeedSlice";
import { setHapiFeature } from "../components/store/hapiPageSlice";
import { setHapiValues } from "../components/store/hapiSlice";
import DividerWithText from "../components/DividerComponent";

const TapParameters = () => {
  const feature = useSelector((state) => state.page);
  const [sides, setSides] = useState({ top: 0, left: 0, bottom: 0, right: 0 });
  const dispatch = useDispatch();
  const vFeed = useSelector((state) => state.vFeed);
  const { hapiTapParams } = useSelector((state) => state.hapipage);
  const { speed, backposition, force, duration, taps, hapiAction, autoSave , ox,oy} =
    useSelector((state) => state.hapivalues);

  const handleExpandClick = () => {
    dispatch(
      setHapiFeature({ feature: "hapiTapParams", value: !hapiTapParams })
    );
  };

  const handleRedraw = () => {
    dispatch(enableVideoFeedCanvas("buttonDrawEnabled"));
  };

  const handleChange = (e) => {
    dispatch(setHapiValues({ feature: e.target.name, value: e.target.value }));
  };
  const handleSelect = (e) => {
    const value = e.target.value;
    const name = e.target.name;
    if (name === "autoSave") {
      dispatch(setHapiValues({ feature: name, value: !autoSave }));
      if (!autoSave) {
        dispatch(enableVideoFeedCanvas("swipeCanvas"));
      }
    }
  };
  return (
    <Box
      sx={{
        border: "1px solid #DFE3EB",
        boxShadow:
          "rgba(9, 30, 66, 0.25) 0px 4px 8px -2px, rgba(9, 30, 66, 0.08) 0px 0px 0px 1px",
        m: 1,
        borderRadius: 2,
        "&:hover": {
          borderColor: "#33BFFF", // Change border color on hover
        },
      }}
    >
      <Box>
        <IconButton
          sx={{ "&:hover": { bgcolor: "transparent" } }}
          onClick={handleExpandClick}
        >
          <img
            src={hapiTapParams ? ArrowCircleDown : ArrowCircleRight}
            alt="toggle icon"
            style={{ width: "24px", height: "24px" }}
          />
          <Typography sx={{ ml: 1 }}>Tap parameters</Typography>
        </IconButton>
      </Box>
      {hapiTapParams && (
        <Box sx={{ flexDirection: "column", p: 1 }}>
          <Grid container spacing={2}>
          {hapiAction === "Touch OCR" &&  <>
            <Grid item xs={6}>
              <Typography sx={{ mb: 0.5 }}>Offset X (mm)</Typography>
              <TextField
                size="small"
                variant="outlined"
                type="number"
                name="ox"
                value={ox}
                onChange={handleChange}
                InputProps={{
                  sx: {
                    height: "30px",
                    "& .MuiInputBase-input": {
                      padding: "0px", // Adjust padding as needed
                    },
                  },
                }}
              />
            </Grid>
            <Grid item xs={6}>
              <Typography sx={{ mb: 0.5 }}>Offset Y (mm)</Typography>
              <TextField
                size="small"
                variant="outlined"
                type="number"
                name="oy"
                value={oy}
                onChange={handleChange}
                InputProps={{
                  sx: {
                    height: "30px",
                    "& .MuiInputBase-input": {
                      padding: "0px", // Adjust padding as needed
                    },
                  },
                }}
              />
            </Grid>
            <Grid item xs={12}>
              <Divider/>
            </Grid> 
            </> }
            <Grid item xs={6}>
              <Grid container spacing={1}>
                {hapiAction === "Swipe" ? (
                  <Grid item xs={12}>
                    <Typography
                      component="span"
                      sx={{
                        fontSize: 14,
                        whiteSpace: "nowrap",
                      }}
                    >
                      Auto Accept
                    </Typography>
                    <Box
                      sx={{
                        display: "flex",
                        alignItems: "center",
                      }}
                    >
                      {" "}
                      <Typography
                        component="span"
                        sx={{
                          fontSize: 14,
                          whiteSpace: "nowrap",
                        }}
                      >
                        {autoSave ? "ON" : "OFF"}
                      </Typography>
                      <Checkbox
                        onClick={handleSelect}
                        name="autoSave"
                        checked={autoSave}
                      />
                    </Box>
                  </Grid>
                ) : (
                  <Grid item xs={12}>
                    <Typography sx={{ mb: 0.5 }}> Back position </Typography>
                    <TextField
                      size="small"
                      variant="outlined"
                      type="number"
                      name="backposition"
                      value={backposition}
                      onChange={handleChange}
                      InputProps={{
                        sx: {
                          height: "30px",
                          "& .MuiInputBase-input": {
                            padding: "0px", // Adjust padding as needed
                          },
                        },
                      }}
                    />
                  </Grid>
                )}
                <Grid item xs={12}>
                  <Typography sx={{ mb: 0.5 }}>Force</Typography>
                  <TextField
                    size="small"
                    variant="outlined"
                    type="number"
                    name="force"
                    value={force}
                    onChange={handleChange}
                    InputProps={{
                      sx: {
                        height: "30px",
                        "& .MuiInputBase-input": {
                          padding: "0px", // Adjust padding as needed
                        },
                      },
                    }}
                  />
                </Grid>
              </Grid>
            </Grid>
            <Grid item xs={6}>
              <Grid container spacing={1}>
                {hapiAction === "Multi tap" || hapiAction === "Swipe" ? (
                  <Grid item xs={12}>
                    <Typography sx={{ mb: 0.5 }}>Speed</Typography>
                    <TextField
                      size="small"
                      variant="outlined"
                      type="number"
                      name="speed"
                      value={speed}
                      onChange={handleChange}
                      InputProps={{
                        sx: {
                          height: "30px",
                          "& .MuiInputBase-input": {
                            padding: "0px", // Adjust padding as needed
                          },
                        },
                      }}
                    />
                  </Grid>
                ) : (
                  <Grid item xs={12}>
                    <Typography sx={{ mb: 0.5 }}> Duration</Typography>
                    <TextField
                      size="small"
                      variant="outlined"
                      type="number"
                      name="duration"
                      value={duration}
                      onChange={handleChange}
                      InputProps={{
                        sx: {
                          height: "30px",
                          "& .MuiInputBase-input": {
                            padding: "0px", // Adjust padding as needed
                          },
                        },
                      }}
                    />
                  </Grid>
                )}
                {hapiAction === "Multi tap" && (
                  <Grid item xs={12}>
                    <Typography sx={{ mb: 0.5 }}> Number of taps</Typography>
                    <TextField
                      size="small"
                      variant="outlined"
                      type="number"
                      name="taps"
                      value={taps}
                      onChange={handleChange}
                      InputProps={{
                        sx: {
                          height: "30px",
                          "& .MuiInputBase-input": {
                            padding: "0px", // Adjust padding as needed
                          },
                        },
                      }}
                    />
                  </Grid>
                )}
                {hapiAction === "Swipe" && (
                  <Grid item xs={12}>
                    <Typography sx={{ mb: 0.5 }}>Gap</Typography>
                    <TextField
                      size="small"
                      variant="outlined"
                      type="number"
                      name="gap"
                      value={taps}
                      onChange={handleChange}
                      InputProps={{
                        sx: {
                          height: "30px",
                          "& .MuiInputBase-input": {
                            padding: "0px", // Adjust padding as needed
                          },
                        },
                      }}
                    />
                  </Grid>
                )}
              </Grid>
            </Grid>
          </Grid>
        </Box>
      )}
    </Box>
  );
};

export default TapParameters;
