import {
  Box,
  IconButton,
  Typography,
  Select,
  MenuItem,
  Grid,
  TextField,
  Divider,
  FormControl,
  InputBase,
  InputLabel,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import ArrowCircleDown from "../assest/icons/arrow-right-circle.svg";
import ArrowCircleRight from "../assest/icons/arrow-circle.svg";
import { useDispatch, useSelector } from "react-redux";
import { setHapiFeature } from "../components/store/hapiPageSlice";
import { setHapiValues } from "../components/store/hapiSlice";
import { alpha, styled } from "@mui/material/styles";

import {
  createHapiScript,
  setHapiScriptValues,
} from "../components/store/hapiScriptSlice";
import { fetchScreenElements } from "../components/store/dutElementSlice";
import { fetchOcrElements } from "../components/store/ocrSlice";
import CustomizedSlider from "../components/PercentageSlider";
import { getScreenNameByElementId } from "../api/navigationApis";
const BootstrapInput = styled(InputBase)(({ theme, error }) => ({
  "label + &": {
    marginTop: theme.spacing(3),
  },
  "& .MuiInputBase-input": {
    borderRadius: 4,
    position: "relative",
    backgroundColor: theme.palette.mode === "light" ? "#F3F6F9" : "#1A2027",
    border: "1px solid",
    borderColor: error
      ? "red" // Apply red border when error exists
      : theme.palette.mode === "light"
      ? "#E0E3E7"
      : "#2D3843",
    fontSize: 16,
    width: "100%",
    padding: "10px 12px",
    transition: theme.transitions.create([
      "border-color",
      "background-color",
      "box-shadow",
    ]),
    fontFamily: [
      "-apple-system",
      "BlinkMacSystemFont",
      '"Segoe UI"',
      "Roboto",
      '"Helvetica Neue"',
      "Arial",
      "sans-serif",
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',
    ].join(","),
    "&:focus": {
      boxShadow: `${alpha(theme.palette.primary.main, 0.25)} 0 0 0 0.2rem`,
      borderColor: error ? "red" : theme.palette.primary.main, // Red border on focus if error
    },
  },
}));

const HapiElements = () => {
  const dispatch = useDispatch();
  const { hapiElements } = useSelector((state) => state.hapipage);
  const {
    hapiType,
    command,
    elementName,
    hapiApiName,
    hapiScriptName,
    hapiId,
    taps,
    force,
    ox,
    oy,
    matching,
    backposition,
    text,
    duration,
    hapiAction,
    screenName,
    element_id,
  } = useSelector((state) => state.hapivalues);
  const { scriptId } = useSelector((state) => state.hapiScripts);
  const { ocrElements } = useSelector((state) => state.ocr);
  const { screens } = useSelector((state) => state.dutScreen);
  const { screenelements } = useSelector((state) => state.screenelements);
  const [hapiApi, setHapiApi] = useState(hapiApiName);
  const [screenNames, setScreenNames] = useState(screenName);
  const isDisabled = true; // Check if the text is null or empty
  const handleExpandClick = () => {
    dispatch(setHapiFeature({ feature: "hapiElements", value: !hapiElements }));
  };
  const handleSelectScreen = (item) => {
    dispatch(fetchScreenElements(item.id));
    dispatch(fetchOcrElements(item.id));
    setScreenNames(item.screen_name);
    dispatch(setHapiValues({ feature: "screenName", value: item.screen_name }));
  };
  const handletextChange = (event) => {
    dispatch(setHapiValues({ feature: "text", value: event.target.value })); // Update state when the slider value changes
  };
  const handleSelectOption = (event) => {
    let emt = "";
    if (hapiType === "EMT") {
      emt = "EMT";
    } else if (hapiType === "OCR") {
      emt = "OCR";
    } else {
      emt = "OCT";
    }
    dispatch(
      setHapiValues({
        feature: "element_id",
        value: `${hapiType}:${event.id}`,
      })
    );
    emt = `${emt}:${event.id}`;
    let api = "";
    if (hapiType === "EMT") {
      dispatch(
        setHapiValues({ feature: "elementName", value: event.element_name })
      );
      if (hapiAction === "Single tap") {
        api = `${command}:${event.element_name}:${duration}:${backposition}:${force}:`;
      } else if (hapiAction === "Multi tap") {
        api = `${command}:${event.element_name}:${taps}:${duration}:${backposition}:${force}:`;
      } else if (hapiAction === "Move") {
        api = `${command}:${event.element_name}:`;
      }
      // }
      //  else if (hapiType === "CAP") {
      //   dispatch(
      //     setHapiValues({ feature: "elementName", value: event.screen_name })
      //   );
      //   api = `${command}:${event.screen_name}:`;
    } else if (hapiType === "OCR") {
      dispatch(
        setHapiValues({ feature: "elementName", value: event.ocr_name })
      );
      api = `${command}:${screenNames}:${event.ocr_name}:`;
    } else if (hapiType === "OCT") {
      dispatch(
        setHapiValues({ feature: "elementName", value: event.ocr_name })
      );
      api = `${command}:${screenNames}:${event.ocr_name}:${text}:rtn:${matching}:${duration}:${backposition}:${force}:${ox}:${oy}`;
    }

    setHapiApi(api); // This will set the hapiApi state

    // Ensure the API is set before dispatching the action
    setTimeout(() => {
      dispatch(setHapiValues({ feature: "hapiApiName", value: api }));

      const hapiScriptData = {
        hapi_id: parseInt(hapiId),
        api: api,
        name: hapiScriptName,
        element_id: emt,
      };
      // console.log(scriptId, "print id");
      if (!scriptId) {
        dispatch(createHapiScript(hapiScriptData));
      }
    }, 0);
  };
  // const handleUpdateHpiApi = () => {
  //   let api = "";
  //   if (hapiType === "CAP") {
  //     api = `${command}:${elementName}:`;
  //     setHapiApi(api);
  //   } else {
  //     if (hapiAction === "Single tap") {
  //       api = `${command}:${elementName}:${duration}:${backposition}:${force}:`;
  //       setHapiApi(api);
  //     } else if (hapiAction === "Multi tap") {
  //       api = `${command}:${elementName}:${taps}:${duration}:${backposition}:${force}:`;
  //       setHapiApi(api);
  //     }
  //   }

  //   dispatch(setHapiValues({ feature: "hapiApiName", value: hapiApi }));
  // };

  useEffect(() => {
    const run = async () => {
      dispatch(setHapiFeature({ feature: "hapiElements", value: true }));

      try {
        let elemId = element_id.split(":");
        if (elemId[0] === "EMT") {
          // Fetch screen name by element id
          await getScreenName(parseInt(elemId[1]));
        } else {
          // If not EMT, find the screen and fetch OCR elements
          const screen = screens.find((doc) => doc.screen_name === screenName);
          if (screen) {
            dispatch(fetchOcrElements(screen.id));
          } else {
            console.error("Screen not found for provided screen name");
          }
        }
      } catch (error) {
        console.error("Element id not found or error in useEffect:", error);
      }
    };

    run(); // Run the async function

    // Add all dependencies that could affect this effect
  }, [element_id, screens, screenName, dispatch]);

  // Async function for fetching screen name
  const getScreenName = async (params) => {
    try {
      const sName = await getScreenNameByElementId(params);
      if (sName) {
        setScreenNames(sName); // Update state with screen name
        dispatch(
          setHapiValues({
            feature: "screenName",
            value: sName,
          })
        );

        const screen = screens.find((doc) => doc.screen_name === sName);
        if (screen) {
          dispatch(fetchScreenElements(screen.id));
        } else {
          console.error("Screen not found for fetched screen name");
        }
      }
    } catch (error) {
      console.error("Error fetching screen name:", error);
    }
  };
  return (
    <Box
      sx={{
        border: "1px solid #DFE3EB",
        boxShadow:
          "rgba(9, 30, 66, 0.25) 0px 4px 8px -2px, rgba(9, 30, 66, 0.08) 0px 0px 0px 1px",
        m: 1,
        borderRadius: 2,
        "&:hover": {
          borderColor: "#33BFFF", // Change border color on hover
        },
      }}
    >
      <Box>
        <IconButton
          sx={{ "&:hover": { bgcolor: "transparent" } }}
          onClick={handleExpandClick}
        >
          <img
            src={hapiElements ? ArrowCircleDown : ArrowCircleRight}
            alt="toggle icon"
            style={{ width: "24px", height: "24px" }}
          />
          <Typography sx={{ ml: 1 }}>{}</Typography>
        </IconButton>
      </Box>
      {hapiElements && hapiScriptName.length > 2 && (
        <Box sx={{ flexDirection: "column", p: 1 }}>
          <Grid container spacing={2}>
            {hapiAction === "Touch OCR" && (
              <>
                <Grid item xs={12}>
                  <Grid container spacing={1}>
                    <Grid item xs={12}>
                      <Typography gutterBottom>Text </Typography>
                      <FormControl
                        variant="standard"
                        sx={{ width: "100%", mb: 2 }} // Adding margin-bottom for spacing
                      >
                        <BootstrapInput
                          value={text}
                          id="bootstrap-input"
                          // type="number"
                          onChange={handletextChange}
                        />
                      </FormControl>
                    </Grid>

                    <Grid item xs={12}>
                      <CustomizedSlider />
                    </Grid>
                  </Grid>
                </Grid>
                {/* Divider after the second row */}
                <Grid item xs={12}>
                  <Divider sx={{ my: 1 }} />
                </Grid>
              </>
            )}
            <Grid
              item
              xs={12}
              sx={{
                opacity: hapiType === "OCT" && !text ? 0.5 : 1, // Make the box appear faded when disabled
                pointerEvents: hapiType === "OCT" && !text ? "none" : "auto", // Disable interactions when no text
              }}
            >
              <Grid container spacing={1}>
                <Grid item xs={12}>
                  <Typography sx={{ mb: 0.5 }}>Screen</Typography>
                  <Select
                    size="small"
                    variant="outlined"
                    sx={{
                      height: "30px",
                      width: "100%",
                      pl: 1,
                      "& .MuiInputBase-input": {
                        padding: "0px", // Adjust padding as needed
                      },
                    }}
                    MenuProps={{
                      PaperProps: {
                        style: {
                          maxHeight: 200, // Set the maximum height for the dropdown
                        },
                      },
                    }}
                    value={screenName}
                    //   onChange={(e) => handleSelectScreen(item)}
                  >
                    {screens.map((item, index) => (
                      <MenuItem
                        key={index}
                        value={item.screen_name}
                        onClick={(e) => handleSelectScreen(item)}
                      >
                        {item.screen_name}
                      </MenuItem>
                    ))}
                  </Select>
                </Grid>

                <Grid item xs={12}>
                  <Typography sx={{ mb: 0.5 }}>Element</Typography>
                  <Select
                    size="small"
                    variant="outlined"
                    sx={{
                      height: "30px",
                      width: "100%",
                      pl: 1,
                      "& .MuiInputBase-input": {
                        padding: "0px", // Adjust padding as needed
                      },
                    }}
                    MenuProps={{
                      PaperProps: {
                        style: {
                          maxHeight: 200, // Set the maximum height for the dropdown
                        },
                      },
                    }}
                    value={elementName}
                  >
                    {(hapiType === "EMT" ? screenelements : ocrElements).map(
                      (item, index) => (
                        <MenuItem
                          key={index}
                          value={
                            hapiType === "EMT"
                              ? item.element_name
                              : item.ocr_name
                          }
                          onClick={(e) => handleSelectOption(item)}
                        >
                          {hapiType === "EMT"
                            ? item.element_name
                            : item.ocr_name}
                        </MenuItem>
                      )
                    )}
                  </Select>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Box>
      )}
    </Box>
  );
};

export default HapiElements;
