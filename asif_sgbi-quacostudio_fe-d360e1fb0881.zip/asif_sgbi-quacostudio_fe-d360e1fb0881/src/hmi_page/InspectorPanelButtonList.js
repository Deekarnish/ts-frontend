import {
  Box,
  Button,
  IconButton,
  Typography,
  Menu,
  MenuItem,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import ArrowCircleDown from "../assest/icons/arrow-right-circle.svg";
import ArrowCircleRight from "../assest/icons/arrow-circle.svg";
import asteriskIcon from "../assest/icons/keyboard-asterisk-square.svg";
import { useDispatch, useSelector } from "react-redux";
import setButtonDetails from "../utils/setDutdetails";
import {
  clearState,
  deleteDutButton,
  setParams,
} from "../components/store/dutButtonSlice";
import { enableFeature, setFeature } from "../components/store/pageSlice";
import { movetoElementPosition } from "../api/navigationApis";
import {
  disableAllAndEnableOption,
  setFeatureExpand,
} from "../components/store/hmiOptionsSlice";
import deleteIcon from "../assest/icons/delete-icon.svg";
import DeleteConfirmationModal from "../components/modals/DeleteConfirmationModal";
import { disableVideoFeedCanvas } from "../components/store/videoFeedSlice";

const menusx = {
  width: 120,
  "&:hover": {
    borderRadius: 3,
    // background:"linear-.(90deg, rgba(11,139,217,1) 0%, rgba(46,114,195,1) 72%, rgba(65,101,240,1) 99%)",
    bgcolor: "#3391FF",
  },
};
const ButtonActive = {
  mb: 1,
  width: "100%",
  color: "white",
  textTransform: "none",
  pl: 3,
  justifyContent: "flex-start", // Align content to the left
  background: "linear-gradient(90deg, #33BFFF 0%, #5D5CE5 100%)",
};

const ButtonNormalStyle = {
  width: "100%",
  textTransform: "none",
  bgcolor: "#E9F3FC",
  pl: 3,
  mb: 1,
  color: "#232328",
  justifyContent: "flex-start", // Align content to the left
};
const InspectorPanelButtonList = ({ onClearRectangle }) => {
  const [openDeleteConfirmation, setOpenDeleteConfirmation] = useState(false);
  const { buttonExpand } = useSelector((state) => state.hmiOptionsSlice);
  const dispatch = useDispatch();
  const { buttons, activeIndex } = useSelector((state) => state.dutButtons);
  const [anchorEl, setAnchorEl] = useState(false);
  const [buttonId, setButtonId] = useState(null);
  const handleExpandClick = () => {
    if (buttonExpand) {
      dispatch(setFeatureExpand({ feature: "buttonExpand", value: false }));
      console.log("test");
    } else {
      dispatch(disableAllAndEnableOption("buttonExpand"));
      dispatch(setFeature({feature:"screens" , value:false}))
    }
  };
  useEffect(() => {}, []);
  const handleClose = () => {
    setAnchorEl(false);
  };

  const handleDelete = () => {
    dispatch(deleteDutButton(buttonId));
    setOpenDeleteConfirmation(false);
  };

  const handleClicked = (details, index) => {
    // Step 1: Set button details

    const values = setButtonDetails(details);
    // Step 2: Clear the rectangle and clear the state when API call starts
    dispatch(disableVideoFeedCanvas('globalNavigationEnabled'))

    dispatch(clearState()); // Clear Redux state if necessary (e.g., set to initial state)
    
    // Step 3: Make the API call
    movetoElementPosition(values.button_position)
      .then((response) => {
        // Step 4: After the promise is fulfilled, setParams and setFeature
        dispatch(setParams(values)); // Dispatch the updated parameters
        dispatch(enableFeature("buttons")); // Set feature after success
        onClearRectangle(); // Clear the rectangle
        dispatch(
          setFeatureExpand({ feature: "propertiesGlobal", value: true })
        );
        dispatch(
          setFeatureExpand({ feature: "propertiesRegion", value: true })
        );
        dispatch(
          setFeatureExpand({ feature: "propertiesGeneral", value: true })
        );
        dispatch(
          setParams({ update: true, create: false, activeIndex: index })
        );
      })
      .catch((error) => {
        // Handle any errors from the API call
        console.error("Error during API call:", error);
      });
  };
  const handleRightClick = (e, item, index) => {
    setAnchorEl(e.currentTarget);
    setButtonId(item.id);
  };
  const handleClickDelete = () => {
    setOpenDeleteConfirmation(true);
    handleClose();
  };

  const rightClickMenu = () => {
    return (
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)} // Opens the submenu on click
        onClose={handleClose}
        sx={{ width: 350 }}
        PaperProps={{
          sx: {
            pl: 1,
            pr: 1,
            border: "1px solid #3391FF",
            borderRadius: 2,
          },
        }}
        anchorOrigin={{
          vertical: "top",
          horizontal: "right", // Aligns the submenu to the right side of the main menu
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "left", // Ensures the submenu opens to the right
        }}
      >
        <MenuItem sx={menusx} name="move" onClick={handleClickDelete}>
          {""}
          <img
            src={deleteIcon}
            alt="indicator icon"
            style={{
              width: "20px",
              height: "20px",
              textTransform: "none",
              marginRight: "5px",
            }}
          />
          Delete
        </MenuItem>
      </Menu>
    );
  };

  return (
    <>
      {buttons.length > 0 && (
        <Box
          sx={{
            border:"1px solid #DFE3EB",
            boxShadow:
              "rgba(9, 30, 66, 0.25) 0px 4px 8px -2px, rgba(9, 30, 66, 0.08) 0px 0px 0px 1px",
            m: 1,
            borderRadius: 2,
            "&:hover": {
              borderColor: "#33BFFF", // Change border color on hover
            },
          }}
        >
          <Box>
            <IconButton
              sx={{ "&:hover": { bgcolor: "transparent" } }}
              onClick={handleExpandClick}
            >
              <img
                src={buttonExpand ? ArrowCircleDown : ArrowCircleRight}
                alt="toggle icon"
                style={{ width: "24px", height: "24px" }}
              />
              <Typography sx={{ ml: 1 }}>Buttons</Typography>
            </IconButton>
          </Box>
          {buttonExpand && (
            <Box
              sx={{
                flexDirection: "column",
                p: 1,
                maxHeight: 300,
                overflow: "auto",
                p: 0.5,
              }}
            >
              {buttons.map((item, index) => (
                <Button
                  startIcon={
                    <img
                      src={asteriskIcon}
                      alt="indicator icon"
                      style={{ width: "20px", height: "20px" }}
                    />
                  }
                  sx={activeIndex === index ? ButtonActive : ButtonNormalStyle}
                  onClick={() => handleClicked(item, index)}
                  key={index}
                  onContextMenu={(e) => {
                    e.preventDefault();
                    handleRightClick(e, item, index); // Function to handle right-click
                  }}
                >
                  {item.button_name}
                </Button>
              ))}
            </Box>
          )}
        </Box>
      )}
      {rightClickMenu()}
      <DeleteConfirmationModal
        openDeleteConfirmation={openDeleteConfirmation}
        setOpenDeleteConfirmation={setOpenDeleteConfirmation}
        handleDelete={handleDelete}
      />
    </>
  );
};

export default InspectorPanelButtonList;
