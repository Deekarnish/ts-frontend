import React, { forwardRef, useEffect, useState } from "react";
import { setElementParams } from "../components/store/dutElementSlice";
import { useDispatch, useSelector } from "react-redux";
import { base64ToImageUrl } from "../utils/setDutdetails";
import { cropElementApi, cropImageApi } from "../api/navigationApis";
import { setOcrParams } from "../components/store/ocrSlice";

// Use forwardRef to allow the parent component to pass the ref down
const ScreenElementsComponent = forwardRef(({ width, height, rect }, ref) => {
  const [isDrawing, setIsDrawing] = useState(false);
  const [startPos, setStartPos] = useState({ x: 0, y: 0 });
  const [endPos, setEndPos] = useState({ x: 0, y: 0 });
  const [lastRect, setLastRect] = useState(null);
  const dispatch = useDispatch();
  const { ocr, elements } = useSelector((state) => state.page);
  const { sX, sY, sW, sH, isDrawingElement } = useSelector((state) =>
    elements ? state.screenelements : state.ocr
  );

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas) return;

    const context = canvas.getContext("2d");

    const handleMouseDown = (e) => {
      if (isDrawingElement) {
        setIsDrawing(true);
      }
      const { offsetX, offsetY } = e;
      if (
        offsetX >= rect.startX &&
        offsetX <= rect.startX + rect.width &&
        offsetY >= rect.startY &&
        offsetY <= rect.startY + rect.height
      ) {
        // Set start position relative to rect's startX and startY
        setStartPos({
          x: Math.floor(Math.max(offsetX - rect.startX)),
          y: Math.floor(Math.max(offsetY - rect.startY)),
        });
      }
    };

    const handleMouseMove = (e) => {
      if (!isDrawing) return;
      const { offsetX, offsetY } = e;

      // Prevent drawing from right to left or bottom to top
      if (
        offsetX < startPos.x + rect.startX ||
        offsetY < startPos.y + rect.startY
      )
        return;

      // Make sure the current position is within the `rect` bounds
      const currentX = Math.min(
        Math.max(offsetX, rect.startX),
        rect.startX + rect.width
      );
      const currentY = Math.min(
        Math.max(offsetY, rect.startY),
        rect.startY + rect.height
      );

      setEndPos({ x: currentX - rect.startX, y: currentY - rect.startY });

      // Clear the canvas before redrawing
      context.clearRect(0, 0, canvas.width, canvas.height);

      // Draw the provided rectangle (rect)
      context.strokeStyle = "blue";
      context.strokeRect(rect.startX, rect.startY, rect.width, rect.height);

      // Draw the user rectangle within bounds (only allowing left-to-right, top-to-bottom)
      context.strokeStyle = "red";
      const elementWidth = currentX - rect.startX - startPos.x;
      const elementHeight = currentY - rect.startY - startPos.y;
      context.strokeRect(
        startPos.x + rect.startX,
        startPos.y + rect.startY,
        elementWidth,
        elementHeight
      );

      // Update the last rectangle dimensions relative to the rect
      setLastRect({
        sX: Math.floor(startPos.x),
        sY: Math.floor(startPos.y),
        sW: Math.floor(elementWidth),
        sH: Math.floor(elementHeight),
      });
    };

    const handleMouseUp = async () => {
      setIsDrawing(false);
      if (!lastRect) return;
      const rois = {
        screen: {
          x: rect.startX,
          y: rect.startY,
          x2: rect.width,
          y2: rect.height,
        },
        element: {
          x: lastRect.sX,
          y: lastRect.sY,
          x2: lastRect.sW,
          y2: lastRect.sH,
        },
      };
      if (elements) {
        try {
          const res = await cropImageApi(
            rect.startX + lastRect.sX,
            rect.startY + lastRect.sY,
            lastRect.sW,
            lastRect.sH
          );

          const croppedImageURL = base64ToImageUrl(res.cropped_image_base64);
          dispatch(setElementParams({ elemUrl: croppedImageURL }));
          dispatch(setElementParams(lastRect));
          dispatch(setElementParams({ isDrawingElement: false }));
        } catch (error) {
          console.error("Error during cropping:", error);
        }
      } else if (ocr) {
        dispatch(setOcrParams(lastRect));
        dispatch(setOcrParams({ isDrawingElement: false }));
      }
    };

    canvas.addEventListener("mousedown", handleMouseDown);
    canvas.addEventListener("mousemove", handleMouseMove);
    canvas.addEventListener("mouseup", handleMouseUp);

    return () => {
      canvas.removeEventListener("mousedown", handleMouseDown);
      canvas.removeEventListener("mousemove", handleMouseMove);
      canvas.removeEventListener("mouseup", handleMouseUp);
    };
  }, [isDrawing, startPos, endPos, rect, lastRect, ref]);

  const reDrawScreenAndElements = () => {
    const canvas = ref.current;
    if (!canvas) return;

    const context = canvas.getContext("2d");
    // Clear the canvas before redrawing
    context.clearRect(0, 0, canvas.width, canvas.height);

    // Draw the provided rectangle (rect)
    context.strokeStyle = "blue";
    context.strokeRect(rect.startX, rect.startY, rect.width, rect.height);

    // Draw the user rectangle within bounds (only allowing left-to-right, top-to-bottom)
    context.strokeStyle = "red";

    context.strokeRect(sX + rect.startX, sY + rect.startY, sW, sH);
  };

  useEffect(() => {
    reDrawScreenAndElements();
  }, [sX, sY, sW, sH, rect]);

  return (
    <canvas
      ref={ref}
      width={width}
      height={height}
      style={{
        display: "block",
        position: "absolute",
        zIndex: 5,
        cursor: isDrawingElement ? "crosshair" : "default", // Correct cursor condition
      }}
    />
  );
});

export default ScreenElementsComponent;
