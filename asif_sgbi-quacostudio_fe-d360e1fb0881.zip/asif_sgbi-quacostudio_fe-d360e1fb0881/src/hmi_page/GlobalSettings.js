import { Box, Button, IconButton, Typography } from "@mui/material";
import React, { useState } from "react";
import ArrowCircleDown from "../assest/icons/arrow-right-circle.svg";
import ArrowCircleRight from "../assest/icons/arrow-circle.svg";
import { alpha, styled } from "@mui/material/styles";
import InputBase from "@mui/material/InputBase";
import InputLabel from "@mui/material/InputLabel";
import FormControl from "@mui/material/FormControl";
import Checkbox from "@mui/material/Checkbox";
import { useDispatch, useSelector } from "react-redux";
import { setParams, updateDutButton } from "../components/store/dutButtonSlice";
import { setFeature } from "../components/store/pageSlice";
import { setParamsSCreen, updateDutScreen } from "../components/store/dutScreenSlice";
import { setFeatureExpand } from "../components/store/hmiOptionsSlice";
import { Autorenew } from "@mui/icons-material";
import Cookies from "js-cookie";
const BootstrapInput = styled(InputBase)(({ theme }) => ({
  "label + &": {
    marginTop: theme.spacing(3),
  },
  "& .MuiInputBase-input": {
    borderRadius: 4,
    position: "relative",
    backgroundColor: theme.palette.mode === "light" ? "#F3F6F9" : "#1A2027",
    border: "1px solid",
    borderColor: theme.palette.mode === "light" ? "#E0E3E7" : "#2D3843",
    fontSize: 16,
    //   width: 'auto',
    width: "100%",
    padding: "10px 12px",
    transition: theme.transitions.create([
      "border-color",
      "background-color",
      "box-shadow",
    ]),
    // Use the system font instead of the default Roboto font.
    fontFamily: [
      "-apple-system",
      "BlinkMacSystemFont",
      '"Segoe UI"',
      "Roboto",
      '"Helvetica Neue"',
      "Arial",
      "sans-serif",
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',
    ].join(","),
    "&:focus": {
      boxShadow: `${alpha(theme.palette.primary.main, 0.25)} 0 0 0 0.2rem`,
      borderColor: theme.palette.primary.main,
    },
  },
}));

const GlobalSettings = () => {
  const dutId = Cookies.get("dutId");
  const feature = useSelector((state) => state.page);
  const { exposure, light , id} = useSelector((state) =>
    feature.buttons ? state.dutButtons : state.dutScreen
  );
  const dispatch = useDispatch();
  const { propertiesGlobal } = useSelector((state) => state.hmiOptionsSlice);

  const handleExpandClick = () => {
    dispatch(
      setFeatureExpand({
        feature: "propertiesGlobal",
        value: !propertiesGlobal,
      })
    );
  };
  const handleClick = (e) => {
    if (feature.buttons) {
      dispatch(setParams({ light: !light }));
      // dispatch(setFeature({ feature: "buttons", value: false }));  // Set feature after success
    } else if (feature.screens) {
      dispatch(setParamsSCreen({ light: !light }));
      // dispatch(setFeature({ feature: "screens", value: false }));  // Set feature after success
    }
  };
  const handleChange = (e) => {
    if (feature.buttons) {
      dispatch(setParams({ exposure: e.target.value }));
    } else if (feature.screens) {
      dispatch(setParamsSCreen({ exposure: e.target.value }));
    }
  };

  const updateGolbalSettings = () =>{
    if (feature.buttons) {
    const buttonData = {
      light: light,
      dut_id: dutId,
    };
    dispatch(updateDutButton({ id: id, dutButtonData: buttonData }))
    

    }else if(feature.screens){
      const screenData = {
        light: light,
        dut_id: dutId,
      };
      dispatch(updateDutScreen({ id: id, dutScreenData: screenData }));
    }
  }
  return (
    <Box
      sx={{
        border: "1px solid #DFE3EB",
        boxShadow:
          "rgba(9, 30, 66, 0.25) 0px 4px 8px -2px, rgba(9, 30, 66, 0.08) 0px 0px 0px 1px",
        m: 1,
        borderRadius: 2,
        "&:hover": {
          borderColor: "#33BFFF", // Change border color on hover
        },
      }}
    >
      <Box display="flex" alignItems="center" justifyContent="space-between">
        <IconButton
          sx={{ "&:hover": { bgcolor: "transparent" } }}
          onClick={handleExpandClick}
        >
          <img
            src={propertiesGlobal ? ArrowCircleDown : ArrowCircleRight}
            alt="toggle icon"
            style={{ width: "24px", height: "24px" }}
          />
          <Typography sx={{ ml: 1 }}>Global Settings</Typography>
        </IconButton>
        <IconButton onClick={updateGolbalSettings}>
          {propertiesGlobal && <Autorenew/>}
        </IconButton>
      </Box>
      {propertiesGlobal && (
        <Box sx={{ display: "flex", flexDirection: "row", p: 1 }}>
          <FormControl variant="standard" sx={{ width: "70%" }}>
            <InputLabel shrink htmlFor="bootstrap-input">
              Exposure
            </InputLabel>
            <BootstrapInput
              id="bootstrap-input"
              value={exposure}
              onChange={(e) => handleChange(e)}
            />
          </FormControl>
          <Box
            sx={{ display: "flex", alignItems: "center", width: "30%", ml: 1 }}
          >
            <Checkbox
              sx={{
                mt: 3,
                color: "blue", // Set the default color (unchecked)
                "&.Mui-checked": {
                  color: "blue", // Set the color when checked
                },
              }}
              onClick={handleClick}
              value={light}
              checked={light}
            />
            <span style={{ marginTop: 23 }}>light</span>
          </Box>
        </Box>
      )}
    </Box>
  );
};

export default GlobalSettings;
