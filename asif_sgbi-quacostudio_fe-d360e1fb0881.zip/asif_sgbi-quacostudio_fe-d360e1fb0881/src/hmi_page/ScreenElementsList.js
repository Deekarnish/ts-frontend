import { Box, Button, IconButton, Typography,Menu,MenuItem } from "@mui/material";
import React, { useState } from "react";
import ArrowCircleDown from "../assest/icons/arrow-right-circle.svg";
import ArrowCircleRight from "../assest/icons/arrow-circle.svg";
import elementsIcon from "../assest/icons/elements.svg";
import { useDispatch, useSelector } from "react-redux";
import {
  disableAllAndEnableOption,
  setFeatureExpand,
} from "../components/store/hmiOptionsSlice";
import DeleteConfirmationModal from "../components/modals/DeleteConfirmationModal";
import deleteIcon from "../assest/icons/delete-icon.svg";
import { deleteOcrElement } from "../components/store/ocrSlice";
import { deleteScreenElement, setElementParams, setSelectedElement } from "../components/store/dutElementSlice";
import setElementDetails from "../utils/setElementDetails";
import { setFeature } from "../components/store/pageSlice";

const ButtonActive = {
  mb: 1,
  width: "100%",
  color: "white",
  textTransform: "none",
  pl: 3,
  justifyContent: "flex-start", // Align content to the left
  background: "linear-gradient(90deg, #33BFFF 0%, #5D5CE5 100%)",
};
const buttonNormalStyle = {
  width: "100%",
  textTransform: "none",
  bgcolor: "#E9F3FC",
  pl: 3,
  mb: 1,
  color: "#232328",
  justifyContent: "flex-start", // Align content to the left
};

const menusx = {
  width: 120,
  "&:hover": {
    borderRadius: 3,
    // background:"linear-.(90deg, rgba(11,139,217,1) 0%, rgba(46,114,195,1) 72%, rgba(65,101,240,1) 99%)",
    bgcolor: "#3391FF",
  },
};

const ScreenElementsList = () => {
  const dispatch = useDispatch();

  const [openDeleteConfirmation, setOpenDeleteConfirmation] = useState(false);
  const { ocrExpand } = useSelector((state) => state.hmiOptionsSlice);
  const { screenelements } = useSelector((state) => state.screenelements);
  const [anchorEl, setAnchorEl] = useState(false);
  const [screenId , setScreenID] = useState(null)
  const [expand , setExpanded] = useState(false)

  const handleExpandClick = () => {
    // if (ocrExpand) {
    //   dispatch(setFeatureExpand({ feature: "ocrExpand", value: false }));
    // } else {
    //   dispatch(disableAllAndEnableOption("ocrExpand"));
    // }
    setExpanded(!expand)
  };
  const handleClickElement = (item , index) =>{
    const values = setElementDetails(item);
    dispatch(setSelectedElement(item.id));
    dispatch(setElementParams(values));
    dispatch(setElementParams({updateElement:true}))
    dispatch(setFeature({feature:"elements" , value:true}))
  }
  const handleClose = () => {
    setAnchorEl(false);
  };
  const handleDelete = () => {
    dispatch(deleteScreenElement(screenId));
    setOpenDeleteConfirmation(false);
  };

  const handleRightClick = (e, item, index) => {
    setAnchorEl(e.currentTarget);
    setScreenID(item.id);
  };
  const handleClickDelete = () => {
    setOpenDeleteConfirmation(true);
    // handleClose()
  };
  const rightClickMenu = () => {
    return (
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)} // Opens the submenu on click
        onClose={handleClose}
        sx={{ width: 350 }}
        PaperProps={{
          sx: {
            pl: 1,
            pr: 1,
            border: "1px solid #3391FF",
            borderRadius: 2,
          },
        }}
        anchorOrigin={{
          vertical: "top",
          horizontal: "right", // Aligns the submenu to the right side of the main menu
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "left", // Ensures the submenu opens to the right
        }}
      >
        <MenuItem sx={menusx} name="move" onClick={(e) => handleClickDelete()}>
          {""}
          <img
            src={deleteIcon}
            alt="indicator icon"
            style={{
              width: "20px",
              height: "20px",
              textTransform: "none",
              marginRight: "5px",
            }}
          />
          Delete
        </MenuItem>
      </Menu>
    );
  };

  return (
    <Box
      sx={{
        border: "1px solid #DFE3EB",
        boxShadow:
          "rgba(9, 30, 66, 0.25) 0px 4px 8px -2px, rgba(9, 30, 66, 0.08) 0px 0px 0px 1px",
        mt: 1,
        borderRadius: 2,
        "&:hover": {
          borderColor: "#33BFFF", // Change border color on hover
        },
      }}
    >
      <Box>
        <IconButton
          sx={{ "&:hover": { bgcolor: "transparent" } }}
          onClick={handleExpandClick}
        >
          <img
            src={expand ? ArrowCircleDown : ArrowCircleRight}
            alt="toggle icon"
            style={{ width: "24px", height: "24px" }}
          />
          <Typography sx={{ ml: 1 }}>Elements</Typography>
        </IconButton>
      </Box>
      {expand && (
        <Box
          sx={{
            flexDirection: "column",
            p: 1,
            maxHeight: 300,
            textAlign: "left",
            overflowY:"auto",
            "&::-webkit-scrollbar": {
                width: "7px", // Width of the scrollbar
              },
              "&::-webkit-scrollbar-track": {
                backgroundColor: "#f1f1f1", // Background of the track
              },
              "&::-webkit-scrollbar-thumb": {
                backgroundColor: "#cccc", // Color of the scrollbar thumb
                borderRadius: "8px", // Rounded corners of the thumb
                maxHeight: "50px", // Adjust the minimum height of the scrollbar thumb
              },
              "&::-webkit-scrollbar-thumb:hover": {
                backgroundColor: "#cccc", // Color when hovered
              },
          }}
        >
          {screenelements.map((item, index) => (
            <Button
              key={index}
              startIcon={
                <img
                  src={elementsIcon}
                  alt="indicator icon"
                  style={{
                    width: "20px",
                    height: "20px",
                    textTransform: "none",
                    textAlign: "left",
                  }}
                />
              }
              sx={{
                width: "100%",
                textTransform: "none",
                bgcolor: "#E9F3FC",
                mb: 1,
                color: "#232328",
                justifyContent:"flex-start"
              }}
              onContextMenu={(e) => {
                e.preventDefault();
                handleRightClick(e, item, index); // Function to handle right-click
              }}
              onClick={e => handleClickElement(item , index)}
            >
              {item.element_name}
            </Button>
          ))}
        </Box>
      )}
      <DeleteConfirmationModal
        openDeleteConfirmation={openDeleteConfirmation}
        setOpenDeleteConfirmation={setOpenDeleteConfirmation}
        handleDelete={handleDelete}
      />
         {rightClickMenu()}
    </Box>
  );
};

export default ScreenElementsList;
