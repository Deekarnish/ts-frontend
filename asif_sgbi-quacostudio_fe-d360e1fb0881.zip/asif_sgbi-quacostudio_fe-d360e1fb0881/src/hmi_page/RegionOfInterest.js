import {
  Box,
  Button,
  IconButton,
  Typography,
  Grid,
  TextField,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import ArrowCircleDown from "../assest/icons/arrow-right-circle.svg";
import ArrowCircleRight from "../assest/icons/arrow-circle.svg";
import IndicatorIcon from "../assest/icons/LightBulb.svg";
import { useDispatch, useSelector } from "react-redux";
import { setParams, updateDutButton } from "../components/store/dutButtonSlice";
import { setFeatureExpand } from "../components/store/hmiOptionsSlice";
import demiCrop from "../assest/images/694979.png";
import editIcon from "../assest/icons/edit-icon.svg";
import { disableAllAndEnableFeature, enableVideoFeedCanvas } from "../components/store/videoFeedSlice";
import {
  setParamsSCreen,
  updateDutScreen,
} from "../components/store/dutScreenSlice";
import { Autorenew } from "@mui/icons-material";
import Cookies from "js-cookie";

const RegionOfInterest = () => {
  const dutId = Cookies.get("dutId");
  const feature = useSelector((state) => state.page);
  const { startX, startY, width, height, imgurl, id } = useSelector((state) =>
    feature.buttons ? state.dutButtons : state.dutScreen
  );
  const sw = width;
  const [sides, setSides] = useState({ top: 0, left: 0, bottom: 0, right: 0 });
  const dispatch = useDispatch();
  const vFeed = useSelector((state) => state.vFeed);
  const { propertiesRegion } = useSelector((state) => state.hmiOptionsSlice);

  const handleExpandClick = () => {
    dispatch(
      setFeatureExpand({
        feature: "propertiesRegion",
        value: !propertiesRegion,
      })
    );
  };

  const adjustWidthKeepingLeftStatic = (name, e) => {
    const newValue = parseInt(e.target.value, 10); // New input value
    const prevValue = sides[name]; // Current value from state

    // Calculate the difference
    const difference = newValue - prevValue;

    // Calculate the new width
    const newWidth = width + difference;

    // Update the sides state
    setSides((prev) => ({
      ...prev,
      [name]: newValue,
    }));

    // Ensure new width is positive
    if (newWidth >= 0) {
      if (feature.buttons) {
        dispatch(setParams({ width: newWidth }));
      } else if (feature.screens) {
        dispatch(setParamsSCreen({ width: newWidth }));
      }
    }
  };

  const adjustWidthKeepingRightStatic = (name, e) => {
    const newValue = parseInt(e.target.value, 10); // New value from input
    const prevValue = sides[name]; // Current value from state

    // Calculate the difference
    const difference = newValue - prevValue;

    // Calculate the new width
    const newWidth = width + difference;

    // Calculate the new startX to keep the right edge static
    const newStartX = startX - difference;

    // Update the sides state
    setSides((prev) => ({
      ...prev,
      [name]: newValue,
    }));

    // Ensure new width and startX are positive
    if (newWidth >= 0 && newStartX >= 0) {
      if (feature.buttons) {
        dispatch(setParams({ width: newWidth, startX: newStartX }));
      } else if (feature.screens) {
        dispatch(setParamsSCreen({ width: newWidth, startX: newStartX }));
      }
    }
  };
  const adjustTopKeepingBottomStatic = (name, e) => {
    // console.log(feature, "feature");
    const newValue = parseInt(e.target.value, 10); // New value from input
    const prevValue = sides[name]; // Current value from state

    // Calculate the difference
    const difference = newValue - prevValue;

    // Calculate the new height
    const newHeight = height - difference;

    // Update the top edge
    const newStartY = startY + difference;

    // Update the sides state
    setSides((prev) => ({
      ...prev,
      [name]: newValue,
    }));

    // Ensure new height and startY are positive
    if (newHeight >= 0 && newStartY >= 0) {
      if (feature.buttons) {
        dispatch(setParams({ startY: newStartY, height: newHeight }));
      } else if (feature.screens) {
        dispatch(setParamsSCreen({ startY: newStartY, height: newHeight }));
      }
    }
  };
  const adjustBottomKeepingTopStatic = (name, e) => {
    const newValue = parseInt(e.target.value, 10); // New value from input
    const prevValue = sides[name]; // Current value from state

    // Calculate the difference
    const difference = newValue - prevValue;

    // Calculate the new height
    const newHeight = height + difference;

    // Update the bottom edge
    const newStartY = startY;

    // Update the sides state
    setSides((prev) => ({
      ...prev,
      [name]: newValue,
    }));

    // Ensure new height is positive
    if (newHeight >= 0) {
      if (feature.buttons) {
        dispatch(setParams({ height: newHeight }));
      } else if (feature.screens) {
        dispatch(setParamsSCreen({ height: newHeight }));
      }
    }
  };
  const handleRedraw = () => {
    dispatch(disableAllAndEnableFeature("buttonDrawEnabled"));
  };
  const updateRegion = () => {
    if (feature.buttons) {
      const buttonData = {
        button_roi: `${startX}:${startY}:${width}:${height}`,
        dut_id: dutId,
        button_image: imgurl.split(",")[1],
      };
      dispatch(updateDutButton({ id: id, dutButtonData: buttonData }));
    } else if (feature.screens) {
      const screenData = {
        screen_roi: `${startX}:${startY}:${width}:${height}`,
        dut_id: dutId,
      };
      dispatch(updateDutScreen({ id: id, dutScreenData: screenData }));
    }
  };
  useEffect(()=>{
    dispatch(
      setFeatureExpand({
        feature: "propertiesRegion",
        value: true,
      }))
  },[])
  return (
    <Box
      sx={{
        border: "1px solid #DFE3EB",
        boxShadow:
          "rgba(9, 30, 66, 0.25) 0px 4px 8px -2px, rgba(9, 30, 66, 0.08) 0px 0px 0px 1px",
        m: 1,
        borderRadius: 2,
        "&:hover": {
          borderColor: "#33BFFF", // Change border color on hover
        },
      }}
    >
      <Box display="flex" alignItems="center" justifyContent="space-between">
        <IconButton
          sx={{ "&:hover": { bgcolor: "transparent" } }}
          onClick={handleExpandClick}
        >
          <img
            src={propertiesRegion ? ArrowCircleDown : ArrowCircleRight}
            alt="toggle icon"
            style={{ width: "24px", height: "24px" }}
          />
          <Typography sx={{ ml: 1 }}>Region of interest (mm)</Typography>
        </IconButton>
        {id && (
          <IconButton onClick={updateRegion}>
            {propertiesRegion && <Autorenew />}
          </IconButton>
        )}
      </Box>
      {propertiesRegion && (
        <Box sx={{ flexDirection: "column", p: 1 }}>
          <Grid container spacing={2}>
            <Grid item xs={5}>
              <Box
                sx={{
                  position: "relative", // Relative positioning for the container
                  borderRadius: 2,
                  height: "100%",
                  width: "100%",
                  maxHeight: { xs: 100, md: 130 },
                }}
              >
                <Box
                  component="img"
                  sx={{
                    borderRadius: 2,
                    height: "100%", // Adjust the height as needed
                    width: "100%", // Adjust the width as needed
                    maxHeight: { xs: 110, md: 130 },
                    objectFit: "contain", // Ensure the image covers the area without distortion
                  }}
                  alt="Small Image"
                  src={(feature.buttons && imgurl ) ? imgurl : demiCrop} // Replace with your image source
                />
                {!vFeed.buttonDrawEnabled && (
                  <IconButton
                    onClick={handleRedraw}
                    sx={{
                      position: "absolute",
                      p: 0.5,
                      bottom: 0, // Adjust based on your design
                      right: 0, // Adjust based on your design
                      color: "white", // Icon color
                      backgroundColor: "#33BFFF", // Background color with transparency
                      borderRadius: 2, // Circular background
                      "&:hover": {
                        backgroundColor: "rgba(0, 0, 0, 0.7)", // Darker on hover
                      },
                    }}
                  >
                    <img
                      src={editIcon}
                      alt="arrow up"
                      style={{ width: "20px", height: "20px" }}
                    />
                  </IconButton>
                )}
              </Box>
            </Grid>
            <Grid item xs={7}>
              <Grid container spacing={1}>
                <Grid item xs={6}>
                  <Box>
                    <Typography
                      component="span"
                      sx={{
                        fontSize: 14,
                        display: "block", // Forces the text to occupy a whole line
                      }}
                    >
                      Top
                    </Typography>
                    <TextField
                      size="small"
                      variant="outlined"
                      type="number"
                      value={sides.top}
                      onChange={(e) => adjustTopKeepingBottomStatic("top", e)}
                      sx={{ width: "70px", mt: 1 }}
                      InputProps={{
                        sx: {
                          height: "30px",
                          "& .MuiInputBase-input": {
                            padding: "5px", // Adjust padding as needed
                          },
                        },
                      }}
                    />
                  </Box>
                </Grid>
                <Grid item xs={6}>
                  <Box>
                    <Typography
                      component="span"
                      sx={{
                        fontSize: 14,
                        display: "block", // Forces the text to occupy a whole line
                      }}
                    >
                      Bottom
                    </Typography>
                    <TextField
                      size="small"
                      variant="outlined"
                      value={sides.bottom}
                      type="number"
                      sx={{ width: "70px", mt: 1 }}
                      onChange={(e) =>
                        adjustBottomKeepingTopStatic("bottom", e)
                      }
                      InputProps={{
                        sx: {
                          height: "30px",
                          "& .MuiInputBase-input": {
                            padding: "5px", // Adjust padding as needed
                          },
                        },
                      }}
                    />
                  </Box>
                </Grid>
                <Grid item xs={6}>
                  <Box>
                    <Typography
                      component="span"
                      sx={{
                        fontSize: 14,
                        display: "block", // Forces the text to occupy a whole line
                      }}
                    >
                      Left
                    </Typography>
                    <TextField
                      size="small"
                      variant="outlined"
                      value={sides.left}
                      type="number"
                      sx={{ width: "70px", mt: 1 }}
                      onChange={(e) => adjustWidthKeepingRightStatic("left", e)}
                      InputProps={{
                        sx: {
                          height: "30px",
                          "& .MuiInputBase-input": {
                            padding: "5px", // Adjust padding as needed
                          },
                        },
                      }}
                    />
                  </Box>
                </Grid>
                <Grid item xs={6}>
                  <Box>
                    <Typography
                      component="span"
                      sx={{
                        fontSize: 14,
                        display: "block", // Forces the text to occupy a whole line
                      }}
                    >
                      Right
                    </Typography>
                    <TextField
                      size="small"
                      variant="outlined"
                      value={sides.right}
                      sx={{ width: "70px", mt: 1 }} // Add margin-top for spacing if needed
                      onChange={(e) => adjustWidthKeepingLeftStatic("right", e)}
                      type="number"
                      InputProps={{
                        sx: {
                          height: "30px",
                          "& .MuiInputBase-input": {
                            padding: "5px", // Adjust padding as needed
                          },
                        },
                      }}
                    />
                  </Box>
                </Grid>
              </Grid>
            </Grid>
          </Grid>
        </Box>
      )}
    </Box>
  );
};

export default RegionOfInterest;
