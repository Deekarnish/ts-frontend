import React, { useState } from 'react';
import { Tabs, Tab, Box, Button } from '@mui/material';
import { PhoneMissed, PhoneMissedOutlined } from '@mui/icons-material';
import OcrGeneralSettings from './OcrGeneralSettings';
import EngineSettings from './EngineSettings';
import OcrSettings from './OcrSettingsComponent';
import { useDispatch, useSelector } from 'react-redux';
import OcrComponents from './OcrComponent';
import { setFeature } from '../components/store/pageSlice';
import DutOcrList from './DutOcrList';
import { clearOcrState, setOcrParams } from '../components/store/ocrSlice';
import ScreenElementsList from './ScreenElementsList';
import { clearElementState, setElementParams } from '../components/store/dutElementSlice';

const OcrScreenTabs = () => {
  const [selectedTab, setSelectedTab] = useState(0); // State to track the selected tab
  const {addElement}  = useSelector(state => state.screenelements)
  const { addOcr } =  useSelector(state => state.ocr)
  const dispatch = useDispatch()
  const handleTabChange = (event, newValue) => {
    setSelectedTab(newValue);
    if(newValue ===0){
      dispatch(clearElementState())
      dispatch(setFeature({ feature: "ocr", value: true }));
      dispatch(setFeature({ feature: "elements", value: false }));
    }else{
      dispatch(clearOcrState())
      dispatch(setFeature({ feature: "elements", value: true }));
      dispatch(setFeature({ feature: "ocr", value: false }));
    }
  };

 const handleAddOcr = () =>{
  dispatch(clearOcrState())
  dispatch(setFeature({ feature: "ocr", value: true }));
  dispatch(setFeature({ feature: "elements", value: false }));
  dispatch(setOcrParams({addOcr:true}))
 }

const handleAddScreen = () =>{
  dispatch(clearElementState())
  dispatch(setFeature({ feature: "elements", value: true }));
  dispatch(setFeature({ feature: "ocr", value: false }));
  dispatch(setElementParams({addElement:true}))
}
  return (
    <Box sx={{p: 1 }}>
        <Box sx={{height:30}}>
      <Tabs
        value={selectedTab}
        onChange={handleTabChange}
        indicatorColor="primary"
        textColor="primary"
        variant="fullWidth"
        sx={{
          backgroundColor: 'none', // Light background color
          boxShadow: '0px 4px 12px rgba(0, 0, 0, 0.1)', // Subtle box shadow
          borderRadius: '6px', // Rounded corners
          minHeight: '35px', // Adjust the height of the Tabs container
        }}
      >
        <Tab
          label="OCR"
          iconPosition="start"
          sx={{
            textTransform: 'none', // Prevent uppercase text
            fontWeight: selectedTab === 0 ? 'bold' : 'normal', // Bold when selected
            p:0,
            color: selectedTab === 0 ? '#0075FF' : '#333', // Blue for selected, default for others
            minHeight: '35px', // Adjust the height of the Tabs container
            "&.Mui-selected": {
              background: "linear-gradient(150deg, #33BFFF 0%, #5D5CE5 100%)",
            },
          }}
        //   icon={<PhoneMissedOutlined/>} 
        />
          <Tab
          label="Elements"
          sx={{
            textTransform: 'none',
            fontWeight: selectedTab === 1 ? 'bold' : 'normal',
            color: selectedTab === 1 ? '#0075FF' : '#333',
            p:0,
            minHeight: '35px', // Adjust the height of the Tabs container
            "&.Mui-selected": {
              background: "linear-gradient(150deg, #33BFFF 0%, #5D5CE5 100%)",
            },
          }}
        />
      </Tabs>
      </Box>
      <Box sx={{ pt: 1, mt: 1 }}>
        {selectedTab === 0 && (
          <>
          <DutOcrList/>
          {!addOcr && <Box >
          <Button
            variant="contained"
            sx={{
              background: "#0075FF",
              color: "white",
              textTransform: "none",
              mt: 1,
              height: 35,
              width: "100%",
              borderRadius: 2,
            }}
            onClick={handleAddOcr}
          >
            Add Field
          </Button>
        </Box> }
          </>
        )}
        {selectedTab === 1 && (<>
          <ScreenElementsList/>
        {!addElement && <Box >
          <Button
            variant="contained"
            sx={{
              background: "#0075FF",
              color: "white",
              textTransform: "none",
              mt: 1,
              height: 35,
              width: "100%",
              borderRadius: 2,
            }}
            onClick={handleAddScreen}
          >
            Add Element
          </Button>
        </Box> }
          </>
        )}
      </Box>
    </Box>
  );
};

export default OcrScreenTabs;
