import {
  Box,
  IconButton,
  Typography,
  Grid,
  Checkbox,
  TextareaAutosize,
  Divider,
} from "@mui/material";
import React, { useState } from "react";
import ArrowCircleDown from "../assest/icons/arrow-right-circle.svg";
import ArrowCircleRight from "../assest/icons/arrow-circle.svg";
import { useDispatch, useSelector } from "react-redux";
import { enableVideoFeedCanvas } from "../components/store/videoFeedSlice";
import { setHapiFeature } from "../components/store/hapiPageSlice";
import { setHapiValues } from "../components/store/hapiSlice";

const OcrSettings = () => {
  const feature = useSelector((state) => state.page);
  const [sides, setSides] = useState({ top: 0, left: 0, bottom: 0, right: 0 });
  const dispatch = useDispatch();
  const vFeed = useSelector((state) => state.vFeed);
  const { hapiTapParams } = useSelector((state) => state.hapipage);

  const { color, hsv, textCorrection, textDetection, ocrKeywords } =
    useSelector((state) => state.ocr);

  const handleExpandClick = () => {
    dispatch(
      setHapiFeature({ feature: "hapiTapParams", value: !hapiTapParams })
    );
  };

  const handleRedraw = () => {
    dispatch(enableVideoFeedCanvas("buttonDrawEnabled"));
  };

  const handleChange = (e) => {
    dispatch(setHapiValues({ feature: e.target.name, value: e.target.value }));
  };
  return (
    <Box
      sx={{
        border: "1px solid #DFE3EB",
        boxShadow:
          "rgba(9, 30, 66, 0.25) 0px 4px 8px -2px, rgba(9, 30, 66, 0.08) 0px 0px 0px 1px",
        m: 1,
        borderRadius: 2,
        "&:hover": {
          borderColor: "#33BFFF", // Change border color on hover
        },
      }}
    >
      <Box>
        <IconButton
          sx={{ "&:hover": { bgcolor: "transparent" } }}
          onClick={handleExpandClick}
        >
          <img
            src={hapiTapParams ? ArrowCircleDown : ArrowCircleRight}
            alt="toggle icon"
            style={{ width: "24px", height: "24px" }}
          />
          <Typography sx={{ ml: 1 }}>OCR Settings</Typography>
        </IconButton>
      </Box>
      {hapiTapParams && (
        <Box sx={{ flexDirection: "column", p: 1 }}>
          <Grid container spacing={1}>
            {/* First Row - Two Columns */}
            <Grid item xs={12}>
              <Typography sx={{ pl: 1, fontWeight: 550 }}>Mode</Typography>
            </Grid>
            <Grid item xs={6}>
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                }}
              >
                <Checkbox
                  name="color"
                  checked={color}
                  sx={{
                    color: color ? "blue" : "default", // Blue when checked
                    "&.Mui-checked": {
                      color: "blue", // Ensure the blue color persists when checked
                    },
                  }}
                />
                <Typography
                  component="span"
                  sx={{
                    fontSize: 12,
                  }}
                >
                  Color
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={6}>
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                }}
              >
                <Checkbox name="hsv" checked={hsv} />
                <Typography
                  component="span"
                  sx={{
                    fontSize: 12,
                  }}
                >
                  HSV
                </Typography>
              </Box>
            </Grid>

            {/* Divider after the first row */}
            <Grid item xs={12}>
              <Divider sx={{ my: 1 }} />{" "}
              {/* Adds some spacing around the divider */}
            </Grid>

            {/* Second Row - Two Columns */}
            <Grid item xs={12}>
              <Typography sx={{ pl: 1, fontWeight: 550 }}>
                Intelligence
              </Typography>
            </Grid>
            <Grid item xs={6}>
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                }}
              >
                <Checkbox name="textCorrection" checked={textCorrection} />
                <Typography
                  component="span"
                  sx={{
                    fontSize: 12,
                    whiteSpace: "nowrap",
                  }}
                >
                  Text Correction
                </Typography>
              </Box>
            </Grid>
            <Grid item xs={6}>
              <Box
                sx={{
                  display: "flex",
                  alignItems: "center",
                }}
              >
                <Checkbox name="textDetection" checked={textDetection} />
                <Typography
                  component="span"
                  sx={{
                    fontSize: 12,
                    whiteSpace: "nowrap",
                  }}
                >
                  Test Detection
                </Typography>
              </Box>
            </Grid>

            {/* Divider after the second row */}
            <Grid item xs={12}>
              <Divider sx={{ my: 1 }} />
            </Grid>

            {/* OCR Keywords */}
            <Grid item xs={12}>
              <Typography sx={{ pl: 1, fontWeight: 550 }}>
                OCR Keywords
              </Typography>
            </Grid>
            <Grid item xs={12}>
              <TextareaAutosize
                maxRows={6}
                minRows={6}
                aria-label="maximum height"
                placeholder="Enter ketwords separated by comma"
                value={ocrKeywords}
                style={{
                  width: "95%",
                  border: "none",
                  outline: "none",
                  resize: "none",
                  backgroundColor: "#CDE5FA",
                  fontFamily: "Arial, sans-serif",
                  marginLeft: "5px",
                  fontSize: "14px",
                  borderRadius: "8px",
                }}
              />
            </Grid>
          </Grid>
        </Box>
      )}
    </Box>
  );
};

export default OcrSettings;
