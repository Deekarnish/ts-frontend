import {
  Box,
  Button,
  IconButton,
  Typography,
  Menu,
  MenuItem,
} from "@mui/material";
import React, { useState } from "react";
import ArrowCircleDown from "../assest/icons/arrow-right-circle.svg";
import ArrowCircleRight from "../assest/icons/arrow-circle.svg";
import { useDispatch, useSelector } from "react-redux";
import screenIncon from "../assest/icons/screen.svg";
import deleteIcon from "../assest/icons/delete-icon.svg";
import {
  clearScreenState,
  deleteDutScreen,
  setParamsSCreen,
} from "../components/store/dutScreenSlice";
import setScreenDetails from "../utils/setScreenDetails";
import { enableFeature, setFeature } from "../components/store/pageSlice";
import { movetoElementPosition } from "../api/navigationApis";
import {
  disableAllAndEnableOption,
  setFeatureExpand,
} from "../components/store/hmiOptionsSlice";
import DeleteConfirmationModal from "../components/modals/DeleteConfirmationModal";
import { disableVideoFeedCanvas } from "../components/store/videoFeedSlice";
import {
  clearElementState,
  fetchScreenElements,
} from "../components/store/dutElementSlice";
import { fetchOcrElements } from "../components/store/ocrSlice";
import CustomBoxScrollbar from "../components/CustomBoxComponent";

const ButtonActive = {
  mb: 1,
  width: "100%",
  color: "white",
  textTransform: "none",
  pl: 3,
  justifyContent: "flex-start", // Align content to the left
  background: "linear-gradient(90deg, #33BFFF 0%, #5D5CE5 100%)",
};
const buttonNormalStyle = {
  width: "100%",
  textTransform: "none",
  bgcolor: "#E9F3FC",
  pl: 3,
  mb: 1,
  color: "#232328",
  justifyContent: "flex-start", // Align content to the left
};

const menusx = {
  width: 120,
  "&:hover": {
    borderRadius: 3,
    // background:"linear-.(90deg, rgba(11,139,217,1) 0%, rgba(46,114,195,1) 72%, rgba(65,101,240,1) 99%)",
    bgcolor: "#3391FF",
  },
};
const DutScreenList = ({ onClearRectangle }) => {
  const [openDeleteConfirmation, setOpenDeleteConfirmation] = useState(false);
  const dispatch = useDispatch();
  const { screens, activeIndex } = useSelector((state) => state.dutScreen);
  const { screenExapand } = useSelector((state) => state.hmiOptionsSlice);
  const [anchorEl, setAnchorEl] = useState(false);
  const [screenId, setScreenID] = useState(null);
  const handleExpandClick = () => {
    if (screenExapand) {
      dispatch(setFeatureExpand({ feature: "screenExapand", value: false }));
    } else {
      dispatch(disableAllAndEnableOption("screenExapand"));
    }
  };
  const handleClose = () => {
    setAnchorEl(false);
  };
  const handleDelete = () => {
    dispatch(deleteDutScreen(screenId));
    setOpenDeleteConfirmation(false);
  };
  const handleClicked = (details, index) => {
    // Step 1: Set button details
    dispatch(fetchScreenElements(details.id));
    dispatch(fetchOcrElements(details.id));
    const values = setScreenDetails(details);
    dispatch(disableVideoFeedCanvas("globalNavigationEnabled"));
    // Step 2: Clear the rectangle and clear the state when API call starts

    dispatch(clearScreenState()); // Clear Redux state if necessary (e.g., set to initial state)

    // Step 3: Make the API call
    movetoElementPosition(values.screen_position)
      .then((response) => {
        // Step 4: After the promise is fulfilled, setParams and setFeature
        dispatch(setParamsSCreen(values)); // Dispatch the updated parameters
        dispatch(enableFeature("screens")); // Set feature after success
        dispatch(clearElementState());

        // dispatch(enableFeature("elements")); // Set feature after success
        onClearRectangle(); // Clear the rectangle
        dispatch(
          setParamsSCreen({ update: true, create: false, activeIndex: index })
        );
      })
      .catch((error) => {
        // Handle any errors from the API call
        console.error("Error during API call:", error);
      });
  };
  const handleRightClick = (e, item, index) => {
    setAnchorEl(e.currentTarget);
    setScreenID(item.id);
  };
  const handleClickDelete = () => {
    setOpenDeleteConfirmation(true);
    // handleClose()
  };
  const rightClickMenu = () => {
    return (
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)} // Opens the submenu on click
        onClose={handleClose}
        sx={{ width: 350 }}
        PaperProps={{
          sx: {
            pl: 1,
            pr: 1,
            border: "1px solid #3391FF",
            borderRadius: 2,
          },
        }}
        anchorOrigin={{
          vertical: "top",
          horizontal: "right", // Aligns the submenu to the right side of the main menu
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "left", // Ensures the submenu opens to the right
        }}
      >
        <MenuItem sx={menusx} name="move" onClick={(e) => handleClickDelete()}>
          {""}
          <img
            src={deleteIcon}
            alt="indicator icon"
            style={{
              width: "20px",
              height: "20px",
              textTransform: "none",
              marginRight: "5px",
            }}
          />
          Delete
        </MenuItem>
      </Menu>
    );
  };
  return (
    <>
      {screens.length > 0 && (
        <Box
          sx={{
            border: "1px solid #DFE3EB",
            boxShadow:
              "rgba(9, 30, 66, 0.25) 0px 4px 8px -2px, rgba(9, 30, 66, 0.08) 0px 0px 0px 1px",
            m: 1,
            borderRadius: 2,
            "&:hover": {
              borderColor: "#33BFFF", // Change border color on hover
            },
          }}
        >
          <Box>
            <IconButton
              sx={{ "&:hover": { bgcolor: "transparent" } }}
              onClick={handleExpandClick}
            >
              <img
                src={screenExapand ? ArrowCircleDown : ArrowCircleRight}
                alt="toggle icon"
                style={{ width: "24px", height: "24px" }}
              />
              <Typography sx={{ ml: 1 }}>Screens</Typography>
            </IconButton>
          </Box>
          {screenExapand && (
             <CustomBoxScrollbar>
              {screens.map((item, index) => (
                <Button
                  startIcon={
                    <img
                      src={screenIncon}
                      alt="indicator icon"
                      style={{ width: "20px", height: "20px" }}
                    />
                  }
                  sx={activeIndex === index ? ButtonActive : buttonNormalStyle}
                  onClick={() => handleClicked(item, index)}
                  key={index}
                  onContextMenu={(e) => {
                    e.preventDefault();
                    handleRightClick(e, item, index); // Function to handle right-click
                  }}
                >
                  {item.screen_name}
                </Button>
              ))}
            </CustomBoxScrollbar>
          )}
          {rightClickMenu()}
        </Box>
      )}
      <DeleteConfirmationModal
        openDeleteConfirmation={openDeleteConfirmation}
        setOpenDeleteConfirmation={setOpenDeleteConfirmation}
        handleDelete={handleDelete}
      />
    </>
  );
};

export default DutScreenList;
