import { Box, Button, IconButton, Typography } from "@mui/material";
import React, { useState } from "react";
import ArrowCircleDown from "../assest/icons/arrow-right-circle.svg";
import ArrowCircleRight from "../assest/icons/arrow-circle.svg";
import indicatorIncon from "../assest/icons/LightBulb.svg";
import { useDispatch, useSelector } from "react-redux";
import { disableAllAndEnableOption, setFeatureExpand } from "../components/store/hmiOptionsSlice";
const DutIndicatorsList = () => {
  const dispatch = useDispatch()
  const { indicatorExpand } = useSelector(state => state.hmiOptionsSlice)

  const handleExpandClick = () => {
    if(indicatorExpand){
      dispatch(setFeatureExpand({feature:"indicatorExpand", value:false}))
    }else{
      dispatch(disableAllAndEnableOption('indicatorExpand'))
    }
  
  };
  return (
    <Box
      sx={{
        border: "1px solid #DFE3EB",
        boxShadow:
          "rgba(9, 30, 66, 0.25) 0px 4px 8px -2px, rgba(9, 30, 66, 0.08) 0px 0px 0px 1px",
        m: 1,
        borderRadius: 2,
        "&:hover": {
          borderColor: "#33BFFF", // Change border color on hover
        },
      }}
    >
      <Box>
        <IconButton
          sx={{ "&:hover": { bgcolor: "transparent" } }}
          onClick={handleExpandClick}
        >
          <img
            src={indicatorExpand ? ArrowCircleDown : ArrowCircleRight}
            alt="toggle icon"
            style={{ width: "24px", height: "24px" }}
          />
          <Typography sx={{ ml: 1 }}>Indicators</Typography>
        </IconButton>
      </Box>
      {indicatorExpand && (
        <Box sx={{ flexDirection: "column", p: 1 }}>
          <Button
            startIcon={
              <img
                src={indicatorIncon}
                alt="indicator icon"
                style={{ width: "20px", height: "20px" }}
              />
            }
            sx={{
              mb: 1,
              width: "100%",
              textTransform: "none",
              bgcolor: "#E9F3FC",
              mb: 1,
              color: "#232328",
            }}
          >
            Indicator A
          </Button>
          <Button
            startIcon={
              <img
                src={indicatorIncon}
                alt="indicator icon"
                style={{ width: "20px", height: "20px" }}
              />
            }
            sx={{
              width: "100%",
              textTransform: "none",
              bgcolor: "#E9F3FC",
              mb: 1,
              color: "#232328",
            }}
          >
            Indicator B
          </Button>
        </Box>
      )}
    </Box>
  );
};

export default DutIndicatorsList;
