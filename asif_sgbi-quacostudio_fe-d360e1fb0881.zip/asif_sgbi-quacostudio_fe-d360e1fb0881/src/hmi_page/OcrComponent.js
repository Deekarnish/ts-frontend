import React from 'react'
import OcrGeneralSettings from './OcrGeneralSettings'
import EngineSettings from './EngineSettings'
import OcrSettings from './OcrSettingsComponent'

const OcrComponents= ({setAddOcr}) => {
  return (
    <>
    <OcrGeneralSettings setAddOcr={setAddOcr}/>
    <EngineSettings/>
    <OcrSettings/>
    </>
  )
}

export default OcrComponents
