import { Box, Button, IconButton, Typography } from "@mui/material";
import React, { useState } from "react";
import ArrowCircleDown from "../assest/icons/arrow-right-circle.svg";
import ArrowCircleRight from "../assest/icons/arrow-circle.svg";
import { useDispatch, useSelector } from "react-redux";
import { disableAllAndEnableOption, setFeatureExpand } from "../components/store/hmiOptionsSlice";

const DutKeyPadList = () => {
  const dispatch = useDispatch()
  const { keyPadExapand } = useSelector(state => state.hmiOptionsSlice)

  const handleExpandClick = () => {
    if(keyPadExapand){
      dispatch(setFeatureExpand({feature:"keyPadExapand", value:false}))
    }else{
      dispatch(disableAllAndEnableOption('keyPadExapand'))
    }
  }

  return (
    <Box
      sx={{
        border: "1px solid #DFE3EB",
        boxShadow:
          "rgba(9, 30, 66, 0.25) 0px 4px 8px -2px, rgba(9, 30, 66, 0.08) 0px 0px 0px 1px",
        m: 1,
        borderRadius: 2,
        "&:hover": {
          borderColor: "#33BFFF", // Change border color on hover
        },
      }}
    >
      <Box>
        <IconButton
          sx={{ "&:hover": { bgcolor: "transparent" } }}
          onClick={handleExpandClick}
        >
          <img
            src={keyPadExapand ? ArrowCircleDown : ArrowCircleRight}
            alt="toggle icon"
            style={{ width: "24px", height: "24px" }}
          />
          <Typography sx={{ ml: 1 }}>Keypad</Typography>
        </IconButton>
      </Box>
      {keyPadExapand && (
        <Box sx={{ flexDirection: "column", p: 1 }}>
          <Button sx={{ mb: 1, width: "100%" }}>KEY 1</Button>
          <Button sx={{ mb: 1, width: "100%" }}>KEY 2</Button>
        </Box>
      )}
    </Box>
  );
};

export default DutKeyPadList;
