import {
  Box,
  Button,
  IconButton,
  MenuItem,
  Typography,
  Select,
} from "@mui/material";
import React, { useState } from "react";
import ArrowCircleDown from "../assest/icons/arrow-right-circle.svg";
import ArrowCircleRight from "../assest/icons/arrow-circle.svg";
import { alpha, styled } from "@mui/material/styles";
import InputBase from "@mui/material/InputBase";
import InputLabel from "@mui/material/InputLabel";
import FormControl from "@mui/material/FormControl";
import { useDispatch, useSelector } from "react-redux";
import { setParams } from "../components/store/dutButtonSlice";
import deleteIcon from "../assest/icons/delete-icon.svg";

const BootstrapInput = styled(InputBase)(({ theme }) => ({
  "label + &": {
    marginTop: theme.spacing(3),
  },
  "& .MuiInputBase-input": {
    borderRadius: 4,
    position: "relative",
    backgroundColor: theme.palette.mode === "light" ? "#F3F6F9" : "#1A2027",
    border: "1px solid",
    borderColor: theme.palette.mode === "light" ? "#E0E3E7" : "#2D3843",
    fontSize: 16,
    //   width: 'auto',
    width: "100%",
    padding: "10px 12px",
    transition: theme.transitions.create([
      "border-color",
      "background-color",
      "box-shadow",
    ]),
    // Use the system font instead of the default Roboto font.
    fontFamily: [
      "-apple-system",
      "BlinkMacSystemFont",
      '"Segoe UI"',
      "Roboto",
      '"Helvetica Neue"',
      "Arial",
      "sans-serif",
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',
    ].join(","),
    "&:focus": {
      boxShadow: `${alpha(theme.palette.primary.main, 0.25)} 0 0 0 0.2rem`,
      borderColor: theme.palette.primary.main,
    },
  },
}));

const IndicatorState = () => {
  const dispatch = useDispatch();
  const { name } = useSelector((state) => state.dutButtons);
  const [expanded, setExpanded] = useState(false);

  const handleExpandClick = () => {
    setExpanded(!expanded);
  };
  const handleChange = (e) => {
    dispatch(setParams({ name: e.target.value }));
  };
  return (
    <Box
      sx={{
        border: "1px solid #DFE3EB",
        boxShadow:
          "rgba(9, 30, 66, 0.25) 0px 4px 8px -2px, rgba(9, 30, 66, 0.08) 0px 0px 0px 1px",
        m: 1,
        borderRadius: 2,
        "&:hover": {
          borderColor: "#33BFFF", // Change border color on hover
        },
      }}
    >
      <Box>
        <IconButton
          sx={{ "&:hover": { bgcolor: "transparent" } }}
          onClick={handleExpandClick}
        >
          <img
            src={expanded ? ArrowCircleDown : ArrowCircleRight}
            alt="toggle icon"
            style={{ width: "24px", height: "24px" }}
          />
          <Typography sx={{ ml: 1 }}>States</Typography>
        </IconButton>
      </Box>
      {expanded && (
        <Box sx={{ flexDirection: "column", p: 1 }}>
          <FormControl variant="standard" sx={{ width: "100%" }}>
            <InputLabel shrink htmlFor="bootstrap-input">
              Name
            </InputLabel>
            <Box sx={{ display: "flex", alignItems: "center", width: "100%" }}>
              <BootstrapInput
                id="bootstrap-input"
                autoComplete="off"
                onChange={handleChange}
                sx={{
                  flex: 1,
                  backgroundColor: "#E9F3FC", // Background color for the input field
                  borderRadius:2,
                  "& .MuiInputBase-input": {
                    borderRadius: 2, // Apply border radius to the input field
                    backgroundColor: "#E9F3FC", // Ensure the background color is applied to the input area
                    padding: "10px", // Optional: adjust padding to match design
                  },
                  "& .MuiInputBase-root": {
                    borderRadius: 2, // Border radius for the input container
                  },
                }}
              />
              <IconButton>
                <img
                  src={deleteIcon}
                  alt="delete icon"
                  style={{
                    width: "20px",
                    height: "20px",
                    textTransform: "none",
                    marginLeft: "5px",
                  }}
                />
              </IconButton>
            </Box>
          </FormControl>

          <FormControl variant="outlined" sx={{ width: "100%" }}>
            {/* <InputLabel id="dropdown-label">{}</InputLabel> */}
            <Select
              labelId="dropdown-label"
              id="dropdown-select"
              //   value={value}
              onChange={handleChange}
              //   label={label} // This prop connects the label with the Select component
              sx={{
                backgroundColor: "#E9F3FC", // Background color
                borderRadius: 2, // Rounded corners
                mt: 1,
                height: 40,
                // "& .MuiOutlinedInput-notchedOutline": {
                //   borderColor: "#3391FF", // Border color
                // },
                "&:hover .MuiOutlinedInput-notchedOutline": {
                  borderColor: "#1A73E8", // Hover border color
                },
                "& .MuiSvgIcon-root": {
                  color: "#3391FF", // Dropdown arrow color
                },
                "& .MuiSelect-select": {
                  padding: "12px", // Padding inside the select
                  fontSize: "1rem", // Font size
                  color: "#1A73E8", // Font color
                },
              }}
            >
              {/* {options.map((option, index) => (
                <MenuItem key={index} value={option.value}>
                  {option.label}
                </MenuItem>
              ))} */}
              <MenuItem>test</MenuItem>
            </Select>
          </FormControl>
          <Button
            variant="contained"
            sx={{
              background: "#0075FF",
              color: "white",
              textTransform: "none",
              mt: 1,
              height: 35,
              width: "100%",
              borderRadius: 2,
            }}
          >
            Add state
          </Button>
        </Box>
      )}
    </Box>
  );
};

export default IndicatorState;
