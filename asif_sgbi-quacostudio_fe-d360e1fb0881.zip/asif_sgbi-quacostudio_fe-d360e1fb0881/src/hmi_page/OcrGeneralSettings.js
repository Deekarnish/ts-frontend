import { Box, IconButton, Typography, Grid, TextField } from "@mui/material";
import React, { useEffect, useState } from "react";
import ArrowCircleDown from "../assest/icons/arrow-right-circle.svg";
import ArrowCircleRight from "../assest/icons/arrow-circle.svg";
import { alpha, styled } from "@mui/material/styles";
import InputBase from "@mui/material/InputBase";
import InputLabel from "@mui/material/InputLabel";
import FormControl from "@mui/material/FormControl";
import { useDispatch, useSelector } from "react-redux";
import demiCrop from "../assest/images/694979.png";
import editIcon from "../assest/icons/edit-icon.svg";
import { setFeatureExpand } from "../components/store/hmiOptionsSlice";
import { createOcrElement, setOcrParams, updateOcrElement } from "../components/store/ocrSlice";
import { setFeature } from "../components/store/pageSlice";
import { areDocumentsDifferent } from "../utils/funcs";

const BootstrapInput = styled(InputBase)(({ theme }) => ({
  "label + &": {
    marginTop: theme.spacing(3),
  },
  "& .MuiInputBase-input": {
    borderRadius: 4,
    position: "relative",
    backgroundColor: theme.palette.mode === "light" ? "#F3F6F9" : "#1A2027",
    border: "1px solid",
    borderColor: theme.palette.mode === "light" ? "#E0E3E7" : "#2D3843",
    fontSize: 16,
    //   width: 'auto',
    width: "100%",
    padding: "10px 12px",
    transition: theme.transitions.create([
      "border-color",
      "background-color",
      "box-shadow",
    ]),
    // Use the system font instead of the default Roboto font.
    fontFamily: [
      "-apple-system",
      "BlinkMacSystemFont",
      '"Segoe UI"',
      "Roboto",
      '"Helvetica Neue"',
      "Arial",
      "sans-serif",
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',
    ].join(","),
    "&:focus": {
      boxShadow: `${alpha(theme.palette.primary.main, 0.25)} 0 0 0 0.2rem`,
      borderColor: theme.palette.primary.main,
    },
  },
}));

const OcrGeneralSettings = () => {
  const dispatch = useDispatch();

  const feature = useSelector((state) => state.page); // fetch feature value from redux state
  const {ocrElements , name, id, isDrawingElement, sW,sX,sH,sY,engine , model , ocrLanguage, addOcr} = useSelector((state) => state.ocr); // fetch name from redux slice based on the featuer
  const { ocrGeneral } = useSelector((state) => state.hmiOptionsSlice);
  const screenId = useSelector((state) => state.dutScreen.id);
  const [expand , setExpanded] = useState(true)
  const [sides, setSides] = useState({ top: 0, left: 0, bottom: 0, right: 0 });

  const handleExpandClick = () => {
    // dispatch(
    //   setFeatureExpand({
    //     feature: "ocrGeneral",
    //     value: !ocrGeneral,
    //   })
    // );
    setExpanded(!expand)
  };
  const handleChange = (e) => {
    dispatch(setOcrParams({ name: e.target.value }));
    if (e.target.value.length > 2) {
      dispatch(setOcrParams({ isDrawingElement: true }));
    }
  };
  const handleRedraw = () => {
    dispatch(setOcrParams({ isDrawingElement: true }));
    dispatch(setFeature({feature:"ocr" , value:true}))
  };
  const handleCreateOcr = () => {
    const ocrData = {
      ocr_name: name,
      ocr_roi: `${sX}:${sY}:${sW}:${sH}`,
      screen_id: parseInt(screenId),
      ocr_engine: engine,
      ocr_model: model,
      ocr_language: ocrLanguage,
      allow_list: "string",
      detection: false,
      correction: false,
    //   mode: "color", 
    };
    dispatch(createOcrElement(ocrData))
    dispatch(setOcrParams({updateOcr:true}))
    dispatch(setOcrParams({addOcr:false}))
  };
  useEffect(() => {
    if (name && sW > 0 && sH > 0 && addOcr && !id) {
      handleCreateOcr();
    }
  }, [name, sW, sH]);

 const updategeneralSettings = () =>{
  if (!id) {
    return;
  }
  
  const document = ocrElements.find(doc => doc.id === id);

  const ocrData = {
    ocr_name: name,
    ocr_roi: `${sX}:${sY}:${sW}:${sH}`,
    screen_id: parseInt(screenId),
    ocr_engine: engine,
    ocr_model: model,
    ocr_language: ocrLanguage,
    allow_list: "string",
    detection: false,
    correction: false,
  //   mode: "color", 
  };
   const isDifferent = areDocumentsDifferent(document , ocrData)
  if (id && isDifferent) {
    dispatch(updateOcrElement({ id: id, ocrData:ocrData}));
  }
 }
  const adjustWidthKeepingLeftStatic = (name, e) => {
    const newValue = parseInt(e.target.value, 10); // New input value
    const prevValue = sides[name]; // Current value from state

    // Calculate the difference
    const difference = newValue - prevValue;

    // Calculate the new width
    const newWidth = sW + difference;

    // Update the sides state
    setSides((prev) => ({
      ...prev,
      [name]: newValue,
    }));

    // Ensure new width is positive
    if (newWidth >= 0) {
      dispatch(setOcrParams({ sW: newWidth }));
    }
  };

  const adjustWidthKeepingRightStatic = (name, e) => {
    const newValue = parseInt(e.target.value, 10); // New value from input
    const prevValue = sides[name]; // Current value from state

    // Calculate the difference
    const difference = newValue - prevValue;

    // Calculate the new width
    const newWidth = sW + difference;

    // Calculate the new startX to keep the right edge static
    const newStartX = sX - difference;

    // Update the sides state
    setSides((prev) => ({
      ...prev,
      [name]: newValue,
    }));

    // Ensure new width and startX are positive
    if (newWidth >= 0 && newStartX >= 0) {
      dispatch(setOcrParams({ sW: newWidth, sX: newStartX }));
    }
  };
  const adjustTopKeepingBottomStatic = (name, e) => {
    const newValue = parseInt(e.target.value, 10); // New value from input
    const prevValue = sides[name]; // Current value from state

    // Calculate the difference
    const difference = newValue - prevValue;

    // Calculate the new height
    const newHeight = sH - difference;

    // Update the top edge
    const newStartY = sY + difference;

    // Update the sides state
    setSides((prev) => ({
      ...prev,
      [name]: newValue,
    }));

    // Ensure new height and startY are positive
    if (newHeight >= 0 && newStartY >= 0) {
      dispatch(setOcrParams({ sY: newStartY, sH: newHeight }));
    }
  };

  const adjustBottomKeepingTopStatic = (name, e) => {
    const newValue = parseInt(e.target.value, 10); // New value from input
    const prevValue = sides[name]; // Current value from state

    // Calculate the difference
    const difference = newValue - prevValue;

    // Calculate the new height
    const newHeight = sH + difference;

    // Update the bottom edge
    const newStartY = sY;

    // Update the sides state
    setSides((prev) => ({
      ...prev,
      [name]: newValue,
    }));

    // Ensure new height is positive
    if (newHeight >= 0) {
      dispatch(setOcrParams({ sH: newHeight }));
    }
  };
  return (
    <Box
      sx={{
        border: "1px solid #DFE3EB",
        boxShadow:
          "rgba(9, 30, 66, 0.25) 0px 4px 8px -2px, rgba(9, 30, 66, 0.08) 0px 0px 0px 1px",
        m: 1,
        borderRadius: 2,
        "&:hover": {
          borderColor: "#33BFFF", // Change border color on hover
        },
      }}
    >
      <Box display="flex" alignItems="center" justifyContent="space-between">
        <IconButton
          sx={{ "&:hover": { bgcolor: "transparent" } }}
          onClick={(e) => handleExpandClick()}
        >
          <img
            src={expand ? ArrowCircleDown : ArrowCircleRight}
            alt="toggle icon"
            style={{ width: "24px", height: "24px" }}
          />
          <Typography sx={{ ml: 1 }}>OCR General</Typography>
        </IconButton>
      </Box>
      {expand && (
        <>
          <Box
            sx={{ flexDirection: "column", p: 1 }}
            onMouseLeave={updategeneralSettings}
          >
            <FormControl variant="standard" sx={{ width: "100%" }}>
              <InputLabel shrink={true} htmlFor="bootstrap-input">
                Name
              </InputLabel>
              <BootstrapInput
                //   value={name}
                id="bootstrap-input"
                autoComplete="off"
                placeholder="Enter name "
                onChange={(e) => handleChange(e)}
                value={name}
              />
            </FormControl>
          </Box>
          <Box sx={{ flexDirection: "column", p: 1 }}>
            <Grid container spacing={2}>
              <Grid item xs={5}>
                <Box
                  sx={{
                    position: "relative", // Relative positioning for the container
                    borderRadius: 2,
                    height: "100%",
                    width: "100%",
                    maxHeight: { xs: 100, md: 130 },
                  }}
                >
                  <Box
                    component="img"
                    sx={{
                      borderRadius: 2,
                      height: "100%", // Adjust the height as needed
                      width: "100%", // Adjust the width as needed
                      maxHeight: { xs: 110, md: 130 },
                      objectFit: "contain", // Ensure the image covers the area without distortion
                    }}
                    alt="Small Image"
                    src={demiCrop} // Replace with your image source
                  />
                  {!isDrawingElement && (
                    <IconButton
                      onClick={handleRedraw}
                      sx={{
                        position: "absolute",
                        p: 0.5,
                        bottom: 0, // Adjust based on your design
                        right: 0, // Adjust based on your design
                        color: "white", // Icon color
                        backgroundColor: "#33BFFF", // Background color with transparency
                        borderRadius: 2, // Circular background
                        "&:hover": {
                          backgroundColor: "rgba(0, 0, 0, 0.7)", // Darker on hover
                        },
                      }}
                    >
                      <img
                        src={editIcon}
                        alt="arrow up"
                        style={{ width: "20px", height: "20px" }}
                      />
                    </IconButton>
                  )}
                </Box>
              </Grid>
              <Grid item xs={7}>
                <Grid container spacing={1}>
                  <Grid item xs={6}>
                    <Box>
                      <Typography
                        component="span"
                        sx={{
                          fontSize: 14,
                          display: "block", // Forces the text to occupy a whole line
                        }}
                      >
                        Top
                      </Typography>
                      <TextField
                        size="small"
                        variant="outlined"
                        type="number"
                          value={sides.top}
                          onChange={(e) => adjustTopKeepingBottomStatic("top", e)}
                        sx={{ width: "70px", mt: 1 }}
                        InputProps={{
                          sx: {
                            height: "30px",
                            "& .MuiInputBase-input": {
                              padding: "5px", // Adjust padding as needed
                            },
                          },
                        }}
                      />
                    </Box>
                  </Grid>
                  <Grid item xs={6}>
                    <Box>
                      <Typography
                        component="span"
                        sx={{
                          fontSize: 14,
                          display: "block", // Forces the text to occupy a whole line
                        }}
                      >
                        Bottom
                      </Typography>
                      <TextField
                        size="small"
                        variant="outlined"
                          value={sides.bottom}
                        type="number"
                        sx={{ width: "70px", mt: 1 }}
                          onChange={(e) =>
                            adjustBottomKeepingTopStatic("bottom", e)
                          }
                        InputProps={{
                          sx: {
                            height: "30px",
                            "& .MuiInputBase-input": {
                              padding: "5px", // Adjust padding as needed
                            },
                          },
                        }}
                      />
                    </Box>
                  </Grid>
                  <Grid item xs={6}>
                    <Box>
                      <Typography
                        component="span"
                        sx={{
                          fontSize: 14,
                          display: "block", // Forces the text to occupy a whole line
                        }}
                      >
                        Left
                      </Typography>
                      <TextField
                        size="small"
                        variant="outlined"
                        value={sides.left}
                        type="number"
                        sx={{ width: "70px", mt: 1 }}
                          onChange={(e) => adjustWidthKeepingRightStatic("left", e)}
                        InputProps={{
                          sx: {
                            height: "30px",
                            "& .MuiInputBase-input": {
                              padding: "5px", // Adjust padding as needed
                            },
                          },
                        }}
                      />
                    </Box>
                  </Grid>
                  <Grid item xs={6}>
                    <Box>
                      <Typography
                        component="span"
                        sx={{
                          fontSize: 14,
                          display: "block", // Forces the text to occupy a whole line
                        }}
                      >
                        Right
                      </Typography>
                      <TextField
                        size="small"
                        variant="outlined"
                        value={sides.right}
                        sx={{ width: "70px", mt: 1 }} // Add margin-top for spacing if needed
                          onChange={(e) => adjustWidthKeepingLeftStatic("right", e)}
                        type="number"
                        InputProps={{
                          sx: {
                            height: "30px",
                            "& .MuiInputBase-input": {
                              padding: "5px", // Adjust padding as needed
                            },
                          },
                        }}
                      />
                    </Box>
                  </Grid>
                </Grid>
              </Grid>
            </Grid>
          </Box>
        </>
      )}
    </Box>
  );
};

export default OcrGeneralSettings;
