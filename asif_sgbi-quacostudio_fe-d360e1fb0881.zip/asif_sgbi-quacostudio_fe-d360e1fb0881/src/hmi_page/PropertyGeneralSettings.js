import { Box, Button, IconButton, Typography } from "@mui/material";
import React, { useEffect, useState } from "react";
import ArrowCircleDown from "../assest/icons/arrow-right-circle.svg";
import ArrowCircleRight from "../assest/icons/arrow-circle.svg";
import { alpha, styled } from "@mui/material/styles";
import InputBase from "@mui/material/InputBase";
import InputLabel from "@mui/material/InputLabel";
import FormControl from "@mui/material/FormControl";
import { useDispatch, useSelector } from "react-redux";
import { setParams, updateDutButton } from "../components/store/dutButtonSlice";
import {
  setParamsSCreen,
  updateDutScreen,
} from "../components/store/dutScreenSlice";
import {
  disableAllAndEnableFeature,
  enableVideoFeedCanvas,
} from "../components/store/videoFeedSlice";
import {
  disableAllAndEnableOption,
  setFeatureExpand,
} from "../components/store/hmiOptionsSlice";
import AutorenewIcon from "@mui/icons-material/Autorenew";
import Cookies from "js-cookie";
import ConfirmationDialog from "../components/modals/SaveConfirmationModal";
import PriorityHighIcon from "@mui/icons-material/PriorityHigh";
import { keyframes } from "@emotion/react";

// Define keyframes for the jumping animation
const shakeHeadAnimation = keyframes`
  0%, 10%, 90%, 100% {
    opacity: 1;
    transform: rotate(0deg);
  }
  25% {
    transform: rotate(-5deg);
  }
  50% {
    transform: rotate(5deg);
  }
  75% {
    transform: rotate(-5deg);
  }
  40%, 60% {
    opacity: 0; /* Disappear */
  }
`;
const blinkBorder = keyframes`
  0%, 100% {
    border-color: #8CC9FF;
  }
  50% {
    border-color: #8CC9FF; /* Brighter red */
  }
`;
const blinkPlaceholder = keyframes`
  0%, 100% {
    opacity: 1;
  }
  50% {
    opacity: 0;
  }
`;
const BootstrapInput = styled(InputBase)(({ theme }) => ({
  "label + &": {
    marginTop: theme.spacing(3),
  },
  "& .MuiInputBase-input": {
    borderRadius: 1,
    position: "relative",
    backgroundColor: theme.palette.mode === "light" ? "#F3F6F9" : "#1A2027",
    border: "1px solid",
    borderColor: theme.palette.mode === "light" ? "#E0E3E7" : "#2D3843",
    fontSize: 16,
    //   width: 'auto',
    height:20,
    width: "100%",
    padding: "10px 12px",
    transition: theme.transitions.create([
      "border-color",
      "background-color",
      "box-shadow",
    ]),
    // Use the system font instead of the default Roboto font.
    fontFamily: [
      "-apple-system",
      "BlinkMacSystemFont",
      '"Segoe UI"',
      "Roboto",
      '"Helvetica Neue"',
      "Arial",
      "sans-serif",
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',
    ].join(","),
    "&:focus": {
      boxShadow: `${alpha(theme.palette.primary.main, 0.25)} 0 0 0 0.2rem`,
      borderColor: theme.palette.primary.main,
    },
  },
}));

const GeneralSettings = () => {
  const dispatch = useDispatch();
  const [openDialog, setOpenDialog] = useState(false);
  const [pendingAction, setPendingAction] = useState(null);
  const feature = useSelector((state) => state.page); // fetch feature value from redux state
  const { name, id, buttons, screens } = useSelector((state) =>
    feature.buttons ? state.dutButtons : state.dutScreen
  ); // fetch name from redux slice based on the featuer
  const { propertiesGeneral } = useSelector((state) => state.hmiOptionsSlice);
  const [nameError, setNameError] = useState(false);
  const dutId = Cookies.get("dutId");

  const handleExpandClick = () => {
    dispatch(
      setFeatureExpand({
        feature: "propertiesGeneral",
        value: !propertiesGeneral,
      })
    );
  };
  // handle change function for update name in the state
  const handleChange = (e) => {
    if (feature.buttons) {
      dispatch(setParams({ name: e.target.value }));
      // Enable button drawing if the name length is greaterthan 2
      if (!id && name && name.length >= 2) {
        dispatch(disableAllAndEnableFeature("buttonDrawEnabled"));
      }
    } else if (feature.screens) {
      dispatch(setParamsSCreen({ name: e.target.value }));
      // Enable screen  drawing if the name length is greaterthan 2
      if (!id && name && name.length >= 2) {
        dispatch(disableAllAndEnableFeature("buttonDrawEnabled"));
      }
    }
  };
  // const updategeneralSettings = () => {
  //   const document = buttons.find((doc) => doc.id === id);
  //   if(document.button_name === name){
  //       return
  //   }
  //   const userConfirmed = window.confirm("do you want to save changes");
  //   if(userConfirmed){
  //   if (feature.buttons) {
  //     const buttonData = {
  //       button_name: name,
  //       dut_id: dutId,
  //     };
  //     dispatch(updateDutButton({ id: id, dutButtonData: buttonData }));
  //   } else if (feature.screens) {
  //     const screenData = {
  //       screen_name: name,
  //       dut_id: dutId,
  //     };
  //     dispatch(updateDutScreen({ id: id, dutScreenData: screenData }));
  //   }
  // }else{
  //   if(feature.buttons){
  //     dispatch(setParams({ name: document.button_name}));
  //   }else if(feature.screens){
  //     dispatch(setParamsSCreen({ name:document.screen_name }));
  //   }
  // }
  // };

  const updategeneralSettings = () => {
    const document = "";
    if (feature.buttons) {
      document = buttons.find((doc) => doc.id === id);
    } else if (feature.screen) {
      document = screens.find((doc) => doc.id === id);
    }

    // if () {
    //   return;
    // }
    // if(feature.buttons && !id || document.button_name === name){

    // }
    setPendingAction(() => {
      if (feature.buttons) {
        const buttonData = {
          button_name: name,
          dut_id: dutId,
        };
        return () =>
          dispatch(updateDutButton({ id: id, dutButtonData: buttonData }));
      } else if (feature.screens) {
        const screenData = {
          screen_name: name,
          dut_id: dutId,
        };
        return () =>
          dispatch(updateDutScreen({ id: id, dutScreenData: screenData }));
      }
    });
    setOpenDialog(true);
  };

  const handleConfirm = () => {
    if (pendingAction) {
      pendingAction();
    }
    setOpenDialog(false);
  };

  const handleCancel = () => {
    const document =  ""
    if (feature.buttons) {
      document =  buttons.find((doc) => doc.id === id);
      dispatch(setParams({ name: document.button_name }));
    } else if (feature.screens) {
      document =  buttons.find((doc) => doc.id === id);
      dispatch(setParamsSCreen({ name: document.screen_name }));
    }
    setOpenDialog(false);
  };
  useEffect(() => {
    dispatch(
      setFeatureExpand({
        feature: "propertiesGeneral",
        value: true,
      })
    );
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      if (name.trim() === "") {
        setNameError(true);
      } else {
        setNameError(false);
      }
    }, 2000); // Check every 2 seconds

    // Cleanup the interval on component unmount
    return () => clearInterval(interval);
  }, [name]);
  return (
    <Box
      sx={{
        border: "1px solid #DFE3EB",
        boxShadow:
          "rgba(9, 30, 66, 0.25) 0px 4px 8px -2px, rgba(9, 30, 66, 0.08) 0px 0px 0px 1px",
        m: 1,
        borderRadius: 2,
        "&:hover": {
          borderColor: "#33BFFF", // Change border color on hover
        },
      }}
    >
      <Box display="flex" alignItems="center" justifyContent="space-between">
        <IconButton
          sx={{ "&:hover": { bgcolor: "transparent" } }}
          onClick={(e) => handleExpandClick()}
        >
          <img
            src={propertiesGeneral ? ArrowCircleDown : ArrowCircleRight}
            alt="toggle icon"
            style={{ width: "24px", height: "24px" }}
          />
          <Typography sx={{ ml: 1 }}>General</Typography>
        </IconButton>
        {id && (
          <IconButton onClick={updategeneralSettings}>
            {propertiesGeneral && <AutorenewIcon />}
          </IconButton>
        )}
      </Box>
      {propertiesGeneral && (
        <Box
          sx={{ flexDirection: "column", p: 1 }}
          // onMouseLeave={updategeneralSettings}
        >
          <FormControl variant="standard" sx={{ width: "100%" }}>
            <InputLabel shrink={true} htmlFor="bootstrap-input">
              Name
            </InputLabel>
            <BootstrapInput
              value={name}
              id="bootstrap-input"
              autoComplete="off"
              placeholder="Enter name "
              onChange={(e) => handleChange(e)}
              sx={{
                borderRadius: 1,
                border: nameError
                  ? "1px solid #8CC9FF"
                  : "1px solid rgba(0, 0, 0, 0.42)",
                animation: nameError
                  ? `${blinkBorder} 1s ease-in-out infinite`
                  : "none", // Apply blinking animation if there's an error
                "&:hover": {
                  border: nameError
                    ? "1px solid red"
                    : "1px solid rgba(0, 0, 0, 0.87)",
                },
                "&:focus-within": {
                  border: nameError
                    ? "1px solid red"
                    : "1px solid rgba(0, 0, 0, 0.87)",
                  animation: nameError
                    ? `${blinkBorder} 1s ease-in-out infinite`
                    : "none", // Blinking on focus if there's an error
                },
                "&::placeholder": {
                  color: nameError ? "red" : "rgba(0, 0, 0, 0.42)", // Change color if there's an error
                  animation: nameError
                    ? `${blinkPlaceholder} 1.5s ease-in-out infinite`
                    : "none", // Blinking placeholder when there's an error
                },
              }}
            />
            {/* {nameError && (
              <PriorityHighIcon
                sx={{
                  position: "absolute",
                  right: "10px",
                  top: "50%",
                  fontSize: 14,
                  transform: "translateY(-50%)",
                  color: "#ffd36b ",
                  animation: `${shakeHeadAnimation} 0.8s ease-in-out infinite`,
                  fontSize: "20px",
                }}
              />
            )} */}
          </FormControl>
        </Box>
      )}
      <ConfirmationDialog
        open={openDialog}
        title="Confirm Changes"
        message="Do you want to save changes?"
        onConfirm={handleConfirm}
        onCancel={handleCancel}
      />
    </Box>
  );
};

export default GeneralSettings;
