import React, { useEffect, useState } from "react";
import {
  Box,
  Button,
  IconButton,
  Typography,
  Grid,
  TextField,
  Checkbox,
  FormControlLabel,
  Menu,
  MenuItem,
  createTheme,
} from "@mui/material";
import ArrowCircleDown from "../assest/icons/arrow-right-circle.svg";
import ArrowCircleRight from "../assest/icons/arrow-circle.svg";
import { alpha, styled } from "@mui/material/styles";
import InputBase from "@mui/material/InputBase";
import InputLabel from "@mui/material/InputLabel";
import FormControl from "@mui/material/FormControl";
import { useDispatch, useSelector } from "react-redux";
import deleteIcon from "../assest/icons/delete-icon.svg";
import { setFeature } from "../components/store/pageSlice";
import {
  clearElementState,
  createScreenElement,
  deleteScreenElement,
  setElementParams,
  setSelectedElement,
  updateScreenElement,
} from "../components/store/dutElementSlice";
import demiCrop from "../assest/images/694979.png";
import editIcon from "../assest/icons/edit-icon.svg";
import DeleteConfirmationModal from "../components/modals/DeleteConfirmationModal";
import setElementDetails from "../utils/setElementDetails";
import ConfirmationDialog from "../components/modals/SaveConfirmationModal";
import { areDocumentsDifferent } from "../utils/funcs";
const theme = createTheme({
  breakpoints: {
    values: {
      xs: 0,
      sm: 600, // You can change this value to your desired breakpoint
      md: 900, // You can change this value to your desired breakpoint
      lg: 1200,
      xl: 1600,
    },
  },
});
const BootstrapInput = styled(InputBase)(({ theme }) => ({
  "label + &": {
    marginTop: theme.spacing(3),
  },
  "& .MuiInputBase-input": {
    borderRadius: 4,
    position: "relative",
    backgroundColor: theme.palette.mode === "light" ? "#F3F6F9" : "#1A2027",
    border: "1px solid",
    borderColor: theme.palette.mode === "light" ? "#E0E3E7" : "#2D3843",
    fontSize: 16,
    width: "100%",
    mb: 1,
    padding: "10px 12px",
    transition: theme.transitions.create([
      "border-color",
      "background-color",
      "box-shadow",
    ]),
    fontFamily: [
      "-apple-system",
      "BlinkMacSystemFont",
      '"Segoe UI"',
      "Roboto",
      '"Helvetica Neue"',
      "Arial",
      "sans-serif",
      '"Apple Color Emoji"',
      '"Segoe UI Emoji"',
      '"Segoe UI Symbol"',
    ].join(","),
    "&:focus": {
      boxShadow: `${alpha(theme.palette.primary.main, 0.25)} 0 0 0 0.2rem`,
      borderColor: theme.palette.primary.main,
    },
  },
}));

const menusx = {
  width: 120,
  "&:hover": {
    borderRadius: 3,
    // background:"linear-.(90deg, rgba(11,139,217,1) 0%, rgba(46,114,195,1) 72%, rgba(65,101,240,1) 99%)",
    bgcolor: "#3391FF",
  },
};

const ScreenElements = ({ item, index }) => {
  const dispatch = useDispatch();
  const [openDeleteConfirmation, setOpenDeleteConfirmation] = useState(false);
  const [anchorEl, setAnchorEl] = useState(false);
  const [open, setOpen] = useState(false);
  const {
    elemUrl,
    sX,
    sY,
    sW,
    sH,
    id,
    name,
    selectedElement,
    isDrawingElement,
  } = useSelector((state) => state.screenelements);
  const screenId = useSelector((state) => state.dutScreen.id);
  const [sides, setSides] = useState({ top: 0, left: 0, bottom: 0, right: 0 });
  const [expand, setExpanded] = useState(false);
  const [elementId, setElementId] = useState(null);

  const handleExpandClick = () => {
    // onExpand(id); // Notify parent to expand this item
    const values = setElementDetails(item);
    dispatch(setSelectedElement(item.id));
    dispatch(setElementParams(values));
  };

  const handleChange = (e) => {
    dispatch(setElementParams({ name: e.target.value }));
  };

  const onCancel = () => {
    setOpen(false);
    const values = setElementDetails(item);
    dispatch(setElementParams(values));
  };
  const onConfirm = () => {
    const elementData = {
      element_name: name,
      element_roi: `${sX}:${sY}:${sW}:${sH}`,
      light: false,
      element_image: elemUrl.split(",")[1],
      screen_id: parseInt(screenId),
    };
    dispatch(
      updateScreenElement({ id: selectedElement, elementData: elementData })
    );
    setOpen(false);
  };

  const handleUpdateElements = () => {
    const elementData = {
      element_name: name,
      element_roi: `${sX}:${sY}:${sW}:${sH}`,
      light: false,
      element_image: elemUrl.split(",")[1],
      screen_id: parseInt(screenId),
    };
    for (let key in elementData) {
      if (elementData[key] !== item[key]) {
        setOpen(true);
        return;
      }
    }

    return true;
  };

  const adjustWidthKeepingLeftStatic = (name, e) => {
    const newValue = parseInt(e.target.value, 10); // New input value
    const prevValue = sides[name]; // Current value from state

    // Calculate the difference
    const difference = newValue - prevValue;

    // Calculate the new width
    const newWidth = sW + difference;

    // Update the sides state
    setSides((prev) => ({
      ...prev,
      [name]: newValue,
    }));

    // Ensure new width is positive
    if (newWidth >= 0) {
      dispatch(setElementParams({ sW: newWidth }));
    }
  };

  const adjustWidthKeepingRightStatic = (name, e) => {
    const newValue = parseInt(e.target.value, 10); // New value from input
    const prevValue = sides[name]; // Current value from state

    // Calculate the difference
    const difference = newValue - prevValue;

    // Calculate the new width
    const newWidth = sW + difference;

    // Calculate the new startX to keep the right edge static
    const newStartX = sX - difference;

    // Update the sides state
    setSides((prev) => ({
      ...prev,
      [name]: newValue,
    }));

    // Ensure new width and startX are positive
    if (newWidth >= 0 && newStartX >= 0) {
      dispatch(setElementParams({ sW: newWidth, sX: newStartX }));
    }
  };
  const adjustTopKeepingBottomStatic = (name, e) => {
    const newValue = parseInt(e.target.value, 10); // New value from input
    const prevValue = sides[name]; // Current value from state

    // Calculate the difference
    const difference = newValue - prevValue;

    // Calculate the new height
    const newHeight = sH - difference;

    // Update the top edge
    const newStartY = sY + difference;

    // Update the sides state
    setSides((prev) => ({
      ...prev,
      [name]: newValue,
    }));

    // Ensure new height and startY are positive
    if (newHeight >= 0 && newStartY >= 0) {
      dispatch(setElementParams({ sY: newStartY, sH: newHeight }));
    }
  };

  const adjustBottomKeepingTopStatic = (name, e) => {
    const newValue = parseInt(e.target.value, 10); // New value from input
    const prevValue = sides[name]; // Current value from state

    // Calculate the difference
    const difference = newValue - prevValue;

    // Calculate the new height
    const newHeight = sH + difference;

    // Update the bottom edge
    const newStartY = sY;

    // Update the sides state
    setSides((prev) => ({
      ...prev,
      [name]: newValue,
    }));

    // Ensure new height is positive
    if (newHeight >= 0) {
      dispatch(setElementParams({ sH: newHeight }));
    }
  };

  const handleRightClick = (event, item) => {
    setAnchorEl(event.currentTarget);
    // setElementId(item.id);
  };
  const handleClose = () => {
    setAnchorEl(false);
  };
  const handleDelete = () => {
    dispatch(deleteScreenElement(item.id));
    setOpenDeleteConfirmation(false);
  };
  const handleClickDelete = () => {
    setOpenDeleteConfirmation(true);
    // handleClose()
  };

  const handledrawEnable = () => {
    dispatch(setElementParams({ isDrawingElement: true }));
  };
  const rightClickMenu = () => {
    return (
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)} // Opens the submenu on click
        onClose={handleClose}
        sx={{ width: 350 }}
        PaperProps={{
          sx: {
            pl: 1,
            pr: 1,
            border: "1px solid #3391FF",
            borderRadius: 2,
          },
        }}
        anchorOrigin={{
          vertical: "top",
          horizontal: "right", // Aligns the submenu to the right side of the main menu
        }}
        transformOrigin={{
          vertical: "top",
          horizontal: "left", // Ensures the submenu opens to the right
        }}
      >
        <MenuItem sx={menusx} name="move" onClick={(e) => handleClickDelete()}>
          {""}
          <img
            src={deleteIcon}
            alt="indicator icon"
            style={{
              width: "20px",
              height: "20px",
              textTransform: "none",
              marginRight: "5px",
            }}
          />
          Delete
        </MenuItem>
      </Menu>
    );
  };
  return (
    <Box
      sx={{
        border: "1px solid #DFE3EB",
        boxShadow:
          "rgba(9, 30, 66, 0.25) 0px 4px 8px -2px, rgba(9, 30, 66, 0.08) 0px 0px 0px 1px",
        m: 1,
        borderRadius: 2,
        "&:hover": {
          borderColor: "#33BFFF", // Change border color on hover
        },
      }}
      onContextMenu={(e) => {
        e.preventDefault(); // Prevent default right-click menu
        handleRightClick(e); // Custom function to handle the right-click event
      }}
    >
      <Box>
        <IconButton
          sx={{ "&:hover": { bgcolor: "transparent" } }}
          onClick={handleExpandClick}
        >
          <img
            src={
              selectedElement === item.id ? ArrowCircleDown : ArrowCircleRight
            }
            alt="toggle icon"
            style={{ width: "24px", height: "24px" }}
          />
          <Typography sx={{ ml: 1 }}>
            {index + 1} {item.element_name}
          </Typography>
        </IconButton>
      </Box>
      {selectedElement === item.id && (
        <Box
          sx={{ flexDirection: "column", p: 1 }}
          onMouseLeave={() => {
            handleUpdateElements();
          }}
        >
          <FormControl variant="standard" sx={{ width: "100%" }}>
            <InputLabel
              shrink
              htmlFor="bootstrap-input"
              sx={{
                top: "0",
                fontSize: "1rem",
                backgroundColor: "#E9F3FC",
                padding: "0 4px",
                color: "#7f8c8d", // Lighten the label color
              }}
            >
              Name
            </InputLabel>
            <Box sx={{ display: "flex", alignItems: "center", width: "100%" }}>
              <BootstrapInput
                id="bootstrap-input"
                autoComplete="off"
                onChange={handleChange}
                value={name}
                sx={{
                  flex: 1,
                  backgroundColor: "#E9F3FC",
                  borderRadius: 2,
                  "& .MuiInputBase-input": {
                    borderRadius: 2,
                    backgroundColor: "#E9F3FC",
                    padding: "10px",
                  },
                  "& .MuiInputBase-root": {
                    borderRadius: 2,
                  },
                }}
              />
              {/* Add Checkbox next to the input */}
              <FormControlLabel
                control={
                  <Checkbox
                    // checked={isChecked} // Add your state logic here
                    // onChange={handleCheckboxChange} // Add your handler here
                    sx={{ ml: 2 }} // Add margin to the left for spacing
                  />
                }
                label="Light"
                sx={{
                  ml: 1, // Adjust spacing between the checkbox and label
                  color: "#7f8c8d", // Lighten label color for 'Light'
                }}
              />
            </Box>
            {/* Error message can be displayed here if needed */}
          </FormControl>

          <Grid container spacing={2}>
            <Grid item xs={5}>
              <Box
                sx={{
                  position: "relative",
                  borderRadius: 2,
                  height: "100%",
                  width: "100%",
                  mt: 2,
                  maxHeight: { xs: 100, md: 100 },
                }}
              >
                <Box
                  component="img"
                  sx={{
                    borderRadius: 2,
                    height: "100%",
                    width: "100%",
                    maxHeight: { xs: 100, md: 100 },
                    objectFit: "cover",
                  }}
                  alt="Small Image"
                  src={elemUrl ? elemUrl : demiCrop}
                />
                {!isDrawingElement && (
                  <IconButton
                    sx={{
                      position: "absolute",
                      p: 0.5,
                      bottom: 0,
                      right: 0,
                      color: "white",
                      backgroundColor: "#33BFFF",
                      borderRadius: 2,
                      "&:hover": {
                        backgroundColor: "rgba(0, 0, 0, 0.7)",
                      },
                    }}
                    onClick={handledrawEnable}
                  >
                    <img
                      src={editIcon}
                      alt="arrow up"
                      style={{ width: "20px", height: "20px" }}
                    />
                  </IconButton>
                )}
              </Box>
            </Grid>
            <Grid item xs={7}>
              <Box
                sx={{
                  display: "flex",
                  justifyContent: "center", // Horizontal alignment
                  alignItems: "center", // Vertical alignment
                  height: "100%", // Ensures the content takes full height of the Grid
                }}
              >
                <Grid container spacing={1}>
                  <Grid item xs={6}>
                    <Typography> Top</Typography>
                    <TextField
                      size="small"
                      variant="outlined"
                      type="number"
                      sx={{ width: "100%" }}
                      value={sides.top}
                      onChange={(e) => adjustTopKeepingBottomStatic("top", e)}
                      InputProps={{
                        sx: {
                          height: "35px",

                          "& .MuiInputBase-input": {
                            padding: "0px",
                          },
                          // Change the size of the number input arrows
                          "& input[type=number]": {
                            "&::-webkit-inner-spin-button, &::-webkit-outer-spin-button":
                              {
                                width: "35px", // Set custom width for arrows
                                height: "35px", // Set custom height for arrows
                                ml: 1,
                              },
                            // For Firefox
                            "&::-moz-inner-spin-button, &::-moz-outer-spin-button":
                              {
                                width: "25px",
                                height: "12px",
                              },
                          },
                        },
                      }}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <Typography> Bottom</Typography>
                    <TextField
                      size="small"
                      variant="outlined"
                      type="number"
                      sx={{ width: "100%" }}
                      value={sides.bottom}
                      onChange={(e) =>
                        adjustBottomKeepingTopStatic("bottom", e)
                      }
                      InputProps={{
                        sx: {
                          height: "35px",

                          "& .MuiInputBase-input": {
                            padding: "0px",
                          },
                          // Change the size of the number input arrows
                          "& input[type=number]": {
                            "&::-webkit-inner-spin-button, &::-webkit-outer-spin-button":
                              {
                                width: "35px", // Set custom width for arrows
                                height: "35px", // Set custom height for arrows
                                ml: 1,
                              },
                            // For Firefox
                            "&::-moz-inner-spin-button, &::-moz-outer-spin-button":
                              {
                                width: "25px",
                                height: "12px",
                              },
                          },
                        },
                      }}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <Typography> Left</Typography>
                    <TextField
                      size="small"
                      variant="outlined"
                      type="number"
                      sx={{ width: "100%" }}
                      value={sides.left}
                      onChange={(e) => adjustWidthKeepingRightStatic("left", e)}
                      InputProps={{
                        sx: {
                          height: "35px",

                          "& .MuiInputBase-input": {
                            padding: "0px",
                          },
                          // Change the size of the number input arrows
                          "& input[type=number]": {
                            "&::-webkit-inner-spin-button, &::-webkit-outer-spin-button":
                              {
                                width: "35px", // Set custom width for arrows
                                height: "35px", // Set custom height for arrows
                                ml: 1,
                              },
                            // For Firefox
                            "&::-moz-inner-spin-button, &::-moz-outer-spin-button":
                              {
                                width: "25px",
                                height: "12px",
                              },
                          },
                        },
                      }}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    <Typography>Right</Typography>
                    <TextField
                      size="small"
                      variant="outlined"
                      type="number"
                      sx={{ width: "100%" }}
                      value={sides.right}
                      onChange={(e) => adjustWidthKeepingLeftStatic("right", e)}
                      InputProps={{
                        sx: {
                          height: "35px",

                          "& .MuiInputBase-input": {
                            padding: "0px",
                          },
                          // Change the size of the number input arrows
                          "& input[type=number]": {
                            "&::-webkit-inner-spin-button, &::-webkit-outer-spin-button":
                              {
                                width: "35px", // Set custom width for arrows
                                height: "35px", // Set custom height for arrows
                                ml: 1,
                              },
                            // For Firefox
                            "&::-moz-inner-spin-button, &::-moz-outer-spin-button":
                              {
                                width: "25px",
                                height: "12px",
                              },
                          },
                        },
                      }}
                    />
                  </Grid>
                </Grid>
              </Box>
            </Grid>
          </Grid>
        </Box>
      )}
      {rightClickMenu()}
      <DeleteConfirmationModal
        openDeleteConfirmation={openDeleteConfirmation}
        setOpenDeleteConfirmation={setOpenDeleteConfirmation}
        handleDelete={handleDelete}
      />
      <ConfirmationDialog
        onCancel={onCancel}
        onConfirm={onConfirm}
        open={open}
        message={"Are you sure to save changes"}
        title={"Update Confirmation"}
      />
    </Box>
  );
};

export const AddScreenElements = () => {
  const dispatch = useDispatch();

  const {
    elemUrl,
    sX,
    sY,
    sW,
    sH,
    id,
    name,
    selectedElement,
    addElement,
    isDrawingElement,
    screenelements,
  } = useSelector((state) => state.screenelements);
  const screenId = useSelector((state) => state.dutScreen.id);
  const [sides, setSides] = useState({ top: 0, left: 0, bottom: 0, right: 0 });
  const [expand, setExpanded] = useState(true);

  const handleExpandClick = () => {
    // onExpand(id); // Notify parent to expand this item
    setExpanded(!expand);
    // dispatch(setSelectedElement(null));
  };

  const handleChange = (e) => {
    dispatch(setElementParams({ name: e.target.value }));
    if (e.target.value.length > 2 && !id) {
      dispatch(setElementParams({ isDrawingElement: true }));
    }
  };

  const handleCreateElements = () => {
    const elementData = {
      element_name: name,
      element_roi: `${sX}:${sY}:${sW}:${sH}`,
      light: false,
      element_image: elemUrl.split(",")[1],
      screen_id: parseInt(screenId),
    };
    dispatch(createScreenElement(elementData));
  };

  const handleUpdateElements = () => {
    if (!id) {
      return;
    }
    
    const document = screenelements.find(doc => doc.id === id);
    const elementData = {
      element_name: name,
      element_roi: `${sX}:${sY}:${sW}:${sH}`,
      light: false,
      element_image: elemUrl.split(",")[1],
      screen_id: parseInt(screenId),
    };
     const isDifferent = areDocumentsDifferent(document , elementData)
     console.log(isDifferent ,"isDiff")
    if (id && isDifferent) {
      dispatch(updateScreenElement({ id: id, elementData: elementData }));
    }
  };

  useEffect(() => {
    if (addElement && elemUrl && name && !selectedElement && !id) {
      handleCreateElements();
      dispatch(setElementParams({ updateElement: true }));
      dispatch(setElementParams({ addElement: false }));
    }
  }, [elemUrl, name]);

  const adjustWidthKeepingLeftStatic = (name, e) => {
    const newValue = parseInt(e.target.value, 10); // New input value
    const prevValue = sides[name]; // Current value from state

    // Calculate the difference
    const difference = newValue - prevValue;

    // Calculate the new width
    const newWidth = sW + difference;

    // Update the sides state
    setSides((prev) => ({
      ...prev,
      [name]: newValue,
    }));

    // Ensure new width is positive
    if (newWidth >= 0) {
      dispatch(setElementParams({ sW: newWidth }));
    }
  };

  const adjustWidthKeepingRightStatic = (name, e) => {
    const newValue = parseInt(e.target.value, 10); // New value from input
    const prevValue = sides[name]; // Current value from state

    // Calculate the difference
    const difference = newValue - prevValue;

    // Calculate the new width
    const newWidth = sW + difference;

    // Calculate the new startX to keep the right edge static
    const newStartX = sX - difference;

    // Update the sides state
    setSides((prev) => ({
      ...prev,
      [name]: newValue,
    }));

    // Ensure new width and startX are positive
    if (newWidth >= 0 && newStartX >= 0) {
      dispatch(setElementParams({ sW: newWidth, sX: newStartX }));
    }
  };
  const adjustTopKeepingBottomStatic = (name, e) => {
    const newValue = parseInt(e.target.value, 10); // New value from input
    const prevValue = sides[name]; // Current value from state

    // Calculate the difference
    const difference = newValue - prevValue;

    // Calculate the new height
    const newHeight = sH - difference;

    // Update the top edge
    const newStartY = sY + difference;

    // Update the sides state
    setSides((prev) => ({
      ...prev,
      [name]: newValue,
    }));

    // Ensure new height and startY are positive
    if (newHeight >= 0 && newStartY >= 0) {
      dispatch(setElementParams({ sY: newStartY, sH: newHeight }));
    }
  };

  const adjustBottomKeepingTopStatic = (name, e) => {
    const newValue = parseInt(e.target.value, 10); // New value from input
    const prevValue = sides[name]; // Current value from state

    // Calculate the difference
    const difference = newValue - prevValue;

    // Calculate the new height
    const newHeight = sH + difference;

    // Update the bottom edge
    const newStartY = sY;

    // Update the sides state
    setSides((prev) => ({
      ...prev,
      [name]: newValue,
    }));

    // Ensure new height is positive
    if (newHeight >= 0) {
      dispatch(setElementParams({ sH: newHeight }));
    }
  };
  const handleRedraw = () => {
    dispatch(setElementParams({ isDrawingElement: true }));
    dispatch(setFeature({ feature: "ocr", value: true }));
  };
  return (
    <Box
      sx={{
        border: "1px solid #DFE3EB",
        boxShadow:
          "rgba(9, 30, 66, 0.25) 0px 4px 8px -2px, rgba(9, 30, 66, 0.08) 0px 0px 0px 1px",
        m: 1,
        borderRadius: 2,
        "&:hover": {
          borderColor: "#33BFFF", // Change border color on hover
        },
      }}
    >
      <Box>
        <IconButton
          sx={{ "&:hover": { bgcolor: "transparent" } }}
          onClick={handleExpandClick}
        >
          <img
            src={expand ? ArrowCircleDown : ArrowCircleRight}
            alt="toggle icon"
            style={{ width: "24px", height: "24px" }}
          />
          <Typography sx={{ ml: 1 }}>Add Element</Typography>
        </IconButton>
      </Box>
      {expand && (
        <Box
          sx={{ flexDirection: "column", p: 1 }}
          onMouseLeave={handleUpdateElements}
        >
          <FormControl variant="standard" sx={{ width: "100%" }}>
            <InputLabel
              shrink
              htmlFor="bootstrap-input"
              sx={{
                top: "0",
                fontSize: "1rem",
                backgroundColor: "#E9F3FC",
                padding: "0 4px",
                color: "#7f8c8d", // Lighten the label color
              }}
            >
              Name
            </InputLabel>
            <Box sx={{ display: "flex", alignItems: "center", width: "100%" }}>
              <BootstrapInput
                id="bootstrap-input"
                autoComplete="off"
                onChange={handleChange}
                placeholder="Enter Name"
                value={name}
                sx={{
                  flex: 1,
                  backgroundColor: "#E9F3FC",
                  borderRadius: 2,
                  "& .MuiInputBase-input": {
                    borderRadius: 2,
                    backgroundColor: "#E9F3FC",
                    padding: "10px",
                  },
                  "& .MuiInputBase-root": {
                    borderRadius: 2,
                  },
                }}
              />
              {/* Add Checkbox next to the input */}
              <FormControlLabel
                control={
                  <Checkbox
                    // checked={isChecked} // Add your state logic here
                    // onChange={handleCheckboxChange} // Add your handler here
                    sx={{ ml: 1 }} // Add margin to the left for spacing
                  />
                }
                label="Light"
                sx={{
                  ml: 1, // Adjust spacing between the checkbox and label
                  color: "#7f8c8d", // Lighten label color for 'Light'
                }}
              />
            </Box>
            {/* Error message can be displayed here if needed */}
          </FormControl>

          <Grid container spacing={2}>
            <Grid item xs={5}>
              <Box
                sx={{
                  position: "relative",
                  borderRadius: 2,
                  height: "100%",
                  width: "100%",
                  mt: 2,
                  maxHeight: { xs: 100, md: 100 ,xl:150},
                }}
              >
                <Box
                  component="img"
                  sx={{
                    borderRadius: 2,
                    height: "100%",
                    width: "100%",
                    maxHeight: { xs: 100, md: 100 ,xl:150 },
                    objectFit: "contain",
                    bgcolor:"#CCCCCc"
                  }}
                  alt="Small Image"
                  src={elemUrl ? elemUrl : demiCrop}
                />
                {!isDrawingElement && (
                  <IconButton
                    onClick={handleRedraw}
                    sx={{
                      position: "absolute",
                      p: 0.5,
                      bottom: 0,
                      right: 0,
                      color: "white",
                      backgroundColor: "#33BFFF",
                      borderRadius: 2,
                      "&:hover": {
                        backgroundColor: "rgba(0, 0, 0, 0.7)",
                      },
                    }}
                  >
                    <img
                      src={editIcon}
                      alt="arrow up"
                      style={{ width: "20px", height: "20px" }}
                    />
                  </IconButton>
                )}
              </Box>
            </Grid>
            <Grid item xs={7}>
              <Box
                sx={{
                  display: "flex", // Enables Flexbox
                  alignItems: "center", // Vertically centers children
                  justifyContent: "center", // Horizontally centers children
                  height: "100%", // Ensures the Box takes full height of the parent
                  width: "100%", // Ensures the Box takes full width of the parent
                }}
              >
                <Grid container spacing={1}>
                  <Grid item xs={6}>
                    Top
                    <TextField
                      size="small"
                      variant="outlined"
                      type="number"
                      sx={{ width: "100%" }}
                      value={sides.top}
                      onChange={(e) => adjustTopKeepingBottomStatic("top", e)}
                      InputProps={{
                        sx: {
                          height: "35px",

                          "& .MuiInputBase-input": {
                            padding: "0px",
                          },
                          // Change the size of the number input arrows
                          "& input[type=number]": {
                            "&::-webkit-inner-spin-button, &::-webkit-outer-spin-button":
                              {
                                width: "35px", // Set custom width for arrows
                                height: "35px", // Set custom height for arrows
                                ml: 1,
                              },
                            // For Firefox
                            "&::-moz-inner-spin-button, &::-moz-outer-spin-button":
                              {
                                width: "25px",
                                height: "12px",
                              },
                          },
                        },
                      }}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    Bottom
                    <TextField
                      size="small"
                      variant="outlined"
                      type="number"
                      sx={{ width: "100%" }}
                      value={sides.bottom}
                      onChange={(e) =>
                        adjustBottomKeepingTopStatic("bottom", e)
                      }
                      InputProps={{
                        sx: {
                          height: "35px",

                          "& .MuiInputBase-input": {
                            padding: "0px",
                          },
                          // Change the size of the number input arrows
                          "& input[type=number]": {
                            "&::-webkit-inner-spin-button, &::-webkit-outer-spin-button":
                              {
                                width: "35px", // Set custom width for arrows
                                height: "35px", // Set custom height for arrows
                                ml: 1,
                              },
                            // For Firefox
                            "&::-moz-inner-spin-button, &::-moz-outer-spin-button":
                              {
                                width: "25px",
                                height: "12px",
                              },
                          },
                        },
                      }}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    Left
                    <TextField
                      size="small"
                      variant="outlined"
                      type="number"
                      sx={{ width: "100%" }}
                      value={sides.left}
                      onChange={(e) => adjustWidthKeepingRightStatic("left", e)}
                      InputProps={{
                        sx: {
                          height: "35px",

                          "& .MuiInputBase-input": {
                            padding: "0px",
                          },
                          // Change the size of the number input arrows
                          "& input[type=number]": {
                            "&::-webkit-inner-spin-button, &::-webkit-outer-spin-button":
                              {
                                width: "35px", // Set custom width for arrows
                                height: "35px", // Set custom height for arrows
                                ml: 1,
                              },
                            // For Firefox
                            "&::-moz-inner-spin-button, &::-moz-outer-spin-button":
                              {
                                width: "25px",
                                height: "12px",
                              },
                          },
                        },
                      }}
                    />
                  </Grid>
                  <Grid item xs={6}>
                    Right
                    <TextField
                      size="small"
                      variant="outlined"
                      type="number"
                      sx={{ width: "100%" }}
                      value={sides.right}
                      onChange={(e) => adjustWidthKeepingLeftStatic("right", e)}
                      InputProps={{
                        sx: {
                          height: "35px",

                          "& .MuiInputBase-input": {
                            padding: "0px",
                          },
                          // Change the size of the number input arrows
                          "& input[type=number]": {
                            "&::-webkit-inner-spin-button, &::-webkit-outer-spin-button":
                              {
                                width: "35px", // Set custom width for arrows
                                height: "35px", // Set custom height for arrows
                                ml: 1,
                              },
                            // For Firefox
                            "&::-moz-inner-spin-button, &::-moz-outer-spin-button":
                              {
                                width: "25px",
                                height: "12px",
                              },
                          },
                        },
                      }}
                    />
                  </Grid>
                </Grid>
              </Box>
            </Grid>
          </Grid>
        </Box>
      )}
    </Box>
  );
};

const ScreenElementsListing = () => {
  const [expandedId, setExpandedId] = useState(null);
  const { screenelements } = useSelector((state) => state.screenelements);
  const [addElement, setAddElement] = useState(false);
  const dispatch = useDispatch();

  const handleAddScreen = () => {
    setAddElement(true);
    dispatch(setFeature({ feature: "elements", value: true }));
    dispatch(clearElementState());
    dispatch(setSelectedElement(null));
  };
  useEffect(() => {}, []);
  return (
    <div>
      {screenelements.map((item, index) => (
        <ScreenElements key={index} index={index} item={item} />
      ))}
      {addElement ? (
        <AddScreenElements
          addElement={addElement}
          setAddElement={setAddElement}
        />
      ) : (
        <Box sx={{ p: 1 }}>
          <Button
            variant="contained"
            sx={{
              background: "#0075FF",
              color: "white",
              textTransform: "none",
              mt: 1,
              height: 40,
              width: "100%",
              borderRadius: 2,
            }}
            onClick={handleAddScreen}
          >
            Add Element
          </Button>
        </Box>
      )}
    </div>
  );
};

export default ScreenElementsListing;
