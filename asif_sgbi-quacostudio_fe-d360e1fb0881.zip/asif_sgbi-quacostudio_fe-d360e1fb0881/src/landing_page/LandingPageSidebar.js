import { Box, Typography, IconButton, useTheme } from '@mui/material';
// import React, { useState } from 'react';
import DescriptionOutlinedIcon from '@mui/icons-material/DescriptionOutlined';
import AddCardOutlinedIcon from '@mui/icons-material/AddCardOutlined';
// import DutAddingModal from '../components/modals/DutAddingModal';
import { useDispatch,} from 'react-redux';
import { setOpenModal, setTypeModal } from '../components/store/dutModalSlice';
import { setOpenTemplate, setTypeTemplateModal } from '../components/store/templateModalSlice';
import fileiconDark from "../assest/icons/fileicondark.svg"
import fileiconLigh from "../assest/icons/fileiconlight.svg"
import { useState } from 'react';
import templateicon from "../assest/icons/templateicon.svg"
import templateiconlight from "../assest/icons/templateiconlight.svg"

const LandingPageSidebar = () => {
  const theme = useTheme();
  // const {open , setOpen } = useState(false)
  const [isHoveredDut, setIsHoveredDut] = useState(false);
  const [isHoveredTemplate, setIsHoveredTemplate] = useState(false);
  const dispatch =  useDispatch()
  // const isEdit = useSelector(state => state.dutmodal.isEdit)

  // const isEditMode = false
  const IconButtonStyles = {
    borderRadius: 3,
    padding: 2,
    background:"none",
    mb: 2,
    color:theme.palette.primary.button,
    color: "#232328",
    textAlign: "left",
    justifyContent: 'flex-start',
    border: `1px solid ${theme.palette.primary.button}`,
    '&:hover':{
      background: "linear-gradient(150deg, #33BFFF 0%, #5D5CE5 100%)",
      color:"white",
    }
  };

  const iconStyles = {
  
     };
     
  const textStyles = { 
    mt:3,
    fontFamily: "Inter",
    fontSize: "14px",
    fontStyle: "normal",
    fontWeight: 700,
    lineHeight: "16px",
 };

 const handleOpenForm =(type)=>{
  if(type === "dut"){
    dispatch(setTypeModal(false))
    dispatch(setOpenModal(true))
  }else if(type === "template"){
    dispatch(setOpenTemplate(true))
    dispatch(setTypeTemplateModal(false))
  }
 
 }
  return (
    <Box 
      sx={{
        paddingLeft: 3,
        textAlign: "left",
        height: '100%', // Ensure it covers the full height of the sidebar
        padding: 2, // Add some padding for better spacing
        paddingTop: 0,
        bgcolor:"none",
        borderRadius:5,
      }} 
    >
      <Box>
        <Typography 
          variant='h6' 
          sx={{
            fontSize: 16, 
            fontWeight: 600,
          }}
        >
          Create New
        </Typography>
      </Box>
      <Box sx={{ padding: 1, display: 'flex', flexDirection: 'column' }}>
        <IconButton
          edge="start"
          color="inherit"
          aria-label="menu"
          sx={{ ...IconButtonStyles }}
          onClick={e=>handleOpenForm("dut")}
          onMouseEnter={() => setIsHoveredDut(true)}
          onMouseLeave={() => setIsHoveredDut(false)}
        >
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'flex-start',
              textAlign: 'left',
            }}
          >
            <img
                src={isHoveredDut ? fileiconLigh : fileiconDark}
                alt="Search Icon"
                style={{ width: "20px", height: "20px" }}
              />
            <Typography variant="caption" sx={textStyles}>
              DUT
            </Typography>
          </Box>
        </IconButton>

        <IconButton
          edge="start"
          color="inherit"
          aria-label="menu"
          onClick={e=>handleOpenForm("template")}
          sx={{ ...IconButtonStyles, mb: 0 }} // Remove bottom margin for the last button
          onMouseEnter={() => setIsHoveredTemplate(true)}
          onMouseLeave={() => setIsHoveredTemplate(false)}
        >
          <Box
            sx={{
              display: 'flex',
              flexDirection: 'column',
              alignItems: 'flex-start',
              textAlign: 'left',
            }}
          >
             <img
                src={isHoveredTemplate ? templateiconlight : templateicon}
                alt="Search Icon"
                style={{ width: "20px", height: "20px" }}
              />
            <Typography variant="caption" sx={textStyles}>
              Create Template
            </Typography>
          </Box>
        </IconButton>
      </Box>
      {/* Dut adding form modal popup component */}
      {/* <DutAddingModal/> */}
    </Box>
  )
}

export default LandingPageSidebar;
