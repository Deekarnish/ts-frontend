import { Box, Menu, MenuItem, CircularProgress } from "@mui/material";
import Grid from "@mui/material/Grid";
import Card from "@mui/material/Card";
import CardContent from "@mui/material/CardContent";
import CardMedia from "@mui/material/CardMedia";
// import { createTheme } from "@mui/material/styles";
import Typography from "@mui/material/Typography";
// import Dut2 from "../assest/images/Group 115.jpg";
import { useEffect, useState } from "react";
import MoreVertOutlinedIcon from "@mui/icons-material/MoreVertOutlined";
import IconButton from "@mui/material/IconButton";
import { useMediaQuery } from "@mui/material";
import { useTheme } from "@mui/material/styles";
import DutAddingModal from "../components/modals/DutAddingModal";
import { useDispatch, useSelector } from "react-redux";
import { deleteDut, getDuts } from "../components/store/dutSlice";
import { useNavigate } from "react-router-dom";
import { setPage } from "../components/store/pageSlice";
import * as React from "react";
import { setDutDetails } from "../components/store/dutDetailsSlice";
import { setOpenModal, setTypeModal } from "../components/store/dutModalSlice";
import DeleteConfirmationModal from "../components/modals/DeleteConfirmationModal";
import TemplateAddingModal from "../components/modals/TemplateModal";

// const theme = createTheme({
//   breakpoints: {
//     values: {
//       xs: 0,
//       sm: 600, // You can change this value to your desired breakpoint
//       md: 900, // You can change this value to your desired breakpoint
//       lg: 1200,
//       xl: 1600,
//     },
//   },
// });

const menusx = {
  "&:hover": {
    borderRadius: 3,
    bgcolor: "#3391FF",
  },
};

// const style = {
//   position: "absolute",
//   top: "50%",
//   left: "50%",
//   transform: "translate(-50%, -50%)",
//   // width: 400,
//   bgcolor: "background.paper",
//   border: "2px solid #000",
//   boxShadow: 24,
//   p: 4,
//   pb: 2,
//   display: "flex",
//   flexDirection: "column",
//   justifyContent: "space-between",
//   borderRadius: 3,

//   // height: 200,
// };

function MediaCard({ dut, setIntialValues }) {
  const theme = useTheme();

  const navigate = useNavigate();
  const [openDeleteConfirmation, setOpenDeleteConfirmation] = useState(false);
  const dispatch = useDispatch();

  const [isLoading, setIsLoading] = useState(true);
  const [imageError, setImageError] = useState(false);

  const handleImageLoad = () => {
    setIsLoading(false);
    setImageError(false); // No error
  };

  const handleImageError = () => {
    setIsLoading(false);
    setImageError(true);
  };
  const handleDelete = async () => {
    dispatch(deleteDut(dut.id));
    setAnchorEl(null);
    setOpenDeleteConfirmation(false);
  };
  const isMediumScreen = useMediaQuery(theme.breakpoints.down("md"));

  const [anchorEl, setAnchorEl] = useState(null);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  // const initialValues = dut;
  const handleClose = () => {
    setAnchorEl(null);
  };
  const editDut = () => {
    setIntialValues(dut);
    dispatch(setTypeModal("edit"));
    dispatch(setOpenModal(true));
  };
  const duplicateDut = () => {
    dispatch(setTypeModal("duplicate"));
    setIntialValues(dut);
    dispatch(setOpenModal(true));
  };
  const navigateToHMI = () => {
    dispatch(setDutDetails(dut));
    console.log(dut);
    navigate(`/hmi`);
    dispatch(setPage("/hmi"));
  };

  return (
    <Card sx={{ bgcolor: "transparent" }}>
      <Box sx={{ width: "100%", height: "200px" }} onClick={navigateToHMI}>
        {isLoading && (
          <Box
            sx={{
              width: "90%",
              height: "auto",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              backgroundColor: "#f0f0f0",
              borderRadius: "4px",
            }}
          >
            <CircularProgress size={24} />
          </Box>
        )}
        {!imageError && (
          <CardMedia
            component="img"
            sx={{
              width: "100%",
              height: isLoading ? 0 : "100%", // Hide image while loading
              // visibility: isLoading ? "hidden" : "visible", // Prevents flickering
            }}
            image={`${process.env.REACT_APP_BASE_URL}/${dut.file_directory}`}
            alt="DUT Image"
            onLoad={handleImageLoad}
            onError={handleImageError}
          />
         )} 
        {!isLoading && imageError && (
          <Box
            sx={{
              width: "100%",
              height: "100%",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              backgroundColor: "#f0f0f0",
              borderRadius: "4px",
            }}
          >
            <Typography variant="body2" color="textSecondary">
              Image Not Found
            </Typography>
          </Box> 
        )} 
      </Box>
      <CardContent>
        <Box
          sx={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
          }}
        >
          <Box>
            <Typography sx={{ fontSize: isMediumScreen ? "0.7rem" : "0.9rem" }}>
              {dut.name}
            </Typography>
            <Typography
              variant="caption"
              sx={{ fontSize: isMediumScreen ? "0.6rem" : "0.7rem" }}
            >
              {dut.serial_number}
            </Typography>
          </Box>
          <Box>
            <IconButton
              onClick={handleClick}
              sx={{
                p: 1,
                borderRadius: 8,
                backgroundColor: "transparent",
                "&:hover": {
                  backgroundColor: "transparent", // Ensure no background color on hover
                  boxShadow: "none", // Remove any shadow
                },
                boxShadow: "none",
              }}
            >
              <MoreVertOutlinedIcon />
            </IconButton>
            <Menu
              anchorEl={anchorEl}
              open={Boolean(anchorEl)}
              onClose={handleClose}
              MenuListProps={{
                "aria-labelledby": "logo-button",
              }}
              PaperProps={{
                sx: {
                  pl: 1,
                  pr: 1,
                  border: "1px solid #3391FF",
                  borderRadius: 2,
                },
              }}
            >
              <MenuItem onClick={(e) => editDut()} sx={menusx}>
                Edit
              </MenuItem>
              <MenuItem sx={menusx} onClick={(e) => duplicateDut()}>
                Duplicate
              </MenuItem>
              <MenuItem
                onClick={() => setOpenDeleteConfirmation(true)}
                sx={menusx}
              >
                Delete
              </MenuItem>
              {/* <MenuItem onClick={handleClose}>Admin</MenuItem> */}
            </Menu>
          </Box>
        </Box>
      </CardContent>
      <DeleteConfirmationModal
        openDeleteConfirmation={openDeleteConfirmation}
        setOpenDeleteConfirmation={setOpenDeleteConfirmation}
        handleDelete={handleDelete}
      />
    </Card>
  );
}

function ListCard({ dut, setIntialValues }) {
  // const theme = useTheme();

  const navigate = useNavigate();

  const dispatch = useDispatch();

  // const [formMode, setFormMode] = useState("edit");

  // const { status, error } = useSelector((state) => state.duts);

  const handleDelete = async () => {
    dispatch(deleteDut(dut.id));
    setAnchorEl(null);
  };
  // const isMediumScreen = useMediaQuery(theme.breakpoints.down("md"));

  const [anchorEl, setAnchorEl] = useState(null);

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  // const initialValues = dut;

  const handleClose = () => {
    setAnchorEl(null);
  };
  const editDut = () => {
    setIntialValues(dut);
    dispatch(setTypeModal("edit"));
    dispatch(setOpenModal(true));
  };
  const duplicateDut = () => {
    setIntialValues(dut);
    dispatch(setTypeModal("duplicate"));
    dispatch(setOpenModal(true));
  };
  const navigateToHMI = () => {
    navigate(`/hmi`);
    dispatch(setPage("/hmi"));
  };
  return (
    <Card sx={{ display: "flex", p: 0.5, pl: 2, bgcolor: "transparent" }}>
      <Grid container spacing={2} alignItems="center">
        {/* Image Column */}
        <Grid item xs={4}>
          <Box
            sx={{ display: "flex", alignItems: "center", cursor: "pointer" }}
            onClick={navigateToHMI}
          >
            {dut.file_directory ? (
              <CardMedia
                component="img"
                sx={{
                  width: 100,
                  height: 100, // Adjust height to fit the card
                  objectFit: "contain", // This maintains the aspect ratio of the image
                  display: "block", // Prevents extra space below the image (sometimes needed)
                }}
                image={`${process.env.REACT_APP_BASE_URL}/${dut.file_directory}`}
                alt="DUT Image"
              />
            ) : (
              <Box
                sx={{
                  width: 100, // Set the same width as the image
                  height: 90, // Ensure height is adjusted accordingly
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  backgroundColor: "#f0f0f0",
                  borderRadius: "4px", // Optional: Add border radius to match CardMedia styling
                }}
              >
                <Typography
                  variant="body2"
                  color="textSecondary"
                  sx={{ fontSize: 12 }}
                >
                  Image Not Found
                </Typography>
              </Box>
            )}
            <Typography sx={{ fontSize: 14, pl: 1 }}>{dut.name}</Typography>
          </Box>
        </Grid>

        {/* Date Column */}
        <Grid item xs={4} onClick={navigateToHMI} sx={{ cursor: "pointer" }}>
          <Typography
            variant="body1"
            sx={{ textAlign: "center", fontSize: 14 }}
          >
            {/* Created on: 2024-08-03 */}
          </Typography>
        </Grid>

        {/* Edit Button Column */}
        <Grid item xs={4}>
          <Box sx={{ display: "flex", justifyContent: "flex-end" }}>
            <IconButton
              onClick={handleClick}
              sx={{
                fontSize: 12,
                border: "1px solid black",
                borderRadius: 2,
                p: 0.5,
                pl: 1,
                pr: 1,
              }}
            >
              Edit <MoreVertOutlinedIcon sx={{ fontSize: 16 }} />
            </IconButton>
          </Box>
        </Grid>
      </Grid>
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)}
        onClose={handleClose}
        MenuListProps={{
          "aria-labelledby": "logo-button",
        }}
        PaperProps={{
          sx: {
            pl: 1,
            pr: 1,
            border: "1px solid #3391FF",
            borderRadius: 2,
          },
        }}
      >
        <MenuItem onClick={(e) => editDut()} sx={menusx}>
          Edit
        </MenuItem>
        <MenuItem sx={menusx} onClick={(e) => duplicateDut()}>
          Duplicate
        </MenuItem>
        <MenuItem sx={menusx} onClick={handleDelete}>
          Delete
        </MenuItem>
        {/* <MenuItem onClick={handleClose}>Admin</MenuItem> */}
      </Menu>
    </Card>
  );
}

export default function DutList({ list }) {
  const dispatch = useDispatch();
  const { data: duts } = useSelector((state) => state.duts);
  const [initialValues, setIntialValues] = useState(false);
  const [viewportHeight, setViewportHeight] = useState(window.innerHeight);

  useEffect(() => {
    //call getDutfunction for set list of dut in Dut slice in react redux
    dispatch(getDuts());

    const handleResize = () => {
      setViewportHeight(window.innerHeight);
    };

    window.addEventListener("resize", handleResize);

    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);
  return (
    <Box
      sx={{
        flexGrow: 1,
        padding: 1,
        height: viewportHeight - 165,
        overflow: "auto",
      }}
    >
      <Grid
        container
        spacing={
          list
            ? { xs: 0.2, md: 0.2, sm: 0.2, xl: 0.5 }
            : { xs: 1, md: 1, sm: 1, xl: 1 }
        }
        columns={{ xs: 2, sm: 6, md: 12, xl: 12 }}
      >
        {list === "list"
          ? duts.map((dut, index) => (
              <Grid item xs={12} sm={12} md={12} xl={12} key={index}>
                <ListCard dut={dut} setIntialValues={setIntialValues} />
              </Grid>
            ))
          : duts.map((dut, index) => (
              <Grid item xs={3} sm={2} md={3} xl={2} key={index} sx={{ p: 1 }}>
                <MediaCard dut={dut} setIntialValues={setIntialValues} />
              </Grid>
            ))}
      </Grid>
      <DutAddingModal initialValues={initialValues} />
      <TemplateAddingModal initialValues={initialValues} />
    </Box>
  );
}
