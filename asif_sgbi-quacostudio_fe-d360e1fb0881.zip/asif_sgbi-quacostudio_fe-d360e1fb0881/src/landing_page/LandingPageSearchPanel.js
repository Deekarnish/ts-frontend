// import { useTheme } from "@emotion/react";
import {
  Box,
  Button,
  Grid,
  TextField,
  Typography,
  InputAdornment,
  IconButton,
  // Input,
} from "@mui/material";
import React, { useEffect, useState } from "react";
import SearchOutlinedIcon from "@mui/icons-material/SearchOutlined";
import MenuOutlinedIcon from "@mui/icons-material/MenuOutlined";
import GridViewOutlinedIcon from "@mui/icons-material/GridViewOutlined";
import { CloseOutlined } from "@mui/icons-material";
import { useDispatch } from "react-redux";
import { searchDuts } from "../components/store/dutSlice";
import searchIcon from "../assest/icons/search-loupe.svg";

const LandingPageSearchPanel = (props) => {
  // const theme = useTheme();
  const { list, setList } = props;
  const [dut, setDut] = useState(true);
  const [query, setQuery] = useState("");
  const [searchopen, setSearchOpen] = useState(false);
  const dispatch = useDispatch();
  const changeButton = () => {
    setDut(!dut);
  };
  const ButtonActiveStyle = {
    background: "linear-gradient(150deg, #33BFFF 0%, #5D5CE5 100%)",
    textTransform: "none",
    borderRadius: 2,
    color: " #FEFEFE",
    fontFamily: "Inter",
    fontSize: "14px",
    fontStyle: "normal",
    fontWeight: 700,
    p: 1,
    pl: 2,
    pr: 2,
    lineHeight: "16px" /* 114.286% */,
  };

  const ButttonNormalStyle = {
    textTransform: "none",
    bgcolor: "none",
    boxShadow: "none",
    p: 1,
    pl: 2,
    pr: 2,
    color: "black",
    fontFamily: "Inter",
    fontSize: "14px",
    fontStyle: "normal",
    fontWeight: 700,
    lineHeight: "16px" /* 114.286% */,
  };
  const handleChange = (data) => {
    setList(data);
  };
  const handleOpenSearch = () => {
    setSearchOpen(!searchopen);
  };
  const handleSearch = () => {
    dispatch(searchDuts(query));
  };
  useEffect(() => {
    handleSearch();
  }, [query]);
  return (
    <Grid
      container
      sx={{
        // width: "99%",
        height: 50,
        bgcolor: "white",
        mr: 2,
        mt: -1,
        mb: 1,
        borderRadius: 2,
        display: "flex",
        flexDirection: "row",
        alignItems: "center",
        justifyContent: "space-between",
        paddingLeft: 1, // Optional: Add some padding for better text alignment
      }}
    >
      <Grid item xs={5} sx={{ display: "inline-flex", alignItems: "center" }}>
        <Typography
          sx={{
            color: "var(--Grey--400, #232328)",
            fontFamily: "Inter",
            fontSize: "14px",
            fontStyle: "normal",
            fontWeight: 600,
            lineHeight: "normal",
          }}
        >
          Recent
        </Typography>
        <Box
          sx={{
            // boxShadow: `0.3px 0.3px 0px 0.7px #C9F3FF`,
            // boxShadow:"#8CC9FF 0px 3px 8px",
            boxShadow: "#8CC9FF  0px 0px 0.15em, #8CC9FF 0px 0.15em 0.5em",
            ml: 2,
            padding: 0.5,
            borderRadius: 3,
            display: "inline-flex",
          }}
        >
          <Button
            variant="contained"
            size="small"
            sx={dut ? ButtonActiveStyle : ButttonNormalStyle}
            onClick={changeButton}
          >
            DUT’s
          </Button>
          <Button
            variant="contained"
            size="small"
            sx={dut ? ButttonNormalStyle : ButtonActiveStyle}
            onClick={changeButton}
          >
            Templates
          </Button>
        </Box>
      </Grid>

      <Grid item xs={2}>
        {/* <Box sx={{ boxShadow: `0.3px 0.3px 0px 0.7px ${theme.palette.primary.button}`,padding:0.5, borderRadius:3, display: 'inline-flex', }}>
            <Button variant="contained" size="small" sx={dut ? ButtonActiveStyle : ButttonNormalStyle} onClick={changeButton}>
                DUT's
            </Button>
            <Button variant="contained" size="small" sx={dut ?ButttonNormalStyle : ButtonActiveStyle} onClick={changeButton}>
                Templates
            </Button>
        </Box> */}
      </Grid>
      <Grid
        item
        xs={5}
        sx={{
          paddingRight: 1,
          display: "flex",
          justifyContent: "end",
          alignItems: "center",
        }}
      >
        {searchopen && (
          <TextField
            variant="standard"
            placeholder="search"
            onChange={(e) => setQuery(e.target.value)}
            InputProps={{
              endAdornment: (
                <img
                  src={searchIcon}
                  alt="Search Icon"
                  style={{ width: "20px", height: "20px" }}
                />
              ),
              sx: {
                "& .MuiOutlinedInput-root": {
                  "& .MuiOutlinedInput-notchedOutline": {
                    borderColor: "blue",
                  },
                  "& .MuiInputBase-input": {
                    display: "flex",
                    alignItems: "center",
                  },
                },
              },
            }}
          />
        )}
        <Box
          sx={{
            display: "flex",
            alignItems: "center",
            gap: 1, // Adjust the spacing value as needed
          }}
        >
          <IconButton onClick={handleOpenSearch}>
            {searchopen ? (
              <CloseOutlined />
            ) : (
              <img
                src={searchIcon}
                alt="Search Icon"
                style={{ width: "20px", height: "20px" }}
              />
            )}
          </IconButton>
          <IconButton
            onClick={() => handleChange("list")}
            sx={{
              borderRadius: 2,
              bgcolor: list === "list" ? "#CDE5FA" : "none",
            }}
          >
            <MenuOutlinedIcon />
          </IconButton>
          <IconButton
            onClick={() => handleChange("grid")}
            sx={{
              borderRadius: 2,
              bgcolor: list === "grid" ? "#CDE5FA" : "none",
            }}
          >
            <GridViewOutlinedIcon sx={{ fontSize: 20 }} />
          </IconButton>
        </Box>
      </Grid>
    </Grid>
  );
};

export default LandingPageSearchPanel;
