// import React from 'react'
// import DutList from './LandingPageDutList'
// const LandingPageMain = () => {
//   return (
//   <>

//   <DutList/>

//   </>
//   )
// }

// export default LandingPageMain