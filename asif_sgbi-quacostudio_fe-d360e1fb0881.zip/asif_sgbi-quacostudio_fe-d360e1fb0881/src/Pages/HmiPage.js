import React, { useEffect, useState, useRef } from "react";
import {
  Box,
  IconButton,
  ThemeProvider,
  Typography,
  createTheme,
  Menu,
  MenuItem,
  InputAdornment,
  TextField,
} from "@mui/material";
import searchIcon from "../assest/icons/search-loupe.svg";
import plusIcon from "../assest/icons/plus-medium.svg";
import SettingIcon from "../assest/icons/video-player-play.svg";
import InspectorPanelButtonList from "../hmi_page/InspectorPanelButtonList";
import DutIndicatorsList from "../hmi_page/DutIndicatorsList";
import DutScreenList from "../hmi_page/DutScreenList";
import DutOcrList from "../hmi_page/DutOcrList";
import DutKeyPadList from "../hmi_page/DutKeyPad";
import VideoFeed from "../components/VideoFeed";
import { useDispatch, useSelector } from "react-redux";
import Cookies from "js-cookie";
import { fetchDutDetails } from "../components/store/dutDetailsSlice";
import astericsicon from "../assest/icons/keyboard-asterisk-square.svg";
import lightbulb from "../assest/icons/LightBulb.svg";
import ocr from "../assest/icons/ocrtextIcon.svg";
import {
  clearState,
  createDutButton,
  fetchDutButtonById,
  setParams,
  updateDutButton,
} from "../components/store/dutButtonSlice";
import {
  disableFeature,
  enableFeature,
  setClear,
  setFeature,
} from "../components/store/pageSlice";
import DutAddingModal from "../components/modals/DutAddingModal";
import closeIcon from "../assest/icons/close.svg";
import GeneralSettings from "../hmi_page/PropertyGeneralSettings";
import RegionOfInterest from "../hmi_page/RegionOfInterest";
import GlobalSettings from "../hmi_page/GlobalSettings";
import EngineSettings from "../hmi_page/EngineSettings";
import {
  disableVideoFeedCanvas,
  enableVideoFeedCanvas,
} from "../components/store/videoFeedSlice";
import {
  clearScreenState,
  createDutScreen,
  fetchDutScreenById,
  setParamsSCreen,
  updateDutScreen,
} from "../components/store/dutScreenSlice";
import { debounce } from "lodash";
import {
  disableAllAndEnableOption,
  setFeatureExpand,
} from "../components/store/hmiOptionsSlice";
import AccordionExpandDefault from "../components/AccordianComponent";
import { useTheme } from "@emotion/react";
import IndicatorState from "../hmi_page/IndicatorState";
import ScreenElementsList, {
  AddScreenElements,
} from "../hmi_page/ScreenElements";
import OcrScreenTabs from "../hmi_page/SwitchTab";
import OcrComponents from "../hmi_page/OcrComponent";
import DividerWithText from "../components/DividerComponent";
import VideoSurveillance from "../components/VideoServeillance";

const menusx = {
  width: 150,
  "&:hover": {
    borderRadius: 2,
    // background:"linear-.(90deg, rgba(11,139,217,1) 0%, rgba(46,114,195,1) 72%, rgba(65,101,240,1) 99%)",
    bgcolor: "#3391FF",
    color: "#FEFEFE",
  },
};

function HMIPage() {
  const [viewportHeight, setViewportHeight] = useState(window.innerHeight);
  const videoFeedRef = useRef(null);
  const [anchorEl, setAnchorEl] = useState(null);
  const { clearscreen } = useSelector((state) => state.page);
  const theme = useTheme();

  const [search, setSearch] = useState({
    properties: false,
    inspector: false,
  });
  const dispatch = useDispatch();

  const feature = useSelector((state) => state.page);
  const { addOcr, updateOcr } = useSelector((state) => state.ocr);
  const { addElement, updateElement } = useSelector(
    (state) => state.screenelements
  );
  const {
    exposure,
    name,
    startX,
    startY,
    width,
    height,
    imgurl,
    light,
    id,
    create,
    update,
    position,
  } = useSelector((state) =>
    feature.buttons ? state.dutButtons : state.dutScreen
  );
  const { inspectorPanel } = useSelector((state) => state.hmiOptionsSlice);
  const dutId = Cookies.get("dutId");

  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleClose = (event) => {
    // console.log(event, "event");
    setAnchorEl(null);
  };

  const handleClickOption = (option) => {
    dispatch(enableFeature(option));
    dispatch(setFeatureExpand({ feature: "inspectorPanel", value: true }));
    dispatch(setFeatureExpand({ feature: "propertiesGlobal", value: true }));

    switch (option) {
      case "buttons":
        dispatch(clearState());
        dispatch(clearScreenState());
        dispatch(setParams({ update: false, create: true }));
        dispatch(disableAllAndEnableOption("buttonExpand"));

        break;
      case "screens":
        dispatch(clearScreenState());
        dispatch(clearState());
        dispatch(setParamsSCreen({ update: false, create: true }));
        dispatch(disableAllAndEnableOption("screenExapand"));
    }
    handleClose();
  };

  const handleClearRectangle = () => {
    if (videoFeedRef.current) {
      videoFeedRef.current.clearReactangle();
    }
  };

  useEffect(() => {
    dispatch(fetchDutDetails(dutId));
    dispatch(fetchDutButtonById(dutId));
    dispatch(fetchDutScreenById(dutId));
    const handleResize = () => {
      setViewportHeight(window.innerHeight);
    };
    window.addEventListener("resize", handleResize);
    return () => {
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  const handleCreateButton = () => {
    if (!imgurl) {
      console.error("Image URL not available yet.");
      return;
    }

    try {
      const buttonData = {
        // Ensure imgurl is split only if it's valid and fully loaded
        button_image: imgurl.split(",")[1], // Split the base64 image data
        button_name: name,
        button_position: position,
        button_roi: `${startX}:${startY}:${width}:${height}`,
        light: light,
        dut_id: parseInt(dutId),
      };

      dispatch(createDutButton(buttonData));
    } catch (error) {
      console.error("Error processing the image URL:", error);
    }
  };

  const handleCreateScreen = () => {
    const screenData = {
      screen_name: name,
      screen_position: position,
      screen_roi: `${startX}:${startY}:${width}:${height}`,
      light: light,
      dut_id: parseInt(dutId),
      exposure: String(exposure),
      orientation: "180",
      // button_image: imgurl.split(",")[1],
    };
    dispatch(createDutScreen(screenData));
  };

  const handleUpdateButton = () => {
    const buttonData = {
      button_name: name,
      // button_position: position,
      button_roi: `${startX}:${startY}:${width}:${height}`,
      light: light,
      dut_id: parseInt(dutId),
      button_image: imgurl.split(",")[1],
    };
    dispatch(updateDutButton({ id: id, dutButtonData: buttonData }));
  };

  const handleUpdateScreen = () => {
    const screenData = {
      screen_name: name,
      // screen_position: position,
      screen_roi: `${startX}:${startY}:${width}:${height}`,
      light: light,
      dut_id: dutId,
      exposure: exposure,
      orientation: "string",
      // button_image: imgurl.split(",")[1],
    };
    dispatch(updateDutScreen({ id: id, dutScreenData: screenData }));
  };

  const debouncedSave = debounce((fn) => {
    fn(); // Call the function with spread parameters
  }); // Save after 1 second of inactivity

  useEffect(() => {
    if (feature.buttons && width && height && name) {
      if (update || id) {
        // debouncedSave(handleUpdateButton); // Pass the function
      } else if (create) {
        debouncedSave(handleCreateButton); // Pass the function
        dispatch(setFeatureExpand({ feature: "inspectorPanel", value: false }));
      }
    } else if (feature.screens && width && height && name) {
      if (update || id) {
        // debouncedSave(handleUpdateScreen); // Pass the function
      } else if (create) {
        debouncedSave(handleCreateScreen); // Pass the function
        dispatch(setFeatureExpand({ feature: "inspectorPanel", value: false }));
      }
    }

    // Clean up the debounce on unmount
    return () => {
      debouncedSave.cancel();
    };
  }, [width, name, height, light, exposure, imgurl, create, update]);
  
  const autoSave = () => {
    if (update) {
      if (feature.buttons) {
        debouncedSave(handleUpdateButton);
      } else if (feature.screens) {
        debouncedSave(handleUpdateScreen);
      }
    }
  };

  const handleSetSearch = (name) => {
    setSearch((previous) => ({
      ...previous,
      [name]: !previous[name], // Toggle the current value of search[name]
    }));
  };
  useEffect(() => {
    if (clearscreen) {
      handleClearRectangle();
      setTimeout(() => {
        dispatch(setClear(false));
      }, 2000);
    }
  }, [clearscreen]);
  const boxRef = useRef(null);

  // Scroll to the bottom whenever the content updates
  const scrollToBottom = () => {
    const box = boxRef.current;
    if (box) {
      box.scrollTop = box.scrollHeight; // Scroll to the bottom
    }
  };

  // Trigger scroll to bottom when content changes
  useEffect(() => {
    scrollToBottom();
  }, [updateElement, addElement , addOcr ,updateOcr]);

  return (
    <Box
      sx={{
        flexGrow: 1,
        height: viewportHeight - 66,
        overflow: "auto",
        mt: -2,
      }}
    >
      <Box sx={{ display: "flex", height: "100%", alignItems: "stretch" }}>
        {/* HMI page inspector panel */}
        <Box
          sx={{
            flex: "0 0 15%",
            minWidth: "250px",
            overflowY: "auto",
            // opacity: inspectorPanel ? 0.5 : 1,
            // pointerEvents: inspectorPanel ? "none" : "",
          }}
        >
          <Box
            display="flex"
            justifyContent="space-between"
            alignItems="center"
            pl={2}
          >
            <Box
              display="flex"
              alignItems="center"
              sx={{ flexGrow: 1 }} // This allows the search box or text to take up the remaining space
            >
              {search.inspector ? (
                <TextField
                  variant="standard"
                  placeholder="Search"
                  InputProps={{
                    endAdornment: (
                      <InputAdornment position="end">
                        <img
                          src={searchIcon}
                          alt="Search Icon"
                          style={{ width: "20px", height: "20px" }}
                        />
                      </InputAdornment>
                    ),
                    sx: {
                      width: "100%", // Ensures the input takes up the available space within the flex container
                      "& .MuiOutlinedInput-root": {
                        "& .MuiOutlinedInput-notchedOutline": {
                          borderColor: "blue",
                        },
                        "& .MuiInputBase-input": {
                          display: "flex",
                          alignItems: "center",
                        },
                      },
                    },
                  }}
                  sx={{ width: "100%" }} // Ensures the TextField takes up full width
                />
              ) : (
                <Typography>Inspector</Typography>
              )}
            </Box>

            <Box display="flex" alignItems="center">
              <IconButton onClick={(e) => handleSetSearch("inspector")}>
                {search.inspector ? (
                  <img
                    src={closeIcon}
                    alt="Close Icon"
                    style={{ width: "13px", height: "13px" }}
                  />
                ) : (
                  <img
                    src={searchIcon}
                    alt="Search Icon"
                    style={{ width: "24px", height: "24px" }}
                  />
                )}
              </IconButton>
              <IconButton onClick={handleClick}>
                <img
                  src={plusIcon}
                  alt="plus Icon"
                  style={{ width: "24px", height: "24px" }}
                />
              </IconButton>
            </Box>
          </Box>
          <InspectorPanelButtonList onClearRectangle={handleClearRectangle} />
          {/* <DutIndicatorsList /> */}
          <DutScreenList onClearRectangle={handleClearRectangle} />
          {feature.screens && id && <OcrScreenTabs />}
          {/* <DutOcrList />
          <DutKeyPadList /> */}

          <Menu
            anchorEl={anchorEl}
            open={Boolean(anchorEl)} //onclick plus Icon on top of inspector panel open this menu
            onClose={handleClose}
            sx={{ width: 400 }}
            PaperProps={{
              sx: {
                pl: 1,
                pr: 1,
                border: "1px solid #3391FF",
                borderRadius: 2,
              },
            }}
          >
            <MenuItem
              onClick={() => handleClickOption("buttons")}
              sx={menusx}
              name="buttons"
            >
              {" "}
              <img
                src={astericsicon}
                alt="indicator icon"
                style={{
                  width: "20px",
                  height: "20px",
                  textTransform: "none",
                  marginRight: "5px",
                }}
              />
              Buttons
            </MenuItem>
            <MenuItem
              onClick={() => handleClickOption("indicators")}
              sx={menusx}
            >
              {" "}
              <img
                src={lightbulb}
                alt="indicator icon"
                style={{
                  width: "20px",
                  height: "20px",
                  textTransform: "none",
                  marginRight: "5px",
                }}
              />
              Indicator
            </MenuItem>
            <MenuItem
              onClick={() => handleClickOption("ocr")}
              sx={menusx}
              name="ocr"
            >
              {" "}
              <img
                src={ocr}
                alt="indicator icon"
                style={{
                  width: "20px",
                  height: "20px",
                  textTransform: "none",
                  marginRight: "5px",
                }}
              />
              Ocr
            </MenuItem>
            <MenuItem onClick={() => handleClickOption("screens")} sx={menusx}>
              {" "}
              <img
                src={astericsicon}
                alt="indicator icon"
                style={{
                  width: "20px",
                  height: "20px",
                  textTransform: "none",
                  marginRight: "5px",
                }}
              />
              Screens
            </MenuItem>
            <MenuItem onClick={() => handleClickOption("keypad")} sx={menusx}>
              {" "}
              <img
                src={astericsicon}
                alt="indicator icon"
                style={{
                  width: "20px",
                  height: "20px",
                  textTransform: "none",
                  marginRight: "5px",
                }}
              />
              Keypad
            </MenuItem>
          </Menu>
        </Box>

        {/* HMI page DUT video streaming area */}

        <Box
          sx={{
            flex: "1 1 auto",
            height: "100%",
            bgcolor: "#E9F3FC",
            minWidth: 0,
            display: "flex",
            position: "relative",
            flexDirection: "column", // Ensure that the accordion stacks vertically with the video feed
          }}
        >
          <VideoFeed
            ref={videoFeedRef}
            sx={{ flex: "1 1 auto", width: "100%", overflow: "auto" }}
          />
          <AccordionExpandDefault />
        </Box>

        {/* HMI page properties panel */}
        <Box
          sx={{
            display: "flex",
            flexDirection: "column",
            flex: "0 0 20%",
            minWidth: "300px",
            overflowY: "auto",
          }}
        >
          {/* First Box with 70% height */}
          <Box
            sx={{ flex: "0 0 70%", overflowY: "auto" }}
            ref={boxRef}
          >
            <Box
              display="flex"
              justifyContent="space-between"
              alignItems="center"
              pl={2}
            >
              <Box display="flex" alignItems="center" sx={{ flexGrow: 1 }}>
                {search.properties ? (
                  <TextField
                    variant="standard"
                    placeholder="Search"
                    InputProps={{
                      endAdornment: (
                        <InputAdornment position="end">
                          <img
                            src={searchIcon}
                            alt="Search Icon"
                            style={{ width: "20px", height: "20px" }}
                          />
                        </InputAdornment>
                      ),
                      sx: {
                        width: "100%",
                        "& .MuiOutlinedInput-root": {
                          "& .MuiOutlinedInput-notchedOutline": {
                            borderColor: "blue",
                          },
                          "& .MuiInputBase-input": {
                            display: "flex",
                            alignItems: "center",
                          },
                        },
                      },
                    }}
                    sx={{ width: "100%" }}
                  />
                ) : (
                  <Typography>Properties</Typography>
                )}
              </Box>

              <Box display="flex" alignItems="center">
                <IconButton>
                  <img
                    src={SettingIcon}
                    alt="Setting Icon"
                    style={{ width: "24px", height: "24px" }}
                  />
                </IconButton>
              </Box>
            </Box>

            {feature.buttons ? (
              <>
                <GeneralSettings autoSave={autoSave} />
                {name && name.length > 2 && (
                  <RegionOfInterest autoSave={autoSave} />
                )}
                {width > 0 && height > 0 && (
                  <GlobalSettings autoSave={autoSave} />
                )}
              </>
            ) : feature.screens ? (
              <>
                <GeneralSettings autoSave={autoSave} />
                {name && name.length > 2 && (
                  <RegionOfInterest autoSave={autoSave} />
                )}
                {width > 0 && height > 0 && (
                  <GlobalSettings autoSave={autoSave} />
                )}
                {id && (
                  <>
                    {(addElement || updateElement) && (
                      <>
                        <DividerWithText text={"Element"} />
                        <AddScreenElements />
                      </>
                    )}
                    {(addOcr || updateOcr) && (
                      <>
                        <DividerWithText text={"Ocr"} />
                        <OcrComponents />
                      </>
                    )}
                  </>
                )}
              </>
            ) : (
              <></>
            )}
          </Box>

          {/* Second Box with 30% height */}
          <Box sx={{ flex: "0 0 30%", overflowY: "auto" }}>
            <VideoSurveillance />
          </Box>
        </Box>
      </Box>

      <DutAddingModal isEditMode={false} />
    </Box>
  );
}

export default HMIPage;
