import {
  Box,
  IconButton,
  ThemeProvider,
  Typography,
  createTheme,
  Menu,
  MenuItem,
  Select,
  Grid,
  InputAdornment,
  TextField,
  Divider,
} from "@mui/material";

import React, { useEffect, useRef, useState } from "react";
import searchIcon from "../assest/icons/search-loupe.svg";
import plusIcon from "../assest/icons/plus-medium.svg";
import closeIcon from "../assest/icons/close.svg";
import GeneralSettingsHapi from "../hapi_page/HapiGeneralSettings";

import TapParameters from "../hapi_page/TapParameters";
import SetResponse from "../hapi_page/ResponseComponent";
import AccordionExpandDefault from "../components/AccordianComponent";
import VideoFeed from "../components/VideoFeed";
import HapiList from "../hapi_page/HapiList";
import ScriptList from "../hapi_page/hapiPageScriptList";
import { useDispatch, useSelector } from "react-redux";
import { setHapiFeature } from "../components/store/hapiPageSlice";
import ArrowForwardIosIcon from "@mui/icons-material/ArrowForwardIos";
import ScriptRunButtons from "../hapi_page/ScriptRunButtons";
import {
  clearHapiState,
  resethapiSlice,
  setHapiValues,
} from "../components/store/hapiSlice";
import {
  clearHapiScriptState,
  fetchHapiScripts,
  resetAllScripts,
} from "../components/store/hapiScriptSlice";
import { fetchDutDetails } from "../components/store/dutDetailsSlice";
import { fetchDutButtonById } from "../components/store/dutButtonSlice";
import { fetchDutScreenById } from "../components/store/dutScreenSlice";
import Cookies from "js-cookie";
import VideoServeillance from "../components/VideoServeillance";
import ExtraOptions from "../hapi_page/api_options/ExtrasOptions";
import Move from "../hapi_page/api_options/Move";
import Tap from "../hapi_page/api_options/Tap";
import Swipe from "../hapi_page/api_options/Swipe";
import MouseAssist from "../hapi_page/MouseAssist";
import { disableAllAndEnableFeature, enableVideoFeedCanvas } from "../components/store/videoFeedSlice";
import HapiButtonsSelect from "../hapi_page/HapiButtonSelection";
import HapiElements from "../hapi_page/HapiElements";
import AddDelayModal from "../components/modals/DelayScriptModal";
import SingleScripTest from "../hapi_page/RunSingleScript";
import DelayParameters from "../hapi_page/DelayParaMeters";
import Ocr from "../hapi_page/api_options/Ocr";
const theme = createTheme({
  breakpoints: {
    values: {
      xs: 0,
      sm: 600,
      md: 900,
      lg: 1200,
      xl: 1600,
    },
  },
});

const menusx = {
  width: 150,
  "&:hover": {
    borderRadius: 2,
    // background:"linear-.(90deg, rgba(11,139,217,1) 0%, rgba(46,114,195,1) 72%, rgba(65,101,240,1) 99%)",
    bgcolor: "#3391FF",
    color: "#FEFEFE",
  },
};

const HapiOptions = ({ handleClose, anchorEl }) => {
  const dispatch = useDispatch();
  const [anchorElSub, setAnchorElSub] = useState(null);
  const [option, setOption] = useState(true);

  const handleClickOpen = (event, name) => {
    setAnchorElSub(event.currentTarget);
    setOption(name);
  };

  const handleCloseSubmenu = () => {
    setAnchorElSub(null);
  };

  const handleClickMouseAssist = () => {
    dispatch(setHapiValues({ feature: "hapiAction", value: "Mouse Assist" }));
    dispatch(setHapiValues({ feature: "hapiType", value: "MV" }));
    dispatch(setHapiValues({ feature: "command", value: "f:str" }));
    dispatch(disableAllAndEnableFeature("MouseAssist"));
    handleClose();
  };

  return (
    <div>
      <Menu
        anchorEl={anchorEl}
        open={Boolean(anchorEl)} // Opens the main menu
        onClose={handleClose}
        sx={{ width: 400 }}
        PaperProps={{
          sx: {
            pl: 1,
            pr: 1,
            border: "1px solid #3391FF",
            borderRadius: 2,
          },
        }}
      >
        <MenuItem
          sx={menusx}
          name="move"
          onClick={(e) => handleClickOpen(e, "move")}
        >
          {" "}
          Move
          <ArrowForwardIosIcon sx={{ marginLeft: "auto", fontSize: 14 }} />
        </MenuItem>
        <MenuItem
          sx={menusx}
          name="tap"
          onClick={(e) => handleClickOpen(e, "tap")}
        >
          {" "}
          Tap
          <ArrowForwardIosIcon sx={{ marginLeft: "auto", fontSize: 14 }} />
        </MenuItem>
        <MenuItem
          sx={menusx}
          name="ocr"
          onClick={(e) => handleClickOpen(e, "ocr")}
        >
          {" "}
          Ocr
          <ArrowForwardIosIcon sx={{ marginLeft: "auto", fontSize: 14 }} />
        </MenuItem>
        <MenuItem
          sx={menusx}
          name="swipe"
          onClick={(e) => handleClickOpen(e, "swipe")}
        >
          {" "}
          Swipe
          <ArrowForwardIosIcon sx={{ marginLeft: "auto", fontSize: 14 }} />
        </MenuItem>
        <MenuItem
          sx={menusx}
          name="mouseAssist"
          onClick={(e) => handleClickMouseAssist(e)}
        >
          {" "}
          Mouse assist
          <ArrowForwardIosIcon sx={{ marginLeft: "auto", fontSize: 14 }} />
        </MenuItem>
        <MenuItem
          sx={menusx}
          name="pinch"
          onClick={(e) => handleClickOpen(e, "pinch")}
        >
          {" "}
          Pinch
          <ArrowForwardIosIcon sx={{ marginLeft: "auto", fontSize: 14 }} />
        </MenuItem>
        <MenuItem
          sx={menusx}
          name="extras"
          onClick={(e) => handleClickOpen(e, "extras")}
        >
          {" "}
          Extras
          <ArrowForwardIosIcon sx={{ marginLeft: "auto", fontSize: 14 }} />
        </MenuItem>
      </Menu>
      {option === "tap" && (
        <Tap
          anchorElSub={anchorElSub}
          handleCloseSubmenu={handleCloseSubmenu}
          handleClose={handleClose}
        />
      )}
      {option === "move" && (
        <Move
          anchorElSub={anchorElSub}
          handleCloseSubmenu={handleCloseSubmenu}
          handleClose={handleClose}
        />
      )}
      {option === "extras" && (
        <ExtraOptions
          anchorElSub={anchorElSub}
          handleCloseSubmenu={handleCloseSubmenu}
          handleClose={handleClose}
        />
      )}
      {option === "swipe" && (
        <Swipe
          anchorElSub={anchorElSub}
          handleCloseSubmenu={handleCloseSubmenu}
          handleClose={handleClose}
        />
      )}
      {option === "ocr" && (
        <Ocr
          anchorElSub={anchorElSub}
          handleCloseSubmenu={handleCloseSubmenu}
          handleClose={handleClose}
        />
      )}
    </div>
  );
};

function HapiPage() {
  const [viewportHeight, setViewportHeight] = useState(window.innerHeight);
  const [anchorEl, setAnchorEl] = useState(null);

  const videoFeedRef = useRef(null);

  const { addNewHapi, hapiElements, hapiTapParams, hapiGeneral } = useSelector(
    (state) => state.hapipage
  );
  const { hapiAction, hapiScriptName, activeIndex, hapiId, hapiType } =
    useSelector((state) => state.hapivalues);
  const { hapiScriptList } = useSelector((state) => state.hapiScripts);

  const dispatch = useDispatch();
  const [search, setSearch] = useState({
    action: false,
    hapi: false,
    script: false,
  });
  const dutId = Cookies.get("dutId");

  const handleClose = () => {
    setAnchorEl(null);
  };
  const handleSetSearch = (name) => {
    setSearch((previous) => ({
      ...previous,
      [name]: !previous[name], // Toggle the current value of search[name]
    }));
  };

  useEffect(() => {
    dispatch(resetAllScripts());
    dispatch(fetchHapiScripts(hapiId));
  }, [hapiId]);

  const handleAddNewHapi = () => {
    dispatch(setHapiFeature({ feature: "addNewHapi", value: true }));
  };
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
    dispatch(clearHapiState());
    dispatch(clearHapiScriptState());
  };
  const handleClearRectangle = () => {
    if (videoFeedRef.current) {
      videoFeedRef.current.clearReactangle();
    }
  };
  React.useEffect(() => {
    dispatch(resethapiSlice());
    dispatch(fetchDutDetails(dutId));
    dispatch(fetchDutButtonById(dutId));
    dispatch(fetchDutScreenById(dutId));
    // handleClearRectangle();
  }, []);
  return (
    <ThemeProvider theme={theme}>
      <Box
        sx={{
          flexGrow: 1,
          height: viewportHeight - 66,
          overflow: "auto",
          mt: -2,
        }}
      >
        <Box sx={{ display: "flex", height: "100%", alignItems: "stretch" }}>
          {/* HAPI page inspector panel */}
          <Box sx={{ flex: "0 0 15%", overflowY: "auto", minWidth: "250px" }}>
            <Box
              display="flex"
              justifyContent="space-between"
              alignItems="center"
              pl={2}
            >
              <Box
                display="flex"
                alignItems="center"
                sx={{ flexGrow: 1 }} // This allows the search box or text to take up the remaining space
              >
                {search.hapi ? (
                  <TextField
                    variant="standard"
                    placeholder="Search"
                    InputProps={{
                      endAdornment: (
                        <InputAdornment position="end">
                          <img
                            src={searchIcon}
                            alt="Search Icon"
                            style={{ width: "20px", height: "20px" }}
                          />
                        </InputAdornment>
                      ),
                      sx: {
                        width: "100%", // Ensures the input takes up the available space within the flex container
                        "& .MuiOutlinedInput-root": {
                          "& .MuiOutlinedInput-notchedOutline": {
                            borderColor: "blue",
                          },
                          "& .MuiInputBase-input": {
                            display: "flex",
                            alignItems: "center",
                          },
                        },
                      },
                    }}
                    sx={{ width: "100%" }} // Ensures the TextField takes up full width
                  />
                ) : (
                  <Typography>ALL HAPI</Typography>
                )}
              </Box>

              <Box display="flex" alignItems="center">
                <IconButton onClick={(e) => handleSetSearch("hapi")}>
                  {search.hapi ? (
                    <img
                      src={closeIcon}
                      alt="Close Icon"
                      style={{ width: "13px", height: "13px" }}
                    />
                  ) : (
                    <img
                      src={searchIcon}
                      alt="Search Icon"
                      style={{ width: "24px", height: "24px" }}
                    />
                  )}
                </IconButton>
                <IconButton
                  onClick={handleAddNewHapi}
                  sx={{
                    pointerEvents: addNewHapi ? "none" : "",
                  }}
                >
                  <img
                    src={plusIcon}
                    alt="plus Icon"
                    style={{ width: "24px", height: "24px" }}
                  />
                </IconButton>
              </Box>
            </Box>
            <HapiList />
            {activeIndex !== false && (
              <>
                <Box
                  display="flex"
                  justifyContent="space-between"
                  alignItems="center"
                  pl={2}
                  sx={{
                    boxShadow: "0 -4px 4px -2px rgba(0, 0, 0, 0.2)", // Top-only shadow
                  }}
                >
                  <Box
                    display="flex"
                    alignItems="center"
                    sx={{ flexGrow: 1 }} // This allows the search box or text to take up the remaining space
                  >
                    {search.script ? (
                      <TextField
                        variant="standard"
                        placeholder="Search"
                        InputProps={{
                          endAdornment: (
                            <InputAdornment position="end">
                              <img
                                src={searchIcon}
                                alt="Search Icon"
                                style={{ width: "20px", height: "20px" }}
                              />
                            </InputAdornment>
                          ),
                          sx: {
                            width: "100%", // Ensures the input takes up the available space within the flex container
                            "& .MuiOutlinedInput-root": {
                              "& .MuiOutlinedInput-notchedOutline": {
                                borderColor: "blue",
                              },
                              "& .MuiInputBase-input": {
                                display: "flex",
                                alignItems: "center",
                              },
                            },
                          },
                        }}
                        sx={{ width: "100%" }} // Ensures the TextField takes up full width
                      />
                    ) : (
                      <Typography>Scripts</Typography>
                    )}
                  </Box>

                  <Box display="flex" alignItems="center" sx={{ mb: 1 }}>
                    <IconButton onClick={(e) => handleSetSearch("script")}>
                      {search.script ? (
                        <img
                          src={closeIcon}
                          alt="Close Icon"
                          style={{ width: "13px", height: "13px" }}
                        />
                      ) : (
                        <img
                          src={searchIcon}
                          alt="Search Icon"
                          style={{ width: "24px", height: "24px" }}
                        />
                      )}
                    </IconButton>
                    <IconButton onClick={handleClick}>
                      <img
                        src={plusIcon}
                        alt="plus Icon"
                        style={{ width: "24px", height: "24px" }}
                      />
                    </IconButton>
                    <HapiOptions
                      anchorEl={anchorEl}
                      handleClose={handleClose}
                    />
                  </Box>
                </Box>
                <Divider />
                <Box
                  sx={{
                    display: "flex",
                    justifyContent: "center",
                    width: "100%",
                  }}
                >
                  <ScriptRunButtons />
                </Box>
                <Divider />
                {hapiScriptList && hapiScriptList.length > 0 && <ScriptList />}
              </>
            )}
          </Box>

          {/* HAPI page DUT video streaming area */}
          <Box
            sx={{
              flex: "1 1 auto",
              height: "100%",
              bgcolor: "#E9F3FC",
              minWidth: 0,
              display: "flex",
              position: "relative",
              flexDirection: "column", // Ensure that the accordion stacks vertically with the video feed
            }}
          >
            <VideoFeed
              ref={videoFeedRef}
              sx={{ flex: "1 1 auto", width: "100%", overflow: "" }}
            />
            <AccordionExpandDefault />
          </Box>
          {/* HAPI Pagel properties */}
          <Box
            sx={{
              flex: "0 0 20%",
              minWidth: "300px",
              height: "100%",
              display: "flex",
              flexDirection: "column",
            }}
          >
            {/* First Box with 70% height */}
            <Box sx={{ flex: "0 0 70%", overflowY: "auto" }}>
              <Box
                display="flex"
                justifyContent="space-between"
                alignItems="center"
                pl={2}
                pt={1}
              >
                <Box display="flex" alignItems="center" sx={{ flexGrow: 1 }}>
                  {search.action ? (
                    <TextField
                      variant="standard"
                      placeholder="Search"
                      InputProps={{
                        endAdornment: (
                          <InputAdornment position="end">
                            <img
                              src={searchIcon}
                              alt="Search Icon"
                              style={{ width: "20px", height: "20px" }}
                            />
                          </InputAdornment>
                        ),
                        sx: {
                          width: "100%",
                          "& .MuiOutlinedInput-root": {
                            "& .MuiOutlinedInput-notchedOutline": {
                              borderColor: "blue",
                            },
                            "& .MuiInputBase-input": {
                              display: "flex",
                              alignItems: "center",
                            },
                          },
                        },
                      }}
                      sx={{ width: "100%" }}
                    />
                  ) : (
                    <Typography>{hapiAction}</Typography>
                  )}
                </Box>
                <Box display="flex" alignItems="center">
                  <SingleScripTest edit={true} />
                </Box>
              </Box>
              {hapiAction && <GeneralSettingsHapi />}
              {hapiAction === "Mouse Assist" ? (
                <>
                  <MouseAssist />
                  <TapParameters />
                </>
              ) : hapiAction === "Swipe" ? (
                <>
                  <TapParameters />
                </>
              ) : hapiAction === "Delay" ? (
                <>
                  <DelayParameters />
                </>
              ) : (
                hapiScriptName.length > 2 && (
                  <>
                    {hapiType === "EMT" ||
                    hapiType === "OCR" ||
                    hapiType === "OCT" ? (
                      <HapiElements />
                    ) : (
                      <HapiButtonsSelect />
                    )}
                    <TapParameters />
                  </>
                )
              )}
              {hapiScriptName.length > 2 && <SetResponse />}
              <AddDelayModal />
            </Box>

            {/* Second Box with 30% height */}
            <Box sx={{ flex: "0 0 30%", overflowY: "auto" }}>
              <VideoServeillance />
            </Box>
          </Box>
        </Box>
      </Box>
    </ThemeProvider>
  );
}

export default HapiPage;
