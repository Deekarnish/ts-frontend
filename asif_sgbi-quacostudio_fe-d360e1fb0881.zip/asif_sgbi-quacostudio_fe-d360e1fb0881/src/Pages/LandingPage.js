import * as React from 'react';
import Box from '@mui/material/Box';
import Grid from '@mui/material/Grid';
import LandingPageSidebar from '../landing_page/LandingPageSidebar';
import LandingPageSearchPanel from '../landing_page/LandingPageSearchPanel';
import DutList from '../landing_page/LandingPageDutList';

export function LandingPage({open , setOpen}) {
  const [list, setList] = React.useState('grid')

  return (
   
      <Box sx={{ flexGrow: 1, bgcolor: 'background.default', color: 'text.primary', padding:0,height:"87vh"}}>
        <Grid container spacing={2} >
          <Grid item xs={2} md={3} sm={3} lg={2} sx={{ bgcolor: 'primary.main' ,}}>
            <LandingPageSidebar open={open} setOpen={setOpen}/>
          </Grid>
          <Grid item xs={10} md={9} lg={10} sm={9} sx={{ bgcolor:'#E4E7ED'}}>
            <LandingPageSearchPanel list={list} setList={setList} />
            <DutList list={list}/>
            {/* <LandingPageMain/> */}
          </Grid>
        </Grid>
      </Box>

  );
}
